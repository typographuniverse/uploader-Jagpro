module.exports = {
  TOKEN: '', //token bot tele anda
  OWNER_ID: '' // Ganti dengan ID Telegram owner
}