
 process.on("unhandledRejection", (reason, promise) => {
    if (reason && reason.message && reason.message.includes("item-not-found","rate-overlimit")) {
        return; // Abaikan error item-not-found
    }
    console.error("⚠️ Unhandled Rejection:", reason);
});
const originalConsoleError = console.error;
console.error = function (...args) {
    if (args[0] && typeof args[0] === "object" && args[0].message && args[0].message.includes("item-not-found","rate-overlimit")) {
        return; // Abaikan error item-not-found
    }
    originalConsoleError.apply(console, args);
};

const express = require('express');
const os = require('os');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const CFonts = require('cfonts');
const chalk = require('chalk');

const app = express();


const port = 5000;

const namebot = 'Jagoan Project';
const nameowner = 'Chandra';
/*
// Function to display header information
function displayHeader() {
    
    
    CFonts.say(namebot, {
        font: 'simple',
        align: 'center',
        colors: ['yellow'],
        background: 'transparent',
        letterSpacing: '0'
    });
    CFonts.say('Aping P Nya Pemula', {
        font: 'console',
        align: 'center',
        colors: ['white'],
        background: 'transparent',
        letterSpacing: '0'
    }); */
console.log(`
     ██  █████   ██████  ██████  ██████   ██████  
     ██ ██   ██ ██       ██   ██ ██   ██ ██    ██ 
     ██ ███████ ██   ███ ██████  ██████  ██    ██ 
██   ██ ██   ██ ██    ██ ██      ██   ██ ██    ██ 
 █████  ██   ██  ██████  ██      ██   ██  ██████  
    `);
    console.log(chalk.white.bold(`
- 📱 Platform: ${os.platform()}
- 🏛️ Architecture: ${os.arch()}
- 💻 Total Memory: ${(os.totalmem() / 1024 / 1024).toFixed(2)} MB
- 🚀 Free Memory: ${(os.freemem() / 1024 / 1024).toFixed(2)} MB
`));
/////////IKLAN DAN LOADING////////////

console.log(chalk.yellow.bold('Ingin Membeli Panel Unlimited seharga 10k saja? Hubungi kami, 0895-3622-82300 atau setelah anda terkoneksi nanti, ketik .owner'));
console.log(chalk.red.bold('Apa yang akan kamu dapatkan?'));
console.log(chalk.green.bold('✓ ') + chalk.red('Unlimited RAM Selama Sebulan'));
console.log(chalk.green.bold('✓ ') + chalk.red('Grup Buyer, gw gak bakal Kabur kalau Mokad'));
console.log(chalk.green.bold('✓ ') + chalk.red('Garansi Unlimited 30 Hari'));
console.log(chalk.green.bold('✓ ') + chalk.red('Fast Response'));
console.log(chalk.green.bold('✓ ') + chalk.red('Free Script Auto-AI ( Kalau ada )'));
console.log(chalk.green.bold('MEMULAI BOT WHATSAPP... '));
console.log(chalk.green.bold('______________'));
///////////////IKLAN//////////////	
// displayHeader();
//console.clear();

app.get('/', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const data = {
        status: 'true',
        message: `${namebot} Sekarang telah berjalan`,
        author: nameowner
    };

    const result = {
        response: data
    };
    res.send(JSON.stringify(result, null, 2));
});

app.listen(port, () => {
    console.log(`Server sedang berjalan di port ${port}`);
});

let isRunning = false;

function start(file) {
    if (isRunning) return;
    isRunning = true;

    const args = [path.join(__dirname, file), ...process.argv.slice(2)];
    const p = spawn(process.argv[0], args, {
        stdio: ['inherit', 'inherit', 'inherit', 'ipc'],
    });

    p.on('message', (data) => {
        console.log(`[ ${namebot} ]${data}`);
        switch (data) {
            case 'reset':
                p.kill();
                isRunning = false;
                start.apply(this, arguments);
                break;
            case 'uptime':
                p.send(process.uptime());
                break;
        }
    });

  p.on('exit', (code, signal) => {
    isRunning = false;

    if (code === null) {
        console.error("❌ [FATAL] Bot keluar dengan code: NULL (mungkin crash atau dibunuh sistem)");
        console.error(`🔍 Signal exit: ${signal || 'Tidak diketahui'}`);
        console.log("⏳ Restart otomatis setelah file berubah...");
    } else {
        console.error(`❌ [EXIT] Bot berhenti dengan code: ${code}`);
    }

    // Auto restart ketika file berubah
    fs.watchFile(args[0], () => {
        fs.unwatchFile(args[0]);
        console.log("♻️ Perubahan file pad index.js terdeteksi, bot akan di-restart...");
        start('start.js');
    });


    });

    p.on('error', (err) => {
        console.error('\x1b[31m%s\x1b[0m', `Error: ${err}`);
        p.kill();
        isRunning = false;
        start('start.js');
    });

    const pluginsFolder = path.join(__dirname, 'plugins');

    fs.readdir(pluginsFolder, (err, files) => {
        if (err) {
            console.error(`Error reading plugins folder: ${err}`);
            return;
        }
        //displayHeader(); //////////////////////fungsi awal ini yaa
    });

    setInterval(() => {}, 1000);
}

start('start.js');

process.on('unhandledRejection', () => {
    console.error('\x1b[31m%s\x1b[0m', 'Unhandled promise rejection. Script will restart...');
    start('start.js');
}); 

process.on('exit', (code) => {
    console.error(`Exited with code: ${code}`);
    console.error('Script will restart...');
    start('start.js');
});
