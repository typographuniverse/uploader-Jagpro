let handler = async (m, { conn, text, usedPrefix, command }) => {
    let who;
    if (m.isGroup) {
        if (m.mentionedJid && m.mentionedJid.length > 0) {
            who = m.mentionedJid[0];
        } else if (m.quoted) {
            who = m.quoted.sender;
        } else {
            throw '🚨 *Tag atau reply seseorang untuk merampok!* \n\n📝 Contoh: \n— *' + usedPrefix + command + ' @user*\n— *' + usedPrefix + command + ' (reply pesan)*';
        }
    } else {
        throw '🚨 *Perintah ini hanya bisa digunakan di grup!*';
    }

    if (!who) throw '🚨 *User tidak valid!*';
    if (who === m.sender) throw '😂 *Kamu tidak bisa merampok diri sendiri!*';
    if (typeof global.db.data.users[who] === 'undefined') throw '😕 *Pengguna tidak ada di database!*';

    let users = global.db.data.users;

    // Check if the target is an owner
    if (users[who].rowner) {
        let initialMoney = users[m.sender].money || 0;
        let penalty = Math.floor(initialMoney * 0.5); // 50% of robber's money
        users[m.sender].money -= penalty;
        global.db.data.users[m.sender].lastrob = new Date * 1; // Apply cooldown
        return conn.reply(m.chat, `😱 *Lah, mau rampok owner?* Maaf, kamu didenda! 💸 Uangmu semula *Rp. ${initialMoney}* dikurangi 50% denda menjadi *Rp. ${users[m.sender].money}*!`, m);
    }

    let __timers = (new Date - global.db.data.users[m.sender].lastrob);
    let _timers = (7200000 - __timers); // 2 hours cooldown
    let timers = clockString(_timers);

    if (new Date - global.db.data.users[m.sender].lastrob < 7200000) { // 2 hours cooldown
        return conn.reply(m.chat, `⏳ *Kamu sudah merampok dan sedang sembunyi!* Tunggu *${timers}* untuk merampok lagi.`, m);
    }

    if (users[who].money < 10000) throw '😢 *Target miskin, uangnya kurang dari 10,000!*';

    let dapat = Math.floor(Math.random() * 100000);
    let successChance = Math.random();
    let success = successChance < 0.7; // 70% success rate, 30% failure rate

    if (success) {
        users[who].money -= dapat;
        users[m.sender].money += dapat;
        global.db.data.users[m.sender].lastrob = new Date * 1;
        conn.reply(m.chat, `💰 *Berhasil merampok!* Kamu mendapatkan *${dapat} money* dari @${who.split('@')[0]}! 🏃‍♂️`, m, { contextInfo: { mentionedJid: [who] } });
    } else {
        let bribe = Math.floor(users[m.sender].money * 0.2); // 20% of robber's money
        if (bribe <= 0) {
            global.db.data.users[m.sender].lastrob = new Date * 1;
            conn.reply(m.chat, `🚓 *Kamu tertangkap!* Uangmu kosong, jadi tidak ada suap. Pihak berwenang memaafkanmu kali ini, tapi cooldown tetap berlaku! 😅`, m);
        } else {
            users[m.sender].money -= bribe;
            users[who].money += bribe;
            global.db.data.users[m.sender].lastrob = new Date * 1;
            conn.reply(m.chat, `🚓 *Kamu tertangkap!* Kamu membayar suap sebesar *${bribe} money* (20% dari uangmu) kepada @${who.split('@')[0]}. 😓`, m, { contextInfo: { mentionedJid: [who] } });
        }
    }
};

handler.help = ['merampok *[@user | reply]*'];
handler.tags = ['rpg'];
handler.command = /^merampok|rampok$/i;
handler.limit = true;
handler.group = true;

module.exports = handler;

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':');
}