// 📝 plugin owner - addowner

const fs = require('fs')
const path = require('path')
const settingsPath = path.resolve(__dirname, '../settings.js') // Ubah jika beda lokasi

let handler = async (m, { conn, text }) => {
    let who
    if (m.isGroup) {
        who = m.mentionedJid[0]
            ? m.mentionedJid[0]
            : m.quoted
            ? m.quoted.sender
            : text
    } else {
        who = m.chat
    }

    if (!who) throw '‼️ Harap tag user.'
    let number = who.split('@')[0]

    if (global.owner.find(o => o[0] === number))
        throw '*‼️ Orang ini sudah jadi owner.*'

    global.owner.push([number, true])

    try {
        await updateSettingsOwner(global.owner)
    } catch (e) {
        console.error('Gagal update settings.js:', e)
        throw '‼️ Gagal menyimpan ke settings.js. Pastikan bot punya izin tulis file.'
    }

    const caption = `✅ Berhasil menambah owner\n\n– 🧑🏻‍🦱 nomor : @${number}\n\n> jangan salah gunakan fitur owner!`
    await conn.reply(m.chat, caption, m, {
        mentions: conn.parseMention(caption)
    })
}

async function updateSettingsOwner(ownerArray) {
    let content = fs.readFileSync(settingsPath, 'utf-8')
    let lines = content.split('\n')

    let startIndex = lines.findIndex(line =>
        line.trim().startsWith('global.owner')
    )
    if (startIndex === -1) throw 'Tidak ditemukan global.owner di settings.js'

    let endIndex = startIndex
    while (endIndex < lines.length && !lines[endIndex].includes('];')) {
        endIndex++
    }

    const newOwnerLines = [
        'global.owner = [',
        ...ownerArray.map(o => `    ['${o[0]}', true],`),
        '];'
    ]

    lines.splice(startIndex, endIndex - startIndex + 1, ...newOwnerLines)

    fs.writeFileSync(settingsPath, lines.join('\n'))
}

handler.help = ['addowner <@user>']
handler.tags = ['owner']
handler.command = /^(add|tambah|\+)owner$/i
handler.rowner = true

module.exports = handler