let handler = async (m, { conn }) => {
  try {
    if (!m.key || !m.messageTimestamp) {
      return conn.reply(m.chat, '❌ Tidak bisa membaca data pesan!', m)
    }

    await conn.chatModify({
      delete: true,
      lastMessages: [
        {
          key: m.key,
          messageTimestamp: m.messageTimestamp
        }
      ]
    }, m.chat)

    // Catatan: tidak bisa balas lagi karena chat sudah terhapus
    // Tapi bisa kasih notifikasi sebelum eksekusi
    // conn.reply(m.chat, '✅ Menghapus chat...', m)

  } catch (e) {
    conn.reply(m.chat, '❌ Gagal menghapus percakapan!\n\n' + e.message, m)
  }
}

handler.help = ['clearchat']
handler.tags = ['owner']
handler.command = /^clearchat$/i
handler.rowner = true

module.exports = handler
