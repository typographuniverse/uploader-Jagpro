const { createCanvas, loadImage } = require('canvas')
const moment = require('moment-timezone')
const fs = require('fs')
const path = require('path')

let handler = async (m, { args, usedPrefix, command }) => {
  let text = args.join(' ')
  if (!text) {
    return m.reply(`❌ Format salah!\nGunakan: ${usedPrefix}${command} WIB|namaPengirim|nominal`)
  }

  let [tz, namaPengirim, nominalStr] = text.split('|')
  const validTimezones = { WIB: 'Asia/Jakarta', WITA: 'Asia/Makassar', WIT: 'Asia/Jayapura' }

  if (!validTimezones[tz.toUpperCase()]) {
    return m.reply(`❌ Timezone tidak valid! Gunakan WIB, WITA, atau WIT.`)
  }

  const nominal = parseInt(nominalStr)
  if (isNaN(nominal)) return m.reply('❌ Nominal harus berupa angka.')

  const now = moment().tz(validTimezones[tz.toUpperCase()])
  const jamTanggal = now.format('HH:mm')
  const hariTanggal = now.format('dddd, DD • MM • YYYY')

  try {
 const bg = await loadImage('https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/src/mentahan_notifdana.jpg')
    const canvas = createCanvas(bg.width, bg.height)
    const ctx = canvas.getContext('2d')
    ctx.drawImage(bg, 0, 0, canvas.width, canvas.height)

    const draw = (text, x, y, font = '22px sans-serif', align = 'left', color = '#000') => {
      ctx.font = font
      ctx.fillStyle = color
      ctx.textAlign = align
      ctx.fillText(text, x, y)
    }

    // Warna abu untuk jam & tanggal
    draw(jamTanggal, 58, 135, 'bold 60px sans-serif', 'left', '#e8e6e6')
    draw(hariTanggal, 58, 175, '24px sans-serif', 'left', '#e8e6e6')

    // Warna putih soft (#e6e6e6) untuk teks notifikasi
    draw(`Hi, ${namaPengirim} baru saja Kirim DANA ke kamu`, 106, 656, '21px sans-serif', 'left', '#e6e6e6')
    draw(`Rp${nominal.toLocaleString('id-ID')} !`, 106, 687, '21px sans-serif', 'left', '#e6e6e6')

    const buffer = canvas.toBuffer()
    await conn.sendFile(m.chat, buffer, 'notifdana.png', 'Thanks yang udah kirim uang sebanyak ini🤑', m)
  } catch (e) {
    console.error(e)
    m.reply(`❌ Terjadi kesalahan:\n${e.message}`)
  }
}

handler.command = ['notifdana']
handler.help = ['notifdana']
handler.tags = ['maker']
handler.limit = true

module.exports = handler
