const fetch = require('node-fetch')
const fs = require('fs')
const path = require('path')
const { pipeline } = require('stream')
const { promisify } = require('util')
const streamPipeline = promisify(pipeline)

let handler = async (m, { args, usedPrefix, command }) => {
  if (!args[0]) throw `Masukkan link GitHub, contoh:\n${usedPrefix + command} https://github.com/user/repo`

  let match = args[0].match(/^https:\/\/github\.com\/([^\/]+)\/([^\/]+)/)
  if (!match) throw '❌ Link GitHub tidak valid! Harus dalam format: https://github.com/user/repo'

  let username = match[1]
  let repo = match[2]

  // Ambil default branch dari GitHub API
  let api = await fetch(`https://api.github.com/repos/${username}/${repo}`)
  if (!api.ok) throw `❌ Gagal ambil info repo dari GitHub`
  let json = await api.json()
  let branch = json.default_branch || 'main'

  // URL zip
  let zipUrl = `https://github.com/${username}/${repo}/archive/refs/heads/${branch}.zip`
  let fileName = `${repo}.zip`
  let filePath = path.join(__dirname, '../tmp', fileName)

  // Cek dan buat folder tmp jika belum ada
  if (!fs.existsSync(path.dirname(filePath))) fs.mkdirSync(path.dirname(filePath), { recursive: true })

  try {
    m.reply(`📥 Sedang mengunduh repo *${repo}* dari GitHub...`)

    const response = await fetch(zipUrl)
    if (!response.ok) throw '❌ Gagal mengunduh ZIP dari GitHub'
    
    await streamPipeline(response.body, fs.createWriteStream(filePath))



let buffer = fs.readFileSync(filePath)
await conn.sendMessage(m.chat, {
  document: buffer,
  fileName,
  mimetype: 'application/zip',
  caption: `✅ Berhasil mengunduh *${repo}* dari branch *${branch}*`
}, { quoted: m })


    // Hapus file setelah berhasil kirim
    fs.unlink(filePath, err => {
      if (err) console.error('Gagal hapus file:', err)
    })

  } catch (err) {
    m.reply('❌ Gagal memproses: ' + err)
  }
}

handler.help = ['githubdl <url>']
handler.tags = ['downloader']
handler.command = /^githubdl|gitclone$/i
handler.limit = true

module.exports = handler
