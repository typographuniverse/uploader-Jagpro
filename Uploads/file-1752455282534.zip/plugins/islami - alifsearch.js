const axios = require('axios');
const cheerio = require('cheerio');

async function alifSearch(keyword) {
    try {
        const { data } = await axios.get(`https://alif.id/?s=${keyword}`);
        const $ = cheerio.load(data);
        const results = [];

        $('.post.style3').each((index, element) => {
            const title = $(element).find('.post-title h5 a span').text().trim();
            const link = $(element).find('.post-title h5 a').attr('href');
            const author = $(element).find('.post-author a').text().trim();
            const date = $(element).find('.post-date').text().trim();
            const category = $(element).find('.post-category a').text().trim();

            if (title && link) {
                results.push({
                    title,
                    url: link,
                    author,
                    date,
                    category,
                });
            }
        });

        return results;
    } catch (error) {
        console.error('Error fetching or parsing data:', error);
        return null;
    }
}

const handler = async (m, { text, args, command }) => {
    try {
        if (command === 'alifsearch') {
            if (!text) return m.reply('Masukkan kata kunci pencarian artikel! Contoh: .alifsearch doa makan');

            const results = await alifSearch(text);
            if (!results || results.length === 0) return m.reply(`Tidak ditemukan artikel dengan kata kunci "${text}".`);

            let result = `🔍 Hasil Pencarian untuk "${text}"\n\n`;
            results.forEach((article, i) => {
                result += `${i + 1}. ${article.title}\n   ✍️ Penulis: ${article.author}\n   📅 Tanggal: ${article.date}\n   🏷️ Kategori: ${article.category}\n   🔗 ${article.url}\n\n`;
            });
            m.reply(result.trim());
        }
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan.');
    }
};

handler.command = ['alifsearch'];
handler.help = ['alifsearch'];
handler.tags = ['islami'];
handler.limit = true;

module.exports = handler;