// ✨ Plugin downloader - mediafire ✨

const fetch = require('node-fetch');
const cheerio = require('cheerio');
const { https } = require('follow-redirects');
const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, args }) => {
  if (!args[0]) return m.reply('Contoh:\n.mediafire https://www.mediafire.com/file/...');

  const url = args[0];
  if (!url.includes('mediafire.com')) return m.reply('❌ Link bukan dari mediafire.com');

  try {
    const res = await fetch(url);
    const html = await res.text();
    const $ = cheerio.load(html);

    
    const fileName = $('div.filename').first().contents().filter(function () {
      return this.type === 'text';
    }).text().trim();

    const fileSize = $('ul.dl-info > li').first().text().replace('Size:', '').trim();
    const downloadLink = $('#downloadButton').attr('href');

    if (!downloadLink) return m.reply('❌ Gagal mengambil direct download link.');

    const repairLink = url;
    const ext = fileName.split('.').pop().toLowerCase();
    const filePath = path.join(__dirname, '../tmp', fileName);
    if (!fs.existsSync(path.dirname(filePath))) fs.mkdirSync(path.dirname(filePath), { recursive: true });

    // MIME detector
    let mimeTypes = {
      "zip": "application/zip", "rar": "application/vnd.rar", "7z": "application/x-7z-compressed",
      "pdf": "application/pdf", "txt": "text/plain", "doc": "application/msword",
      "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "mp3": "audio/mpeg", "mp4": "video/mp4", "jpg": "image/jpeg", "jpeg": "image/jpeg",
      "png": "image/png", "gif": "image/gif", "webp": "image/webp"
    };
    const mimetype = mimeTypes[ext] || 'application/octet-stream';

    // Kirim info + tombol dulu
    let caption = `📂 *Mediafire File Info*\n\n` +
                  `📌 *Judul:* ${fileName}\n` +
                  `💾 *Ukuran:* ${fileSize || "Tidak Tersedia"}\n\n` +
                  `_Gunakan tombol di bawah untuk mengakses file._`;

    const interactiveButtons = [
      {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: "📂 Kunjungi File",
          url: downloadLink
        })
      },
      {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: "⚒️ Perbaiki Link",
          url: repairLink
        })
      }
    ];

    await conn.sendMessage(m.chat, {
      text: caption,
      title: "Sang Jagoan",
      footer: "Downloader by Jagoan Project",
      interactiveButtons
    }, { quoted: m });

/*
    m.reply('⏬ Mengunduh file, mohon tunggu...');
*/
    const file = fs.createWriteStream(filePath);
    https.get(downloadLink, res => {
      res.pipe(file);
      file.on('finish', async () => {
        file.close();
        await conn.sendMessage(
          m.chat,
          {
            document: fs.readFileSync(filePath),
            mimetype,
            fileName
          },
          { quoted: m }
        );
        fs.unlinkSync(filePath);
      });
    }).on('error', err => {
      fs.unlinkSync(filePath);
      console.error(err);
      m.reply('❌ Gagal mengunduh file:\n' + err.message);
    });

  } catch (err) {
    console.error(err);
    m.reply('❌ Terjadi kesalahan:\n' + err.message);
  }
};

handler.help = ['mediafire [url]'];
handler.tags = ['downloader'];
handler.command = /^mediafire$/i;

module.exports = handler;