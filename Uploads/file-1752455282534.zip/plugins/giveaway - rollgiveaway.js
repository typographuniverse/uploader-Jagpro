const fs = require('fs');
const path = require('path');

// Helper function to ensure database directory exists
const ensureDatabaseDir = () => {
    const dir = path.join(__dirname, '../database');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
};

// Helper function to load giveaways from JSON file
const loadGiveaways = () => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return {};
    } catch (err) {
        console.error('Error loading giveaways:', err);
        return {};
    }
};

// Helper function to save giveaways to JSON file
const saveGiveaways = (giveaways) => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        ensureDatabaseDir();
        fs.writeFileSync(filePath, JSON.stringify(giveaways, null, 2), 'utf8');
    } catch (err) {
        console.error('Error saving giveaways:', err);
    }
};

let handler = async (m, { conn, usedPrefix }) => {
    // Initialize conn.giveway from JSON file
    conn.giveway = loadGiveaways();

    let id = m.chat;
    if (!(id in conn.giveway)) throw `‼️ *UPSS!! TIDAK BISA*\n\n– tidak ada giveaway yang sedang berlangsung di group ini, untuk memulai giveaway ikuti contoh dibawah ini.\n📝 Contoh penggunaan :\n\n– ${usedPrefix}mulaigiveaway akun epep`;

    let d = new Date;
    let date = d.toLocaleDateString('id', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });
    let absen = conn.giveway[id][1];

    // Shuffle the absen array
    shuffleArray(absen);

    if (absen.length === 0) throw '*tidak ada peserta yang tersisa!*';

    let totalParticipants = absen.length; // Total peserta sebelum pemilihan
    let cita = absen.shift(); // Pilih dan hapus peserta pertama
    let tag = `@${cita.split`@`[0]}`; // Menandai pemenang

    let loadd = [
        '■□□□□□□□□□ 10%',
        '■■□□□□□□□□ 20%',
        '■■■□□□□□□□ 30%',
        '■■■■□□□□□□ 40%',
        '■■■■■□□□□□ 50%',
        '■■■■■■□□□□ 60%',
        '■■■■■■■□□□ 70%',
        '■■■■■■■■□□ 80%',
        '■■■■■■■■■□ 90%',
        '■■■■■■■■■■ 100%',
        '*✅ LAODING COMPLETE*'
    ];

    let { key } = await conn.sendMessage(m.chat, { text: '*♻️ Mengacak pemenang..*' });

    for (let i = 0; i < loadd.length; i++) {
        await sleep(1000);
        await conn.sendMessage(m.chat, { text: loadd[i], edit: key });
    }

    // Pesan tipuan
    let fakeMessages = [
        `Apakah @${cita.split`@`[0]} yang menang??🤔🤔`,
        `Oh bukann😁, acak lagiii ahhh...`,
        `Apakah @${cita.split`@`[0]} yang menang? 😭 Hmmm, dari tampangnya keknya gak cocok deh`,
        `Kalau @${cita.split`@`[0]}? Kayaknya masih bukan deh, acak lagi ahh.. terakhir nih guys...😂 `
    ];

    // Membuat salinan dari array absen untuk memilih peserta secara acak
    let remainingAbsens = [...absen];

    // Fungsi untuk memilih peserta secara acak
    const getRandomParticipant = () => {
        if (remainingAbsens.length === 0) return null; // Jika tidak ada peserta tersisa
        let randomIndex = Math.floor(Math.random() * remainingAbsens.length);
        let randomParticipant = remainingAbsens.splice(randomIndex, 1)[0]; // Pilih dan hapus peserta dari array
        return randomParticipant;
    };

    // Mengganti setiap pesan dengan peserta acak
    for (let message of fakeMessages) {
        let randomParticipant = getRandomParticipant();
        if (randomParticipant) {
            let tagRandomParticipant = `@${randomParticipant.split`@`[0]}`;
            await conn.sendMessage(m.chat, {
                text: message.replace('@' + cita.split`@`[0], tagRandomParticipant),
                contextInfo: { mentionedJid: [randomParticipant] }
            });
        }
        await sleep(7000); // Delay 7 detik
    }

    // Hasil akhir
    await sleep(5000); // Delay 5 detik sebelum mengirim hasil
    let remainingParticipants = absen.length; // Jumlah peserta tersisa setelah pemilihan

    // Update database with remaining participants
    conn.giveway[id][1] = absen;
    saveGiveaways(conn.giveway); // Save to JSON file

    return conn.reply(m.chat, `🎊 *CONGRATULATIONS* 🎊

– selamat kepada ${tag} kamu adalah pemenang giveawaynya dari ${totalParticipants} peserta.

– 🤴🏻 pemenang : ${tag}
– 📆 tanggal : ${date}
– 👨‍👨‍👧‍👦 sisa peserta : ${remainingParticipants}
————————————————————————
*📝 NOTE :* Hapus giveaway setelah selesai dengan cara ketik *.hapusgiveaway*`, m, { contextInfo: { mentionedJid: [cita] } });
};

handler.help = ['rollgiveaway'];
handler.tags = ['giveaway'];
handler.command = /^(rolling|rollgiveaway|rollinggiveaway)$/i;
handler.admin = true;
module.exports = handler;

const sleep = (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};

// Fisher-Yates Shuffle Algorithm
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}