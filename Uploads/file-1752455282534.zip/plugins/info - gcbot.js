let handler = async (m, { conn }) => {
    let groups = Object.values(conn.chats).filter(chat => chat.id.endsWith('@g.us'));
    
    if (groups.length === 0) {
        return conn.reply(m.chat, '🚫 Bot tidak bergabung dalam grup mana pun.', m);
    }

    let message = '*📋 Daftar Grup yang Diikuti Bot:*\n\n';
    
    for (let i = 0; i < groups.length; i++) {
        let group = groups[i];
        let metadata = await conn.groupMetadata(group.id).catch(() => null); 
        if (!metadata) continue;

        let subject = metadata.subject || 'Nama Grup Tidak Tersedia';
        let participants = metadata.participants.length; // Jumlah anggota grup
        let creationDate = new Date(metadata.creation * 1000).toLocaleDateString('id-ID'); // Konversi timestamp ke tanggal
        let botAdmin = metadata.participants.find(p => p.id === conn.user.jid)?.admin ? '✅ Ya' : '❌ Tidak';

        message += `*${i + 1}. ${subject}*\n`;
        message += `*ID:* ${group.id}\n\n`;
        message += `*Jumlah Anggota :* ${participants} orang\n`;
        message += `*Dibuat Pada    :* ${creationDate}\n`;
        message += `🔑 Bot Admin   : ${botAdmin}\n`;
        message += `━━━━━━━━━━━━━━━━━━\n\n`;
    }

    conn.reply(m.chat, message, m);
};

handler.help = ['gcbot'];
handler.tags = ['tools'];
handler.command = /^(gcbot)$/i;

module.exports = handler;
