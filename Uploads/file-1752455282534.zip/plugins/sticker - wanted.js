const fetch = require('node-fetch');
const { Sticker } = require('wa-sticker-formatter');
const uploadImage = require('../scrape/uploadImage');

const handler = async (m, { conn, command, usedPrefix }) => {
  try {
    // Validasi global.ptereodactyl
    if (!global.ptereodactyl) {
      throw new Error('Base URL ptereodactyl tidak terdefinisi di settings.js');
    }

    // Cek apakah ada gambar atau sticker yang di-reply
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mediaType || '';
    if (!/image\/(png|jpe?g)|webp/.test(mime)) {
      return m.reply(`📸 Reply gambar (PNG/JPEG/Video) atau sticker biasa atau sticker bergerak dengan caption *${usedPrefix + command}* untuk membuat trigger! 😎`);
    }

    // Kasih tanda bot sedang bekerja
    await conn.sendMessage(m.chat, { react: { text: '⚙️', key: m.key } });

    // Download media
    const media = await q.download();
    const fileSizeLimit = 5 * 1024 * 1024; // 5MB
    if (media.length > fileSizeLimit) {
      throw new Error('Ukuran gambar/sticker tidak boleh melebihi 5MB');
    }

    // Upload gambar untuk mendapatkan URL
    const imageUrl = await uploadImage(media);

    // Buat URL API menggunakan global.ptereodactyl
    const API_URL = `${global.ptereodactyl}api/wanted?url=${encodeURIComponent(imageUrl)}`;
    const response = await fetch(API_URL, { method: 'GET', responseType: 'arraybuffer' });

    if (!response.ok) {
      throw new Error(`Gagal mengambil data dari API: ${response.status} ${response.statusText}`);
    }

    // Ambil data gambar dari API
    const imageBuffer = Buffer.from(await response.arrayBuffer());

    // Buat sticker dari hasil API
    const sticker = new Sticker(imageBuffer, {
      pack: global.packname || 'wanted Sticker',
      author: global.author || 'Jagoan Project',
      type: 'full',
      quality: 20
    });

    // Kirim sticker ke chat
    await conn.sendFile(m.chat, await sticker.toBuffer(), 'sticker.webp', '', m);

    // Efek sukses
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (e) {
    console.error('Error in trigger handler:', e);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply('😓 Gagal membuat sticker trigger. Pastikan gambar/sticker valid dan coba lagi! 🙏');
  }
};

handler.help = ['wanted'];
handler.tags = ['sticker'];
handler.command = /^wanted$/i;
handler.limit = true;

module.exports = handler;