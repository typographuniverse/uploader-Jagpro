let setmenu = async (m, { conn, args }) => {
  // Daftar mode menu yang tersedia
  const menuModes = ['simple', 'payment', 'edit', 'buttonlist', 'image', 'button', 'mix', 'gift'];
  
  // Jika tidak ada argumen, tampilkan daftar mode
  if (!args[0]) {
    const list = menuModes.map((mode, index) => `${index + 1}. ${mode.charAt(0).toUpperCase() + mode.slice(1)}`).join('\n');
    return m.reply(`📋 *Daftar Mode Menu yang Tersedia:*\n\n${list}\n\nKetik \`.setmenu <nomor>\` untuk memilih mode.\nContoh: \`.setmenu 3\``);
  }

  // Validasi argumen sebagai nomor
  const modeIndex = parseInt(args[0]) - 1;
  if (isNaN(modeIndex) || modeIndex < 0 || modeIndex >= menuModes.length) {
    return m.reply(`❌ Nomor tidak valid! Pilih nomor antara 1 dan ${menuModes.length}.\nKetik \`.setmenu\` untuk melihat daftar mode.`);
  }

  // Ubah mode menu di database
  const selectedMode = menuModes[modeIndex];
  global.db.data.settings[conn.user.jid].setmenu = selectedMode;
  
  // Kirim konfirmasi
  await conn.sendMessage(m.chat, {
    text: `✅ Mode menu berhasil diubah ke: *${selectedMode.charAt(0).toUpperCase() + selectedMode.slice(1)}*\nGunakan \`.menu\` untuk melihat menu dengan mode baru.`,
    contextInfo: global.adReply.contextInfo // Menggunakan contextInfo dari global.adReply
  }, { quoted: m });
}

setmenu.help = ['setmenu [nomor]'];
setmenu.tags = ['owner'];
setmenu.command = ['setmenu'];
setmenu.owner = true; // Hanya owner yang bisa menggunakan perintah ini
module.exports = setmenu;