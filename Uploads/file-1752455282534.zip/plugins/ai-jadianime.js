const uploadImage = require('../lib/uploadImage.js');
let handler = async (m, { conn }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw 'No media found'
  let media = await q.download()
  let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
  let link = await uploadImage(media)
  let s = await filters(link)
  conn.sendMessage(m.chat, { image: { url: global.apixtermurl + "/api/tools/buffimg?url="+s.url  +"&key="+ global.apixtermkey} }, { quoted: m })
}
handler.help = ['toanime (reply media)']
handler.tags = ['ai']
handler.command = /^(toanime)$/i

module.exports = handler;

async function filters(imageurl, model="anime2d") {
  let tryng = 0;
  // Membuat request filters
  let ai = await fetch(`${global.apixtermurl}/api/img2img/filters?action=${model}&url=${imageurl}&key=${global.apixtermkey}`)
    .then(response => response.json());

  if (!ai.status) return ai;
  console.log(ai);

  while (tryng < 50) { // Maksimal 50 kali
    tryng += 1; // Menambahkan nilai tryng
    // Pengecekan status request
    let s = await fetch(`${global.apixtermurl}/api/img2img/filters/batchProgress?id=${ai.id}`)
      .then(response => response.json());

    if (s.status === 1) {
      console.log("Starting...");
    } else if (s.status === 2) {
      console.log("Processing...");
    } else if (s.status === 3) {
      return s; // Mengembalikan nilai s
    } else if (s.status === 4) {
      return m.reply("Maaf terjadi kesalahan. Coba gunakan gambar lain!");
    }

    await new Promise(resolve => setTimeout(resolve, 2000));
  }
}