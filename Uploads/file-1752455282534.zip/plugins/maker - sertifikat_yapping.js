const { createCanvas, loadImage } = require('canvas');
const axios = require('axios');

const handler = async (m, { conn, text, command }) => {
    if (!text) {
        return m.reply(`⚠️ Masukkan namanya bro!\n\nContoh:\n.yapping Rina Wahyu`);
    }

    try {
        // 🔧 Kirim reaksi gear saat mulai proses
        await conn.sendMessage(m.chat, { react: { text: "⚙️", key: m.key } });

        const canvasWidth = 1086;
        const canvasHeight = 768;
        const canvas = createCanvas(canvasWidth, canvasHeight);
        const ctx = canvas.getContext('2d');

        // Background dari GitHub
        const bgUrl = 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/src/Biru%20Pirus%20Abstrak%20Modern%20Sertifikat%20Penghargaan%20Juara.png';

        // Ambil background dari URL
        const response = await axios.get(bgUrl, { responseType: 'arraybuffer' });
        const bgImage = await loadImage(Buffer.from(response.data));
        ctx.drawImage(bgImage, 0, 0, canvasWidth, canvasHeight);

        // Tulis nama (diturunkan ke posisi Y = 320)
        ctx.font = 'bold 48px sans-serif';
        ctx.fillStyle = '#105E66';
        ctx.textAlign = 'center';
        ctx.fillText(text.toUpperCase(), canvasWidth / 2, 320);

        // Convert ke buffer dan kirim
        const buffer = canvas.toBuffer();
        await conn.sendMessage(m.chat, {
            image: buffer,
            caption: `🎖️ Sertifikat Top Yapping untuk: ${text}`
        }, { quoted: m });

        // ✅ Kirim reaksi centang hijau
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (err) {
        console.error('❌ Gagal buat sertifikat:', err);

        // ❌ Kirim reaksi gagal
        await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

        m.reply('😓 Gagal membuat sertifikat. Cek koneksi atau pastikan URL background bisa diakses.');
    }
};

handler.command = /^yapping$/i;
handler.tags = ['maker'];
handler.help = ['yapping <nama>'];
handler.limit = true;

module.exports = handler;
