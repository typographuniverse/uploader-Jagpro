const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');

const PINJAM_PATH = path.join(__dirname, '../lib/datapinjam.json');
if (!fs.existsSync(PINJAM_PATH)) fs.writeFileSync(PINJAM_PATH, JSON.stringify({ bank: 20000000000, users: {} }, null, 2));

const THUMBS = {
  info: 'https://raw.githubusercontent.com/Zephyr-crack/Zepyrzz/main/Uploads/file-1752028361888.jpeg',
  berhasil: 'https://raw.githubusercontent.com/Zephyr-crack/Zepyrzz/main/Uploads/file-1752028478540.jpeg',
  saldoHabis: 'https://raw.githubusercontent.com/Zephyr-crack/Zepyrzz/main/Uploads/file-1752028541279.jpeg',
  cicil: 'https://raw.githubusercontent.com/Zephyr-crack/Zepyrzz/main/Uploads/file-1752028541279.jpeg',
  warning: 'https://raw.githubusercontent.com/Zephyr-crack/Zepyrzz/main/Uploads/file-1752026518580.jpeg',
  bank: 'https://raw.githubusercontent.com/Zephyr-crack/Zepyrzz/main/Uploads/file-1752032353214.jpeg'
};

const ctxInfo = (title, larger, thumb) => ({
  externalAdReply: {
    title,
    body: '',
    thumbnailUrl: thumb,
    mediaType: 1,
    renderLargerThumbnail: larger
  }
});

const contextInfoError = async (title, msg, conn, sender) => {
  let ppUrl = global.thumb;
  try { ppUrl = await conn.profilePictureUrl(sender, 'image'); } catch (e) {}
  return {
    text: msg,
    contextInfo: {
      externalAdReply: {
        title,
        body: '',
        thumbnailUrl: ppUrl,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  };
};

let handler = async (m, { conn, text, command, args }) => {
  const data = JSON.parse(fs.readFileSync(PINJAM_PATH));
  const userId = m.sender;
  const userName = global.db.data.users[userId]?.name || await conn.getName(userId);
  const now = moment().tz('Asia/Jakarta');
  const isOwner = global.owner.some(([num]) => userId.startsWith(num));

  if (!global.db.data.users[userId]) {
    global.db.data.users[userId] = { money: 0, name: userName };
  }

  if (command === 'pinjam') {
    if (!args[0]) {
      return conn.sendMessage(m.chat, {
        text: `🏦 *BANK ${global.namebot}* 🏦\n\nHaii ${userName} Selamat Datang Di Bank *${global.namebot}*, Kami menyediakan pinjaman money tanpa bunga yang bisa kamu pakai untuk kebutuhan dalam bot ini...\n\n📝 *Command :*\n.pinjam <nominal> <hari>\n.cicil <nominal>\n.lunasi\n.pinjamanku\n\nMaksimal pinjaman 120 hari dan jika tidak dilunasi maka akan dikick dari grup.`,
        contextInfo: ctxInfo('🏦 BANK INFORMASI', true, THUMBS.info)
      }, { quoted: m });
    }

    let nominal = parseInt(args[0]);
    let days = parseInt(args[1]);
    if (isNaN(nominal) || isNaN(days)) {
      return conn.sendMessage(m.chat, await contextInfoError(
        '❌ Format Salah',
        'Format salah. Gunakan .pinjam <nominal> <hari>',
        conn,
        userId
      ), { quoted: m });
    }
    if (days > 120) {
      return conn.sendMessage(m.chat, await contextInfoError(
        '⛔ Maksimal 120 Hari',
        'Maksimal pinjaman hanya 120 hari',
        conn,
        userId
      ), { quoted: m });
    }
    if (nominal > data.bank) {
      return conn.sendMessage(m.chat, {
        text: `‼️ *SALDO TIDAK CUKUP*\n\n> saldo di bank ${global.namebot} tidak cukup.\n– Saldo Bank : ${data.bank.toLocaleString()}`,
        contextInfo: ctxInfo('‼️ SALDO BANK HABIS', true, THUMBS.saldoHabis)
      }, { quoted: m });
    }

    const jatuhTempo = now.clone().add(days, 'days').format('YYYY-MM-DD');
    if (!data.users[userId]) data.users[userId] = { hutang: 0, jatuhTempo: null };
    data.users[userId].hutang += nominal;
    data.users[userId].jatuhTempo = jatuhTempo;
    data.bank -= nominal;
    global.db.data.users[userId].money += nominal;
    fs.writeFileSync(PINJAM_PATH, JSON.stringify(data, null, 2));

    return conn.sendMessage(m.chat, {
      text: `✅ *BERHASIL MEMINJAM*\n\n> kamu telah meminjam money sebanyak ${nominal.toLocaleString()} dengan waktu ${days} hari\n\n– Nasabah : ${userName}\n– Hutang : ${data.users[userId].hutang.toLocaleString()}\n– Batas Pelunasan : ${jatuhTempo}\n– Saldo Kamu : ${global.db.data.users[userId].money.toLocaleString()}`,
      contextInfo: ctxInfo('✅ PEMINJAMAN BERHASIL', false, THUMBS.berhasil)
    }, { quoted: m });
  }

  if (command === 'cicil') {
    let cicil = parseInt(args[0]);
    if (isNaN(cicil) || cicil <= 0) {
      return conn.sendMessage(m.chat, await contextInfoError(
        '❌ Format Salah',
        'Format salah. Gunakan .cicil <nominal>',
        conn,
        userId
      ), { quoted: m });
    }
    if (!data.users[userId] || data.users[userId].hutang <= 0) {
      return conn.sendMessage(m.chat, await contextInfoError(
        '❌ Tidak Memiliki Hutang',
        'Kamu tidak memiliki hutang saat ini.',
        conn,
        userId
      ), { quoted: m });
    }
    if (global.db.data.users[userId].money < cicil) {
      return conn.sendMessage(m.chat, await contextInfoError(
        '⛔ Saldo Tidak Cukup',
        'Saldo kamu tidak cukup untuk membayar cicilan.',
        conn,
        userId
      ), { quoted: m });
    }

    data.users[userId].hutang -= cicil;
    data.bank += cicil;
    global.db.data.users[userId].money -= cicil;
    if (data.users[userId].hutang <= 0) {
      data.users[userId].hutang = 0;
      data.users[userId].jatuhTempo = null;
    }
    fs.writeFileSync(PINJAM_PATH, JSON.stringify(data, null, 2));

    return conn.sendMessage(m.chat, {
      text: `✅ *BERHASIL MENYICIL*\n\n> kamu menyicil sebanyak ${cicil.toLocaleString()}\n\n– Nasabah : ${userName}\n– Sisa Hutang : ${data.users[userId].hutang.toLocaleString()}\n– Batas Pelunasan : ${data.users[userId].jatuhTempo || '–'}\n– Saldo Kamu : ${global.db.data.users[userId].money.toLocaleString()}`,
      contextInfo: ctxInfo('✅ CICILAN DIBAYARKAN', false, THUMBS.cicil)
    }, { quoted: m });
  }

  if (command === 'lunasi') {
    if (!data.users[userId] || data.users[userId].hutang <= 0) {
      return conn.sendMessage(m.chat, await contextInfoError(
        '❌ Tidak Memiliki Hutang',
        'Kamu tidak memiliki hutang yang perlu dilunasi.',
        conn,
        userId
      ), { quoted: m });
    }
    const jumlahLunas = data.users[userId].hutang;
    if (global.db.data.users[userId].money < jumlahLunas) {
      return conn.sendMessage(m.chat, await contextInfoError(
        '⛔ Saldo Tidak Cukup',
        'Saldo kamu tidak cukup untuk melunasi hutang.',
        conn,
        userId
      ), { quoted: m });
    }

    data.bank += jumlahLunas;
    global.db.data.users[userId].money -= jumlahLunas;
    data.users[userId].hutang = 0;
    data.users[userId].jatuhTempo = null;
    fs.writeFileSync(PINJAM_PATH, JSON.stringify(data, null, 2));

    return conn.sendMessage(m.chat, {
      text: `✅ *BERHASIL MELUNASI*\n\n> kamu telah melunasi seluruh hutang sebesar ${jumlahLunas.toLocaleString()}\n\n– Nasabah : ${userName}\n– Hutang : 0\n– Status : LUNAS ✨\n– Saldo Kamu : ${global.db.data.users[userId].money.toLocaleString()}`,
      contextInfo: ctxInfo('✅ HUTANG LUNAS', false, THUMBS.cicil)
    }, { quoted: m });
  }

  if (command === 'pinjamanku') {
    const userData = data.users[userId];
    if (!userData || userData.hutang <= 0) {
      return conn.sendMessage(m.chat, await contextInfoError(
        '❌ Tidak Memiliki Pinjaman',
        'Kamu tidak memiliki pinjaman aktif.',
        conn,
        userId
      ), { quoted: m });
    }
    return conn.sendMessage(m.chat, {
      text: `📄 *PINJAMAN KAMU*\n\n– Nasabah : ${userName}\n– Hutang : ${userData.hutang.toLocaleString()}\n– Batas Pelunasan : ${userData.jatuhTempo}\n– Saldo Kamu : ${global.db.data.users[userId].money.toLocaleString()}`,
      contextInfo: ctxInfo('📄 CEK PINJAMAN', false, THUMBS.info)
    }, { quoted: m });
  }

  if (command === 'saldobank') {
    if (!isOwner) {
      return conn.sendMessage(m.chat, await contextInfoError(
        '⛔ Akses Ditolak',
        'Fitur ini hanya untuk owner!',
        conn,
        userId
      ), { quoted: m });
    }
    if (args[0] === 'isi') {
      if (args[1] === 'max') {
        data.bank = 20000000000;
      } else {
        let tambah = parseInt(args[1]);
        if (isNaN(tambah)) {
          return conn.sendMessage(m.chat, await contextInfoError(
            '❌ Format Salah',
            'Masukkan nominal angka!',
            conn,
            userId
          ), { quoted: m });
        }
        data.bank += tambah;
      }
      fs.writeFileSync(PINJAM_PATH, JSON.stringify(data, null, 2));
      return conn.sendMessage(m.chat, {
        text: `✅ *SALDO BANK DITAMBAH*\n\n– Saldo sekarang: ${data.bank.toLocaleString()}`,
        contextInfo: ctxInfo('✅ ISI SALDO BANK', false, THUMBS.bank)
      }, { quoted: m });
    } else if (args[0] === 'cek') {
      return conn.sendMessage(m.chat, {
        text: `🏦 *SALDO BANK*\n\n– Saldo sekarang: ${data.bank.toLocaleString()}`,
        contextInfo: ctxInfo('🏦 CEK SALDO BANK', false, THUMBS.bank)
      }, { quoted: m });
    } else {
      return conn.sendMessage(m.chat, {
        text: 'Gunakan: .saldobank isi <nominal/max> atau .saldobank cek',
        contextInfo: ctxInfo('ℹ️ FORMAT SALDOBANK', false, THUMBS.bank)
      }, { quoted: m });
    }
  }
};

handler.help = ['pinjam', 'cicil', 'lunasi', 'pinjamanku', 'saldobank isi <nominal/max>', 'saldobank cek'];
handler.tags = ['rpg'];
handler.command = /^pinjam|cicil|lunasi|pinjamanku|saldobank$/i;
handler.group = true;

module.exports = handler;