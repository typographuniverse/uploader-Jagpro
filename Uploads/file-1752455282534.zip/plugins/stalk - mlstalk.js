let handler = async (m, { conn, text, usedPrefix, command }) => {
	if (!text) return conn.reply(m.chat, `• *Example :* ${usedPrefix + command} 84830127/2169`, m)
	let kemii = await fetch(`https://vapis.my.id/api/ml-stalk?id=${text.split('/')[0]}&zoneid=${text.split('/')[1]}`)
	let hasil = await kemii.json()
	conn.reply(m.chat, formatProfileData(hasil), m)
   console.log(hasil)
}
handler.help = ['mlstalk *<text>*']
handler.tags = ['stalk']
handler.command = /^(mlstalk)$/i
handler.limit = true

module.exports = handler

function formatProfileData(data) {
  if (!data || !data.status || !data.data) return "Data tidak valid.";

  const { data: details } = data.data;

  return `✨ *Profil Akun Game* ✨

🔹 *Game*: ${details.product?.gameName || "N/A"}
📛 *Nama Pemain*: ${details.userNameGame || "N/A"}
🆔 *Game ID*: ${details.gameId || "N/A"}
🌍 *Zone ID*: ${details.zoneId || "N/A"}

🎮 *Item Terakhir Dibeli*: ${details.item?.name || "Tidak ada"}
🔹 *Harga*: Rp${details.item?.price?.toLocaleString('id-ID') || "N/A"}

🖼️ *Icon Game*: ${details.product?.image || "N/A"}

🛡️ Profil akun telah berhasil ditampilkan.`;
}