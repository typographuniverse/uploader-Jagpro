const axios = require('axios');
const cheerio = require('cheerio');

// Handler utama
let handler = async (m, { conn, text, command }) => {
  try {
    if (!text) {
      return m.reply(`Please provide a dish name to search!\n\nExample:\n.${command} Nasi Goreng`);
    }

    m.reply('Searching for the recipe, please wait...');

    const results = await resep(text);

    if (results.length === 0) {
      return m.reply('No recipes found for the given dish name.');
    }

    let message = `
🍽️ *Recipes Found!* 🍽️

`;
    results.forEach((res, index) => {
      message += `
🔹 *Recipe ${index + 1}*
- 🍲 Name: ${res.namaResep}
- ⏲️ Cooking Time: ${res.waktuMasak}
- 👨‍🍳 Created by: ${res.pembuat}
- 🔗 [View Recipe](${res.linkResep})
`;
    });

    await conn.sendMessage(m.chat, { text: message, footer: namebot }, { quoted: m });
  } catch (error) {
    console.error(error);
    m.reply("An error occurred: " + error.message);
  }
};

handler.help = ["resepi"];
handler.tags = ["internet"];
handler.command = /^(resepi)$/i;

module.exports = handler;

// Function to search for recipes
async function resep(makanan) {
  let BASE = `https://cookpad.com/id/cari/${encodeURIComponent(makanan)}`;
  let { data } = await axios.get(BASE);

  let $ = cheerio.load(data);
  let hasil = [];

  $("li[data-search-tracking-target='result']").each((i, el) => {
    let namaResep = $(el).find("h2 a").text().trim();
    let linkResep = "https://cookpad.com" + $(el).find("h2 a").attr("href");
    let waktuMasak = $(el).find(".mise-icon-time + .mise-icon-text").text().trim();
    let pembuat = $(el).find(".flex.items-center span.text-cookpad-gray-600").text().trim();

    hasil.push({ namaResep, linkResep, waktuMasak, pembuat });
  });

  return hasil;
}