// 📝 plugin tools - copyuser

// 📝 plugin tools - copyuser

let handler = async (m, { conn, text }) => {
  let number;

  // Ambil daftar user yang di-tag dari text
  const mentioned = m.mentionedJid && m.mentionedJid.length > 0 ? m.mentionedJid[0] : null;

  // Cek apakah ada tag
  if (mentioned) {
    // Ambil nomor dari user yang di-tag
    number = mentioned.replace(/[^0-9]/g, '');
  } else {
    // Jika tidak ada tag
    return m.reply('‼️ *TAG USERNYA*\n\n> Contoh : .copy @armancuki');
  }

  // Pastikan nomor valid (tidak kosong dan hanya angka)
  if (!number || number.length < 5) {
    return m.reply('Gagal mendapatkan nomor! Pastikan Anda menandai user dengan nomor WhatsApp yang valid.');
  }

  const interactiveMessage = {
    text: `\n 🪀 nomor user\n ╰┈➤ *${number}*`,
    title: "✅ *BERHASIL COPY NOMOR*",
    footer: "\nᴛᴇᴋᴀɴ ᴛᴏᴍʙᴏʟ ᴅɪʙᴀᴡᴀʜ ɪɴɪ ᴜɴᴛᴜᴋ ᴍᴇɴʏᴀʟɪɴ ɴᴏᴍᴏʀ.",
    interactiveButtons: [
      {
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
          display_text: "📋 SALIN NOMOR",
          id: "copy_number",
          copy_code: number
        })
      }
    ]
  };

  // Perbaikan: Hapus duplikat 'conn'
  await conn.sendMessage(m.chat, interactiveMessage, { quoted: m });
};

handler.help = ['copy <@user>'];
handler.tags = ['tools'];
handler.command = /^copy$/i;

module.exports = handler;