const axios = require('axios')

class TempMail {
  constructor() {
    this.cookie = null
    this.baseUrl = 'https://tempmail.so'
  }

  async updateCookie(response) {
    if (response.headers['set-cookie']) {
      this.cookie = response.headers['set-cookie'].join('; ')
    }
  }

  async makeRequest(url) {
    const response = await axios({
      method: 'GET',
      url,
      headers: {
        'accept': 'application/json',
        'cookie': this.cookie || '',
        'referer': this.baseUrl + '/',
        'x-inbox-lifespan': '600',
        'sec-ch-ua': '"Not A(Brand";v="8", "Chromium";v="132"',
        'sec-ch-ua-mobile': '?1'
      }
    })

    await this.updateCookie(response)
    return response
  }

  async initialize() {
    const response = await axios.get(this.baseUrl, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
        'sec-ch-ua': '"Not A(Brand";v="8", "Chromium";v="132"'
      }
    })
    await this.updateCookie(response)
    return this
  }

  async getInbox() {
    const url = `${this.baseUrl}/us/api/inbox?requestTime=${Date.now()}&lang=us`
    const response = await this.makeRequest(url)
    return response.data
  }

  async getMessage(messageId) {
    const url = `${this.baseUrl}/us/api/inbox/messagehtmlbody/${messageId}?requestTime=${Date.now()}&lang=us`
    const response = await this.makeRequest(url)
    return response.data
  }
}

async function createTempMail() {
  const mail = new TempMail()
  await mail.initialize()
  return mail
}

const handler = async (m, { conn }) => {
  try {
    const mail = await createTempMail()
    const inbox = await mail.getInbox()

    if (!inbox.data?.name) throw new Error('Gagal mendapatkan email sementara.')

    const emailInfo = `🕑 *Temporary Email*\n\n📧 *Email:* ${inbox.data.name}\n⏳ *Expired:* 10 Menit\n📥 *Inbox:* ${inbox.data.inbox?.length || 0} Pesan\n\n> Email akan otomatis dihapus setelah 10 menit.`
    await conn.sendMessage(m.chat, { text: emailInfo }, { quoted: m })

    const state = {
      processedMessages: new Set(),
      isRunning: true
    }

    const processInbox = async () => {
      if (!state.isRunning) return

      try {
        const updatedInbox = await mail.getInbox()
        const messages = updatedInbox.data?.inbox || []

        const sorted = messages.sort((a, b) => new Date(b.date) - new Date(a.date))

        for (const msg of sorted) {
          if (!state.processedMessages.has(msg.id)) {
            const detail = await mail.getMessage(msg.id)
            const cleanContent = detail.data?.html
              ? detail.data.html.replace(/<[^>]*>?/gm, '').trim()
              : 'Tidak ada isi pesan.'

            const messageInfo = `📩 *Pesan Baru!*\n\n👤 *From:* ${msg.from || 'Tidak diketahui'}\n📝 *Subject:* ${msg.subject || 'Tidak ada'}\n\n📨 *Isi Pesan:*\n${cleanContent}`
            await conn.sendMessage(m.chat, { text: messageInfo }, { quoted: m })

            state.processedMessages.add(msg.id)
          }
        }
      } catch (err) {
        console.error('Gagal cek inbox:', err)
      }
    }

    await processInbox()
    const interval = setInterval(processInbox, 10000)

    setTimeout(() => {
      state.isRunning = false
      clearInterval(interval)
      conn.sendMessage(m.chat, { text: '⏱️ Email sementara telah dihapus setelah 10 menit.' }, { quoted: m })
    }, 600000)

  } catch (error) {
    const errMsg = error instanceof Error ? error.message : String(error)
    await conn.reply(m.chat, `❌ Error: ${errMsg}`, m)
  }
}

handler.help = ['tempmail']
handler.tags = ['tools']
handler.command = /^tempmail$/i
handler.register = true

module.exports = handler
