// 📝 plugin group - afkback

// 📝 plugin group - afkback

module.exports = {
  async before(m, { conn }) {
    let chat = global.db.data.chats[m.chat] || {};
    chat.afk = chat.afk || {};

    let ppUrl = global.thumb;
    try {
      ppUrl = await conn.profilePictureUrl(m.sender, 'image');
    } catch (e) {}

    // Detect any user activity (text, sticker, reaction, etc.)
    if (chat.afk[m.sender] && chat.afk[m.sender].time > -1 && (m.message || m.msg)) {
      let afkTime = chat.afk[m.sender].time;
      let reason = chat.afk[m.sender].reason || 'tanpa alasan yang jelas';
      let duration = clockString(new Date() - afkTime);
      let userName = conn.getName(m.sender) || 'Pengguna';

      await conn.sendMessage(m.chat, {
        text: `🥳 *Kamu telah kembali dari AFK*\n\n– Nama: ${userName}\n– Alasan: ${reason}\n– Selama: ${duration}`,
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            title: '⛔ PENGGUNA TELAH KEMBALI',
            body: '',
            thumbnailUrl: ppUrl,
            mediaType: 1,
            renderLargerThumbnail: false,
          },
        },
      }, { quoted: m });

      // Clear AFK status for this user in this group
      delete chat.afk[m.sender];
      global.db.data.chats[m.chat] = chat;
    }

    // Check for mentioned or quoted AFK users
    let jids = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];
    for (let jid of jids) {
      if (!chat.afk[jid]) continue;
      let afkTime = chat.afk[jid].time;
      if (!afkTime || afkTime < 0) continue;
      let reason = chat.afk[jid].reason || 'tanpa alasan yang jelas';
      let duration = clockString(new Date() - afkTime);
      let userName = conn.getName(jid) || 'Pengguna';

      try {
        ppUrl = await conn.profilePictureUrl(jid, 'image');
      } catch (e) {}

      // Delete the message if in a group
      if (m.isGroup) {
        await m.delete();
      }

      await conn.sendMessage(m.chat, {
        text: `*‼️ Jangan tag atau reply dia! 😡*\n\n– Nama: ${userName}\n– Status: Sedang AFK\n– Alasan: ${reason}\n– Sejak: ${duration}`,
        contextInfo: {
          mentionedJid: [jid],
          externalAdReply: {
            title: '⛔ PENGGUNA SEDANG AFK',
            body: '',
            thumbnailUrl: ppUrl,
            mediaType: 1,
            renderLargerThumbnail: false,
          },
        },
      }, { quoted: m });
    }
  },
};

function clockString(ms) {
  if (isNaN(ms) || ms < 0) return '00:00:00';
  let h = Math.floor(ms / 3600000);
  let m = Math.floor(ms / 60000) % 60;
  let s = Math.floor(ms / 1000) % 60;
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}