/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/


// Plugin untuk mengelola panel Pterodactyl: membuat server, admin, mencari user, dan mengelola akses grup
const fs = require('fs');
const fetch = require('node-fetch');
const moment = require('moment-timezone');
const crypto = require('crypto');
const path = require('path');
const ssh2 = require('ssh2');


// Path untuk menyimpan data grup dan kadaluarsa
const databaseDir = path.resolve(__dirname, '../database');
const expiredPath = path.resolve(databaseDir, '../database/expired.json');

// Fungsi untuk menginisialisasi direktori dan file
function initializeFiles() {
  try {
    if (!fs.existsSync(databaseDir)) {
      fs.mkdirSync(databaseDir, { recursive: true });
      console.log('Direktori database dibuat:', databaseDir);
    }
    if (!fs.existsSync(expiredPath)) {
      fs.writeFileSync(expiredPath, JSON.stringify([], null, 2));
      console.log('File expired.json dibuat:', expiredPath);
    }
  } catch (e) {
    console.error('Gagal menginisialisasi file:', e);
    throw new Error('Gagal menginisialisasi file: ' + e.message);
  }
}

// Panggil inisialisasi saat plugin dimuat
initializeFiles();


// Fungsi untuk memvalidasi respons API
async function validateResponse(response, url) {
  if (!response.ok) {
    const text = await response.text();
    console.error(`Respons gagal [${response.status}]: ${text.slice(0, 200)}`);
    if (response.status === 403) throw new Error('Akses ditolak (403): API key salah atau tidak diizinkan.');
    if (response.status === 404) throw new Error('Endpoint tidak ditemukan (404): Periksa URL API.');
    throw new Error(`HTTP ${response.status}: ${text.slice(0, 100)}... di ${url}`);
  }
  const contentType = response.headers.get('content-type');
  if (!contentType || !contentType.includes('application/json')) {
    const text = await response.text();
    console.error(`Respons bukan JSON: ${text.slice(0, 200)}... di ${url}`);
    throw new Error(`Respons bukan JSON: ${text.slice(0, 100)}... di ${url}`);
  }
  return response;
}

let handler = async (m, { conn, text, command, args, isPremium }) => {
  // Fungsi untuk membalas pesan
  const Reply = (msg) => conn.reply(m.chat, msg, m);
  // Pesan peringatan khusus untuk owner berdasarkan settings.js
  const mess = { owner: `‼️ Perintah ini khusus untuk ${global.nameowner}!` };

  // Memeriksa apakah pengguna adalah owner
  const isOwner = global.owner.some(([num]) => num === m.sender.split('@')[0]) || m.sender.split('@')[0] === global.rowner;

  // Mendapatkan nomor dari tag, quote, atau teks
  let who;
  if (m.isGroup) {
    who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.chat;
  } else {
    who = m.chat;
  }

  switch (command.toLowerCase()) {
    case '1gb': case '2gb': case '3gb': case '4gb': case '5gb':
case '6gb': case '7gb': case '8gb': case '9gb': case '10gb':
case 'unlimited': case 'unli': {
  if (!isOwner && !isPremium) return Reply(mess.owner);
  if (!text) return Reply('‼️ *FORMAT TIDAK LENGKAP*\n\n– Contoh penggunaan :\n> .unli v2 bendot\n> .unli v2 bendot|62×××××××××××');

  let versi = 'v1';
  let input = text.trim();
  const versionMatch = input.match(/^(v[1-5])\s+/i);
  if (versionMatch) {
    versi = versionMatch[1].toLowerCase();
    input = input.replace(versionMatch[0], '').trim();
  }

  let [usernameRaw, nomorRaw] = input.split('|');
  if (!usernameRaw) return Reply('‼️ *USERNAME DIPERLUKAN*\n\n> Harap masukkan username untuk membuat panel.');
  const username = usernameRaw.toLowerCase().replace(/\s/g, '');
  const nomor = nomorRaw ? nomorRaw.replace(/\D/g, '') + '@s.whatsapp.net' : null;

  const versiConf = {
    v1: { domain: global.domain, apikey: global.apikey, loc: global.loc, egg: global.egg, nestid: global.nestid },
    v2: { domain: global.domainV2, apikey: global.apikeyV2, loc: global.locV2, egg: global.eggV2, nestid: global.nestidV2 },
    v3: { domain: global.domainV3, apikey: global.apikeyV3, loc: global.locV3, egg: global.eggV3, nestid: global.nestidV3 },
    v4: { domain: global.domainV4, apikey: global.apikeyV4, loc: global.locV4, egg: global.eggV4, nestid: global.nestidV4 },
    v5: { domain: global.domainV5, apikey: global.apikeyV5, loc: global.locV5, egg: global.eggV5, nestid: global.nestidV5 }
  };

  const conf = versiConf[versi];
  if (!conf) return Reply('‼️ *VERSI PANEL TIDAK VALID*\n\n> Gunakan v1 - v5');

  const specs = {
    '1gb': { ram: 1000, disk: 1000, cpu: 40 },
    '2gb': { ram: 2000, disk: 1500, cpu: 60 },
    '3gb': { ram: 3000, disk: 2500, cpu: 80 },
    '4gb': { ram: 4000, disk: 3500, cpu: 100 },
    '5gb': { ram: 5000, disk: 4500, cpu: 120 },
    '6gb': { ram: 6000, disk: 5500, cpu: 140 },
    '7gb': { ram: 7000, disk: 6500, cpu: 160 },
    '8gb': { ram: 8000, disk: 7500, cpu: 180 },
    '9gb': { ram: 9000, disk: 8500, cpu: 200 },
    '10gb': { ram: 10000, disk: 9500, cpu: 220 },
    'unlimited': { ram: 0, disk: 0, cpu: 0 },
    'unli': { ram: 0, disk: 0, cpu: 0 }
  }[command];

  const email = `${username}@gmail.com`;
  const password = username + Math.floor(Math.random() * 1000);
  const name = username;

  try {
    // Membuat user di panel
    const userUrl = `${conf.domain}/api/application/users`;
    console.log('Mengakses URL:', userUrl);
    let userRes = await fetch(userUrl, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${conf.apikey}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: name,
        last_name: 'Bot',
        password,
        language: 'en'
      })
    });
    userRes = await validateResponse(userRes, userUrl);
    let user = await userRes.json();
    if (user.errors) throw `Gagal membuat user: ${user.errors[0].detail}`;

    // Mendapatkan detail egg
    const eggUrl = `${conf.domain}/api/application/nests/${conf.nestid}/eggs/${conf.egg}`;
    console.log('Mengakses URL:', eggUrl);
    let eggRes = await fetch(eggUrl, {
      headers: {
        'Accept': 'application/json',
        Authorization: `Bearer ${conf.apikey}`
      }
    });
    eggRes = await validateResponse(eggRes, eggUrl);
    let eggDetail = await eggRes.json();
    if (eggDetail.errors) throw `Gagal mengambil egg: ${eggDetail.errors[0].detail}`;

    // Membuat server
    const serverUrl = `${conf.domain}/api/application/servers`;
    console.log('Mengakses URL:', serverUrl);
    let serverRes = await fetch(serverUrl, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${conf.apikey}`
      },
      body: JSON.stringify({
        name,
        user: user.attributes.id,
        egg: parseInt(conf.egg),
        docker_image: eggDetail.attributes.docker_image,
        startup: eggDetail.attributes.startup,
        environment: {
          INST: 'npm',
          CMD_RUN: 'npm start',
          AUTO_UPDATE: '0',
          USER_UPLOAD: '0'
        },
        limits: {
          memory: specs.ram,
          swap: 0,
          disk: specs.disk,
          io: 500,
          cpu: specs.cpu
        },
        feature_limits: {
          databases: 3,
          backups: 3,
          allocations: 2
        },
        deploy: {
          locations: [parseInt(conf.loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    serverRes = await validateResponse(serverRes, serverUrl);
    let server = await serverRes.json();
    if (server.errors) throw `Gagal membuat server: ${server.errors[0].detail}`;

    // Menyimpan data kadaluarsa
    const expiredList = JSON.parse(fs.readFileSync(expiredPath));
    const waktuKadaluarsa = Date.now() + 30 * 24 * 60 * 60 * 1000;
    expiredList.push({
      username,
      user_id: user.attributes.id,
      server_id: server.attributes.id,
      versi,
      nomor: nomor || m.chat,
      tanggal: Date.now(),
      kadaluarsa: waktuKadaluarsa
    });
    fs.writeFileSync(expiredPath, JSON.stringify(expiredList, null, 2));

    // Format output
    const kadaluarsaStr = moment(waktuKadaluarsa).tz('Asia/Jakarta').format('DD-MM-YYYY HH:mm');
    const hasil = `🛍️ *DATA AKUN PANEL KAMU*\n\n` +
                  `⎙ *USERNAME*\n> ╰┈➤ ${user.attributes.username}\n` +
                  `⎙ *PASSWORD*\n> ╰┈➤ ${password}\n\n` +
                  `💾 *RAM :* ${specs.ram / 1000 || 'Unlimited'} GB\n` +
                  `🗂️ *DISK :* ${specs.disk / 1000 || 'Unlimited'} GB\n` +
                  `⚙️ *CPU :* ${specs.cpu || 'Unlimited'}%\n\n` +
                  `⎙ *LINK PANEL*\n╰┈➤ ${conf.domain}\n` +
                  `⎙ *VERSI PANEL*\n╰┈➤ ${versi.toUpperCase()}\n` +
                  `⎙ *EXPIRED*\n╰┈➤ ${kadaluarsaStr}\n\n` +
                  `🔗 *GRUP PANEL*\n╰┈➤ ${panelgrup}\n\n` +
                  `📝 *NOTE :*\n> JANGAN BAGIKAN DATA PANEL KAMU KE ORANG LAIN, DAN SIMPAN DATA PANEL SEBAIK MUNGKIN KARENA OWNER HANYA MENGIRIM DATA PANEL SATU KALI SAJA!!`;

    // Mengirim hasil
    fs.writeFileSync('akunpanel.txt', hasil);
    if (nomor) {
      // Kirim ke nomor tujuan jika ada
      await conn.sendMessage(nomor, {
        document: fs.readFileSync('akunpanel.txt'),
        fileName: 'akunpanel.txt',
        mimetype: 'text/plain',
        caption: hasil
      }, { quoted: m });
      // Konfirmasi ke grup
      const caption = `✅ *BERHASIL MEMBUAT AKUN PANEL*\n\n– Akun panel telah dibuat dan dikirim ke private chat: @${nomor.split('@')[0]}`;
      await conn.reply(m.chat, caption, m, {
        mentions: conn.parseMention(caption)
      });
    } else {
      // Reply langsung di chat room jika tidak ada nomor
      await conn.sendMessage(m.chat, {
        document: fs.readFileSync('akunpanel.txt'),
        fileName: 'akunpanel.txt',
        mimetype: 'text/plain',
        caption: hasil
      }, { quoted: m });
      // Konfirmasi ke grup
      const caption = `✅ *BERHASIL MEMBUAT AKUN PANEL*\n\n– Akun panel telah dibuat dan dikirim di chat ini.`;
      await conn.reply(m.chat, caption, m);
    }
    fs.unlinkSync('akunpanel.txt');
  } catch (e) {
    console.error('Error:', e);
    Reply(`‼️ Gagal membuat panel: ${e.message}`);
  }
  break;
}

    case 'cadmin': {
      if (!isOwner) return Reply(mess.owner);
      if (!text) return Reply(`Format:\n.cadmin [versi] [nomor/mention] [username]\n\n` +
                            `Contoh:\n.cadmin v2 +628xxx Biyu\n.cadmin @tag Biyu\n.cadmin Biyu`);

      let versi = 'v1';
      let nomor = who;
      let raw = text.trim();
      let versiMatch = raw.match(/^(v[1-5])\s+/i);
      if (versiMatch) {
        versi = versiMatch[1].toLowerCase();
        raw = raw.replace(versiMatch[0], '').trim();
      }

      if (m.mentionedJid && m.mentionedJid[0]) {
        nomor = m.mentionedJid[0];
        raw = raw.replace(/@(\d{5,16})/, '').trim();
      } else {
        let noMatch = raw.match(/^(\+?0?8[\d\s\-]{7,20}|\+?62[\d\s\-]{7,20})\s+/);
        if (noMatch) {
          let no = noMatch[1].replace(/[\s\-]/g, '').replace(/^0/, '62').replace(/^\+/, '');
          nomor = no + '@s.whatsapp.net';
          raw = raw.replace(noMatch[0], '').trim();
        }
      }

      let username = raw.toLowerCase().replace(/\s+/g, '');
      if (!username) return Reply('‼️ Harap masukkan username.');
      let email = username + '@gmail.com';
      let name = capital(username);
      let password = username + crypto.randomBytes(2).toString('hex');

      let config = {
        v1: { domain: global.domain, apikey: global.apikey },
        v2: { domain: global.domainV2, apikey: global.apikeyV2 },
        v3: { domain: global.domainV3, apikey: global.apikeyV3 },
        v4: { domain: global.domainV4, apikey: global.apikeyV4 },
        v5: { domain: global.domainV5, apikey: global.apikeyV5 }
      }[versi];

      try {
        const adminUrl = `${config.domain}/api/application/users`;
        console.log('Mengakses URL:', adminUrl);
        let res = await fetch(adminUrl, {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${config.apikey}`
          },
          body: JSON.stringify({
            email,
            username,
            first_name: name,
            last_name: 'Admin',
            root_admin: true,
            language: 'en',
            password
          })
        });
        res = await validateResponse(res, adminUrl);
        let data = await res.json();
        if (data.errors) throw `Gagal membuat admin: ${JSON.stringify(data.errors[0], null, 2)}`;

        let user = data.attributes;
        let teks = `*Data Akun Admin Panel ${versi.toUpperCase()}*\n\n` +
                   `*📡 ID:* ${user.id}\n` +
                   `*👤 Username:* ${user.username}\n` +
                   `*🔐 Password:* ${password}\n` +
                   `*🌐 Domain:* ${config.domain}\n\n` +
                   `*Syarat & Ketentuan:*\n` +
                   `• Akun expired dalam 1 bulan\n` +
                   `• Jangan asal hapus server!\n` +
                   `• Ketahuan maling? Auto ban + delete akun!`;

        fs.writeFileSync('./akunpanel.txt', teks);
        await conn.sendMessage(nomor, {
          document: fs.readFileSync('./akunpanel.txt'),
          fileName: 'akunpanel.txt',
          mimetype: 'text/plain',
          caption: teks
        }, { quoted: m });
        fs.unlinkSync('./akunpanel.txt');

        const caption = `✅ File akun admin berhasil dikirim ke @${nomor.split('@')[0]}`;
        await conn.reply(m.chat, caption, m, {
          mentions: conn.parseMention(caption)
        });
        if (m.isGroup) Reply(`✅ *Admin ${versi.toUpperCase()} berhasil dibuat!*\nData akun dikirim ke private @${nomor.split('@')[0]}`);
      } catch (e) {
        console.error('Error:', e);
        Reply(`‼️ Gagal membuat admin: ${e.message}`);
      }
      break;
    }

    case 'searchuser': {
      if (!isOwner && !isPremium) return Reply(mess.owner);
      if (!text.includes('|')) return Reply(`Format salah!\nGunakan: .searchuser v1|email/username`);

      let [version, keyword] = text.split('|').map(v => v.trim().toLowerCase());
      let config = {
        v1: { domain: global.domain, apikey: global.apikey },
        v2: { domain: global.domainV2, apikey: global.apikeyV2 },
        v3: { domain: global.domainV3, apikey: global.apikeyV3 },
        v4: { domain: global.domainV4, apikey: global.apikeyV4 },
        v5: { domain: global.domainV5, apikey: global.apikeyV5 }
      };

      if (!config[version]) return Reply('Versi tidak valid. Gunakan v1 - v5.');
      let { domain, apikey } = config[version];

      try {
        let users = [], page = 1;
        while (true) {
          const userUrl = `${domain}/api/application/users?page=${page}`;
          console.log('Mengakses URL:', userUrl);
          let res = await fetch(userUrl, {
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              Authorization: `Bearer ${apikey}`
            }
          });
          res = await validateResponse(res, userUrl);
          let json = await res.json();
          if (!json.data || json.data.length === 0) break;
          users = users.concat(json.data);
          if (json.meta.pagination.current_page >= json.meta.pagination.total_pages) break;
          page++;
        }

        let foundUser = users.find(u =>
          u.attributes.email.toLowerCase().includes(keyword) ||
          u.attributes.username.toLowerCase().includes(keyword)
        );
        if (!foundUser) return Reply(`User dengan keyword *${keyword}* tidak ditemukan.`);

        let userId = foundUser.attributes.id;
        let infoUser = `*✦ User Info [${version.toUpperCase()}]*\n\n` +
                       `• *ID:* ${userId}\n` +
                       `• *Nama:* ${foundUser.attributes.first_name}\n` +
                       `• *Username:* ${foundUser.attributes.username}\n` +
                       `• *Email:* ${foundUser.attributes.email}\n` +
                       `• *Admin:* ${foundUser.attributes.root_admin ? 'Ya' : 'Tidak'}\n` +
                       `• *Tgl Buat:* ${foundUser.attributes.created_at.split('T')[0]}\n\n`;

        let allServers = [], pageSrv = 1;
        while (true) {
          const serverUrl = `${domain}/api/application/servers?page=${pageSrv}`;
          console.log('Mengakses URL:', serverUrl);
          let resSrv = await fetch(serverUrl, {
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              Authorization: `Bearer ${apikey}`
            }
          });
          resSrv = await validateResponse(resSrv, serverUrl);
          let srvJson = await resSrv.json();
          if (!srvJson.data || srvJson.data.length === 0) break;
          allServers = allServers.concat(srvJson.data);
          if (srvJson.meta.pagination.current_page >= json.meta.pagination.total_pages) break;
          pageSrv++;
        }

        let userServers = allServers.filter(s => s.attributes.user === userId);
        if (userServers.length === 0) {
          infoUser += '*Server:* Tidak ada server.';
        } else {
          infoUser += `*✦ Server (${userServers.length} total):*\n`;
          for (let s of userServers) {
            infoUser += `• *Name:* ${s.attributes.name}\n  *RAM:* ${s.attributes.limits.memory} MB\n  *Disk:* ${s.attributes.limits.disk} MB\n  *Status:* ${s.attributes.suspended ? 'Suspended' : 'Aktif'}\n\n`;
          }
        }
        Reply(infoUser);
      } catch (e) {
        console.error('Error:', e);
        Reply(`‼️ Gagal mencari user: ${e.message}`);
      }
      break;
    }

    case 'listadmin': {
      if (!isOwner && !isPremium) return Reply(mess.owner);
      let version = args[0]?.toLowerCase().trim() || '';
      let page = parseInt(args[1]) || 1;

      if (!version) {
        let instruksi = `╔══✪「 *INSTRUKSI LIST ADMIN* 」✪══\n` +
                        `║ Untuk melihat daftar admin tiap versi panel, gunakan format:\n` +
                        `║ \n` +
                        `║ ◦ *.listadmin v1*\n` +
                        `║ ◦ *.listadmin v2*\n` +
                        `║ ◦ *.listadmin v3*\n` +
                        `║ ◦ *.listadmin v4*\n` +
                        `║ ◦ *.listadmin v5*\n` +
                        `║ \n` +
                        `║ Tambahkan nomor halaman jika ingin lihat data lebih lanjut:\n` +
                        `║ Contoh: *.listadmin v1 2*\n` +
                        `╚═══════════════════════════════`;
        return Reply(instruksi);
      }

      let config = {
        v1: { domain: global.domain, apikey: global.apikey },
        v2: { domain: global.domainV2, apikey: global.apikeyV2 },
        v3: { domain: global.domainV3, apikey: global.apikeyV3 },
        v4: { domain: global.domainV4, apikey: global.apikeyV4 },
        v5: { domain: global.domainV5, apikey: global.apikeyV5 }
      };

      if (!config[version]) return Reply('Versi tidak valid. Gunakan v1 - v5.');
      let { domain, apikey } = config[version];

      try {
        const adminUrl = `${domain}/api/application/users?page=${page}`;
        console.log('Mengakses URL:', adminUrl);
        let cek = await fetch(adminUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apikey}`
          }
        });
        cek = await validateResponse(cek, adminUrl);
        let res = await cek.json();
        if (!res.data) return Reply('Gagal mengambil data admin.');
        let users = res.data.filter(i => i.attributes.root_admin === true);
        if (users.length < 1) return Reply(`Tidak ada admin panel pada versi ${version.toUpperCase()}.`);

        let teks = `*✦ List Admin Panel Pterodactyl ${version.toUpperCase()} (Page ${page})*\n\n`;
        for (let i of users) {
          teks += `• *ID:* ${i.attributes.id}\n  *Nama:* ${i.attributes.first_name}\n  *Created:* ${i.attributes.created_at.split('T')[0]}\n\n`;
        }
        teks += `Gunakan: *.listadmin ${version} [halaman]* untuk lihat halaman lain.`;
        await conn.sendMessage(m.chat, { text: teks }, { quoted: m });
      } catch (e) {
        console.error('Error:', e);
        Reply(`‼️ Gagal mengambil data admin: ${e.message}`);
      }
      break;
    }

    case 'listpanel':
    case 'listp':
    case 'listserver': {
      if (!isOwner && !isPremium) return Reply(mess.owner);
      const page = m.quoted ? m.quoted.page : parseInt(args[1]) || 1;
      const version = args[0]?.toLowerCase() || 'v1';

      let config = {
        v1: { domain: global.domain, apikey: global.apikey, capikey: global.capikey },
        v2: { domain: global.domainV2, apikey: global.apikeyV2, capikey: global.capikeyV2 },
        v3: { domain: global.domainV3, apikey: global.apikeyV3, capikey: global.capikeyV3 },
        v4: { domain: global.domainV4, apikey: global.apikeyV4, capikey: global.capikeyV4 },
        v5: { domain: global.domainV5, apikey: global.apikeyV5, capikey: global.capikeyV5 }
      };

      if (!config[version]) return Reply('Versi tidak valid. Gunakan v1 - v5.');
      let { domain, apikey, capikey } = config[version];

      const fetchServers = async () => {
        const serverUrl = `${domain}/api/application/servers?page=${page}`;
        console.log('Mengakses URL:', serverUrl);
        const response = await fetch(serverUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apikey}`
          }
        });
        return await validateResponse(response, serverUrl);
      };

      try {
        const serverRes = await fetchServers();
        const servers = (await serverRes.json()).data;
        if (servers.length < 1) return Reply('Tidak ada server ditemukan.');

        let messageText = `\n*乂 List Server Panel Pterodactyl (Version ${version.toUpperCase()})*\n`;
        const serverList = await Promise.all(servers.map(async (server, index) => {
          const s = server.attributes;
          const resourceUrl = `${domain}/api/client/servers/${s.uuid.split('-')[0]}/resources`;
          console.log('Mengakses URL:', resourceUrl);
          const response = await fetch(resourceUrl, {
            method: 'GET',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              Authorization: `Bearer ${capikey}`
            }
          });
          const data = await response.json();
          const status = data.attributes ? data.attributes.current_state : s.status || 'Unknown';
          return `\n*${index + 1}. ID:* ${s.id}  *Nama:* ${s.name}  *RAM:* ${
            s.limits.memory === 0 ? 'Unlimited' : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().slice(0, 2) + 'GB' : s.limits.memory.toString().slice(0, 1) + 'GB'
          }  *CPU:* ${s.limits.cpu === 0 ? 'Unlimited' : s.limits.cpu + '%'}  *Disk:* ${
            s.limits.disk === 0 ? 'Unlimited' : s.limits.disk.toString().length > 3 ? s.limits.disk.toString().slice(0, 2) + 'GB' : s.limits.disk.toString().slice(0, 1) + 'GB'
          }  *Created:* ${s.created_at.split('T')[0]}\n*Status:* ${status}\n`;
        }));

        messageText += serverList.join('');
        messageText += `\n\n*Halaman:* ${page} - Gunakan \`.listpanel ${version} ${page + 1}\` untuk halaman berikutnya.`;
        messageText += `\nGunakan \`.listpanel ${version} ${page - 1}\` untuk halaman sebelumnya.`;
        await conn.sendMessage(m.chat, { text: messageText }, { quoted: m });
      } catch (e) {
        console.error('Error:', e);
        Reply(`‼️ Gagal mengambil daftar server: ${e.message}`);
      }
      break;
    }

    case 'deladmin':
    case 'deladminv1':
    case 'deladminv2':
    case 'deladminv3':
    case 'deladminv4':
    case 'deladminv5': {
      if (!isOwner) return Reply(mess.owner);
      let versi = command.replace('deladmin', '').toLowerCase() || 'v1';
      let idTarget = args[0];

      let config = {
        v1: { domain: global.domain, apikey: global.apikey },
        v2: { domain: global.domainV2, apikey: global.apikeyV2 },
        v3: { domain: global.domainV3, apikey: global.apikeyV3 },
        v4: { domain: global.domainV4, apikey: global.apikeyV4 },
        v5: { domain: global.domainV5, apikey: global.apikeyV5 }
      };

      if (!config[versi]) return Reply('Versi tidak valid. Gunakan v1 - v5.');
      let { domain, apikey } = config[versi];

      const fetchAllAdmins = async () => {
        let allUsers = [];
        let currentPage = 1;
        let hasNextPage = true;
        while (hasNextPage) {
          const adminUrl = `${domain}/api/application/users?page=${currentPage}`;
          console.log('Mengakses URL:', adminUrl);
          let cek = await fetch(adminUrl, {
            method: 'GET',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              Authorization: `Bearer ${apikey}`
            }
          });
          cek = await validateResponse(cek, adminUrl);
          let res = await cek.json();
          if (res.data && res.data.length > 0) {
            allUsers.push(...res.data);
            if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
              currentPage++;
            } else {
              hasNextPage = false;
            }
          } else {
            hasNextPage = false;
          }
        }
        return allUsers;
      };

      try {
        if (!idTarget) {
          const allUsers = await fetchAllAdmins();
          if (allUsers.length < 1) return Reply('Tidak ada admin panel.');
          let teks = `*乂 Daftar Admin Panel Pterodactyl ${versi.toUpperCase()}*\n\n`;
          allUsers.forEach((i) => {
            if (i.attributes.root_admin !== true) return;
            teks += `• *${i.attributes.first_name}* (ID: ${i.attributes.id})\n`;
          });
          teks += `\nGunakan perintah:\n*.deladmin${versi} [id]*\nContoh: *.deladmin${versi} 12*`;
          return Reply(teks);
        }

        const allUsers = await fetchAllAdmins();
        let targetUser = allUsers.find(e => e.attributes.id == idTarget && e.attributes.root_admin === true);
        if (!targetUser) throw 'Akun admin tidak ditemukan atau bukan root_admin!';

        const deleteUrl = `${domain}/api/application/users/${targetUser.attributes.id}`;
        console.log('Mengakses URL:', deleteUrl);
        let delusr = await fetch(deleteUrl, {
          method: 'DELETE',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apikey}`
          }
        });
        delusr = await validateResponse(delusr, deleteUrl);
        let res = delusr.ok ? { errors: null } : await delusr.json();
        if (res.errors) throw `Gagal menghapus admin panel: ${JSON.stringify(res.errors)}`;

        const caption = `✅ Berhasil menghapus admin panel *${capital(targetUser.attributes.username)}* (ID ${targetUser.attributes.id}) dari ${versi.toUpperCase()}`;
        await conn.reply(m.chat, caption, m, {
          mentions: conn.parseMention(caption)
        });
      } catch (e) {
        console.error('Error:', e);
        Reply(`‼️ Gagal menghapus admin: ${e.message}`);
      }
      break;
    }

    case 'delpanel':
    case 'delpanelv1':
    case 'delpanelv2':
    case 'delpanelv3':
    case 'delpanelv4':
    case 'delpanelv5': {
      if (!isOwner && !isPremium) return Reply(mess.owner);
      if (!isGroupAllowed(m.chat)) return Reply(`Grup ini belum memiliki akses. Minta ${global.nameowner} ketik *.addakses* di grup ini.`);

      let versi = command.replace('delpanel', '').toLowerCase() || 'v1';
      let idTarget = args[0];

      let config = {
        v1: { domain: global.domain, apikey: global.apikey },
        v2: { domain: global.domainV2, apikey: global.apikeyV2 },
        v3: { domain: global.domainV3, apikey: global.apikeyV3 },
        v4: { domain: global.domainV4, apikey: global.apikeyV4 },
        v5: { domain: global.domainV5, apikey: global.apikeyV5 }
      };

      if (!config[versi]) return Reply('Versi tidak valid. Gunakan v1 - v5.');
      let { domain, apikey } = config[versi];

      try {
        const serverUrl = `${domain}/api/application/servers?page=1`;
        console.log('Mengakses URL:', serverUrl);
        let res = await fetch(serverUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apikey}`
          }
        });
        res = await validateResponse(res, serverUrl);
        let json = await res.json();
        let servers = json.data;

        if (!idTarget) {
          if (!servers.length) return Reply('Tidak ada server yang ditemukan.');
          let out = `*乂 Daftar Server Panel ${versi.toUpperCase()}*\n\n`;
          for (let srv of servers) {
            let s = srv.attributes;
            out += `• ID: *${s.id}*\n  Nama: ${s.name}\n  RAM: ${s.limits.memory}MB | Disk: ${s.limits.disk}MB | CPU: ${s.limits.cpu}%\n\n`;
          }
          out += `Gunakan perintah:\n*.delpanel${versi} [id]*\nContoh: *.delpanel${versi} ${servers[0]?.attributes.id || 1}*`;
          return Reply(out);
        }

        let id = parseInt(idTarget);
        let target = servers.find(s => s.attributes.id === id);
        if (!target) throw 'ID server tidak ditemukan.';

        let namaServer = target.attributes.name.toLowerCase();
        let namaTampil = target.attributes.name;

        const deleteServerUrl = `${domain}/api/application/servers/${id}`;
        console.log('Mengakses URL:', deleteServerUrl);
        await fetch(deleteServerUrl, {
          method: 'DELETE',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apikey}`
          }
        });

        const userUrl = `${domain}/api/application/users?page=1`;
        console.log('Mengakses URL:', userUrl);
        let userRes = await fetch(userUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apikey}`
          }
        });
        userRes = await validateResponse(userRes, userUrl);
        let userJson = await userRes.json();
        let users = userJson.data;
        let user = users.find(u => u.attributes.first_name.toLowerCase() === namaServer);

        if (user) {
          const deleteUserUrl = `${domain}/api/application/users/${user.attributes.id}`;
          console.log('Mengakses URL:', deleteUserUrl);
          await fetch(deleteUserUrl, {
            method: 'DELETE',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              Authorization: `Bearer ${apikey}`
            }
          });
        }

        const caption = `✅ Server *${capital(namaTampil)}* berhasil dihapus dari ${versi.toUpperCase()}.`;
        await conn.reply(m.chat, caption, m, {
          mentions: conn.parseMention(caption)
        });
      } catch (e) {
        console.error('Error:', e);
        Reply(`‼️ Gagal menghapus server: ${e.message}`);
      }
      break;
    }

    case 'clearuser': {
      if (!isOwner) return Reply(mess.owner);
      const commandArgs = text.trim().split(',');
      const version = commandArgs[0].toLowerCase().trim();
      const excludeIds = commandArgs.slice(1).map(id => id.trim()).filter(Boolean);

      let config = {
        v1: { domain: global.domain, apikey: global.apikey },
        v2: { domain: global.domainV2, apikey: global.apikeyV2 },
        v3: { domain: global.domainV3, apikey: global.apikeyV3 },
        v4: { domain: global.domainV4, apikey: global.apikeyV4 },
        v5: { domain: global.domainV5, apikey: global.apikeyV5 }
      };

      if (!version || !config[version]) {
        return Reply(`*[ Clear User Panel Pterodactyl ]*\n\n` +
                     `*.clearuser v1, id1, id2*\n> Hapus semua user di panel v1, kecuali ID yang disebut.\n\n` +
                     `*.clearuser v2*\n> Hapus semua user di panel v2, kecuali admin utama (ID: 1).\n\n` +
                     `Contoh:\n.clearuser v1, 44, 45\n.clearuser v2`);
      }

      let { domain, apikey } = config[version];

      try {
        const userUrl = `${domain}/api/application/users`;
        console.log('Mengakses URL:', userUrl);
        let res = await fetch(userUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apikey}`
          }
        });
        res = await validateResponse(res, userUrl);
        let data = await res.json();
        let users = data.data;
        if (!users || users.length === 0) {
          return Reply('Tidak ada user yang ditemukan di panel ini.');
        }

        let hasil = [];
        for (let user of users) {
          let u = user.attributes;
          if (version === 'v2' && u.id === 1) {
            hasil.push(`> Mengabaikan admin utama (ID: 1 - ${u.username})`);
            continue;
          }
          if (excludeIds.includes(u.id.toString())) {
            hasil.push(`> Mengabaikan user: ${u.username} (ID: ${u.id})`);
            continue;
          }
          const deleteUrl = `${domain}/api/application/users/${u.id}`;
          console.log('Mengakses URL:', deleteUrl);
          let del = await fetch(deleteUrl, {
            method: 'DELETE',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              Authorization: `Bearer ${apikey}`
            }
          });
          if (del.ok) {
            hasil.push(`✔️ Dihapus: ${u.username} (ID: ${u.id})`);
          } else {
            let errText = await del.text();
            hasil.push(`❌ Gagal hapus ${u.username} (ID: ${u.id}) → ${del.status}`);
          }
        }
        let output = `*[ Clear User ${version.toUpperCase()} Selesai ]*\n\n` + hasil.join('\n');
        Reply(output);
      } catch (e) {
        console.error('Error:', e);
        Reply(`‼️ Gagal menghapus user: ${e.message}`);
      }
      break;
    }

    case 'clearserver': {
      if (!isOwner) return Reply(mess.owner);
      const commandArgs = text.trim().split(',');
      const version = commandArgs[0].toLowerCase().trim();
      const excludeIds = commandArgs.slice(1).map(id => id.trim()).filter(Boolean);

      let config = {
        v1: { domain: global.domain, apikey: global.apikey },
        v2: { domain: global.domainV2, apikey: global.apikeyV2 },
        v3: { domain: global.domainV3, apikey: global.apikeyV3 },
        v4: { domain: global.domainV4, apikey: global.apikeyV4 },
        v5: { domain: global.domainV5, apikey: global.apikeyV5 }
      };

      if (!version || !config[version]) {
        return Reply(`*[ Clear Server Panel Pterodactyl ]*\n\n` +
                     `*.clearserver v1, id1, id2*\n> Hapus semua server di panel v1, kecuali ID yang disebut.\n\n` +
                     `*.clearserver v2*\n> Hapus semua server di panel v2.\n\n` +
                     `Contoh:\n.clearserver v1, 123, 456\n.clearserver v2`);
      }

      let { domain, apikey } = config[version];

      try {
        const serverUrl = `${domain}/api/application/servers`;
        console.log('Mengakses URL:', serverUrl);
        let res = await fetch(serverUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apikey}`
          }
        });
        res = await validateResponse(res, serverUrl);
        let data = await res.json();
        let servers = data.data;
        if (!servers || servers.length === 0) return Reply('Tidak ada server ditemukan.');

        let hasil = [];
        for (let server of servers) {
          let s = server.attributes;
          if (excludeIds.includes(s.id.toString())) {
            hasil.push(`> Mengabaikan server: ${s.name} (ID: ${s.id})`);
            continue;
          }
          const deleteUrl = `${domain}/api/application/servers/${s.id}`;
          console.log('Mengakses URL:', deleteUrl);
          let del = await fetch(deleteUrl, {
            method: 'DELETE',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              Authorization: `Bearer ${apikey}`
            }
          });
          if (del.ok) {
            hasil.push(`✔️ Dihapus: ${s.name} (ID: ${s.id})`);
          } else {
            let errText = await del.text();
            hasil.push(`❌ Gagal hapus ${s.name} (ID: ${s.id}) → ${del.status}`);
          }
        }
        let output = `*[ Clear Server ${version.toUpperCase()} Selesai ]*\n\n` + hasil.join('\n');
        Reply(output);
      } catch (e) {
        console.error('Error:', e);
        Reply(`‼️ Gagal menghapus server: ${e.message}`);
      }
      break;
    }


//////////////////////UNTUK INSTALL PANEL SETALAH ADA VPS ////////////
case "installpanel": {
  if (!isOwner) return Reply(mess.owner);
  if (!text) return Reply("Format: ipvps|pwvps|panel.com|node.com|ramserver *(contoh: 100000)*");

  // Pisahkan input berdasarkan tanda |
  let vii = text.split("|");
  if (vii.length < 5) return Reply("Format: ipvps|pwvps|panel.com|node.com|ramserver *(contoh: 100000)*");

  // Validasi spasi di awal atau akhir setiap segmen
  for (let i = 0; i < vii.length; i++) {
    if (vii[i].startsWith(" ") || vii[i].endsWith(" ")) {
      return Reply("❌ Kesalahan input: Terdapat spasi di awal atau akhir segmen. Pastikan format benar tanpa spasi tambahan, contoh:\n.installpanel 139.59.240.225|YatJ67m9NIVb|jagproev1.jagoanproject.web.id|node.jagproev1.jagoanproject.web.id|8000");
    }
  }

  // Bersihkan input dari spasi (opsional, untuk keamanan tambahan)
  vii = vii.map(item => item.trim());

  let sukses = false;
  const ress = new ssh2.Client();
  const connSettings = {
    host: vii[0],
    port: '22',
    username: 'root',
    password: vii[1]
  };

  const pass = "admin1";
  let passwordPanel = pass;
  const domainpanel = vii[2];
  const domainnode = vii[3];
  const ramserver = vii[4];
  const deletemysql = `\n`;
  const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;

  async function instalWings() {
    ress.exec(commandPanel, (err, stream) => {
      if (err) throw err;
      stream.on('close', async (code, signal) => {
        ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
          if (err) throw err;
          stream.on('close', async (code, signal) => {
            let teks = `
*Install Panel Telah Berhasil ✅*

*Berikut Detail Akun Panel Kamu 📦*

*👤 Username :* admin
*🔐 Password :* ${passwordPanel}
*🌐 ${domainpanel}*

Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Command Menjalankan Wings*
*.startwings* ipvps|pwvps|tokenwings
`;
            await conn.sendMessage(m.chat, { text: teks }, { quoted: m }); // Ganti sock dengan conn
          }).on('data', async (data) => {
            await console.log(data.toString());
            if (data.toString().includes("Masukkan nama lokasi: ")) {
              stream.write('Singapore\n');
            }
            if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
              stream.write('Node By Skyzo\n');
            }
            if (data.toString().includes("Masukkan domain: ")) {
              stream.write(`${domainnode}\n`);
            }
            if (data.toString().includes("Masukkan nama node: ")) {
              stream.write('Node By Skyzo\n');
            }
            if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
              stream.write(`${ramserver}\n`);
            }
            if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
              stream.write(`${ramserver}\n`);
            }
            if (data.toString().includes("Masukkan Locid: ")) {
              stream.write('1\n');
            }
          }).stderr.on('data', async (data) => {
            console.log('Stderr : ' + data);
          });
        });
      }).on('data', async (data) => {
        if (data.toString().includes('Input 0-6')) {
          stream.write('1\n');
        }
        if (data.toString().includes('(y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Enter the panel address (blank for any address)')) {
          stream.write(`${domainpanel}\n`);
        }
        if (data.toString().includes('Database host username (pterodactyluser)')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('Database host password')) {
          stream.write(`admin\n`);
        }
        if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
          stream.write(`${domainnode}\n`);
        }
        if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
          stream.write('admin@gmail.com\n');
        }
        console.log('Logger: ' + data.toString());
      }).stderr.on('data', (data) => {
        m.reply(`Error Terjadi kesalahan :\n${data}`);
        console.log('STDERR: ' + data);
      });
    });
  }

  async function instalPanel() {
    ress.exec(commandPanel, (err, stream) => {
      if (err) throw err;
      stream.on('close', async (code, signal) => {
        await instalWings();
      }).on('data', async (data) => {
        if (data.toString().includes('Input 0-6')) {
          stream.write('0\n');
        }
        if (data.toString().includes('(y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Database name (panel)')) {
          stream.write('\n');
        }
        if (data.toString().includes('Database username (pterodactyl)')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('Password (press enter to use randomly generated password)')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
          stream.write('Asia/Jakarta\n');
        }
        if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
          stream.write('admin@gmail.com\n');
        }
        if (data.toString().includes('Email address for the initial admin account')) {
          stream.write('admin@gmail.com\n');
        }
        if (data.toString().includes('Username for the initial admin account')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('First name for the initial admin account')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('Last name for the initial admin account')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('Password for the initial admin account')) {
          stream.write(`${passwordPanel}\n`);
        }
        if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
          stream.write(`${domainpanel}\n`);
        }
        if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
          stream.write('1\n');
        }
        if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('(yes/no)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Still assume SSL? (y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Please read the Terms of Service')) {
          stream.write('y\n');
        }
        if (data.toString().includes('(A)gree/(C)ancel:')) {
          stream.write('A\n');
        }
        console.log('Logger: ' + data.toString());
      }).stderr.on('data', (data) => {
        m.reply(`Error Terjadi kesalahan :\n${data}`);
        console.log('STDERR: ' + data);
      });
    });
  }

  ress.on('ready', async () => {
    await m.reply(`*Memproses install server panel 🚀*

* *Ip Address :* ${vii[0]}
* *Domain :* ${vii[2]}

Mohon tunggu 1 - 10 menit hingga proses install selesai`);
    ress.exec(deletemysql, async (err, stream) => {
      if (err) throw err;
      stream.on('close', async (code, signal) => {
        await instalPanel();
      }).on('data', async (data) => {
        await stream.write('\t');
        await stream.write('\n');
        await console.log(data.toString());
      }).stderr.on('data', async (data) => {
        m.reply(`Error Terjadi kesalahan :\n${data}`);
        console.log('Stderr : ' + data);
      });
    });
  }).on('error', (err) => {
    console.log('Connection Error: ' + err);
    m.reply('Katasandi atau IP tidak valid');
  }).connect(connSettings);
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "startwings": case "configurewings": {
 if (!isOwner) return Reply(mess.owner);
let t = text.split('|')
if (t.length < 3) return Reply("ipvps|pwvps|token_node")

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new ssh2.Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("*Berhasil menjalankan wings ✅*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "gantipw": case "gantipwvps": {
 if (!isOwner) return Reply(mess.owner);
let t = text.split('|')
if (t.length < 3) return Reply("ipvps|pwvps|pwbaru")

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `passwd`
const ress = new ssh2.Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write(`${token}\n`)
stream.write(`${token}\n`)
if (data.includes("password updated successfully")) return m.reply(`
*Berhasil mengubah password Vps ✅*

* *Password lama :* ${passwd}
* *Password baru :* ${token}
`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//////////////////////UNTUK INSTALL PANEL SETALAH ADA VPS ////////////





    case 'clearadmin': {
      if (!isOwner) return Reply(mess.owner);
      const commandArgs = text.trim().split(',');
      const version = commandArgs[0].toLowerCase().trim();
      const excludeIds = commandArgs.slice(1).map(id => id.trim()).filter(Boolean);

      let config = {
        v1: { domain: global.domain, apikey: global.apikey },
        v2: { domain: global.domainV2, apikey: global.apikeyV2 },
        v3: { domain: global.domainV3, apikey: global.apikeyV3 },
        v4: { domain: global.domainV4, apikey: global.apikeyV4 },
        v5: { domain: global.domainV5, apikey: global.apikeyV5 }
      };

      if (!version || !config[version]) {
        return Reply(`*[ Clear Admin Panel Pterodactyl ]*\n\n` +
                     `*.clearadmin v1, id1, id2*\n> Hapus semua admin di panel v1, kecuali ID yang disebut.\n\n` +
                     `*.clearadmin v2*\n> Hapus semua admin di panel v2.\n\n` +
                     `Contoh:\n.clearadmin v1, 44, 45\n.clearadmin v2`);
      }

      let { domain, apikey } = config[version];

      try {
        const adminUrl = `${domain}/api/application/users`;
        console.log('Mengakses URL:', adminUrl);
        let res = await fetch(adminUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apikey}`
          }
        });
        res = await validateResponse(res, adminUrl);
        let data = await res.json();
        let users = data.data.filter(u => u.attributes.root_admin === true);
        if (!users || users.length === 0) return Reply('Tidak ada admin ditemukan.');

        let hasil = [];
        for (let user of users) {
          let u = user.attributes;
          if (excludeIds.includes(u.id.toString())) {
            hasil.push(`> Mengabaikan admin: ${u.username} (ID: ${u.id})`);
            continue;
          }
          const deleteUrl = `${domain}/api/application/users/${u.id}`;
          console.log('Mengakses URL:', deleteUrl);
          let del = await fetch(deleteUrl, {
            method: 'DELETE',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              Authorization: `Bearer ${apikey}`
            }
          });
          if (del.ok) {
            hasil.push(`✔️ Dihapus: ${u.username} (ID: ${u.id})`);
          } else {
            let errText = await del.text();
            hasil.push(`❌ Gagal hapus ${u.username} (ID: ${u.id}) → ${del.status}`);
          }
        }
        let output = `*[ Clear Admin ${version.toUpperCase()} Selesai ]*\n\n` + hasil.join('\n');
        Reply(output);
      } catch (e) {
        console.error('Error:', e);
        Reply(`‼️ Gagal menghapus admin: ${e.message}`);
      }
      break;
    }

    default:
      Reply('Perintah tidak dikenali.');
      break;
  }
};
handler.help = [
  '1gb <v1-5> <username|nomor>',
  '2gb <v1-5> <username|nomor>',
  '3gb <v1-5> <username|nomor>',
  '4gb <v1-5> <username|nomor>',
  '5gb <v1-5> <username|nomor>',
  '6gb <v1-5> <username|nomor>',
  '7gb <v1-5> <username|nomor>',
  '8gb <v1-5> <username|nomor>',
  '9gb <v1-5> <username|nomor>',
  '10gb <v1-5> <username|nomor>',
  'unlimited <v1-5> <username|nomor>',
  'unli <v1-5> <username|nomor>',
  'cadmin <v1-5> <nomor/mention> <username>',
  'searchuser <v1-5|email/username>',
  'listadmin <v1-5> [page]',
  'listpanel <v1-5> [page]',
  'listp <v1-5> [page]',
  'listserver <v1-5> [page]',
  'deladmin <v1-5> [id]',
  'delpanel <v1-5> [id]',
  'clearuser <v1-5>[,id1,id2,...]',
  'clearserver <v1-5>[,id1,id2,...]',
  'clearadmin <v1-5>[,id1,id2,...]',
  'installpanel <ipvps|pwvps|panel.com|node.com|ramserver>',
  'startwings <ipvps|pwvps|token>',
  'gantipwvps <ipvps|pwvps|pwbaru>'
];

handler.command = /^(1gb|2gb|3gb|4gb|5gb|6gb|7gb|8gb|9gb|10gb|unlimited|unli|cadmin|searchuser|listadmin|listpanel|listp|listserver|deladmin|deladminv1|deladminv2|deladminv3|deladminv4|deladminv5|delpanel|delpanelv1|delpanelv2|delpanelv3|delpanelv4|delpanelv5|clearuser|clearserver|clearadmin|installpanel|startwings|gantipwvps)$/i;
handler.tags = ['cpanel'];
handler.rowner = true;

module.exports = handler;