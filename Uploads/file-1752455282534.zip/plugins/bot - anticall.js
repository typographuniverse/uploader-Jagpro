let handler = m => m;

handler.before = async function (m) {
    if (this.anticallInitialized) return;
    this.anticallInitialized = true;

    this.ev.on('call', async (call) => {
        console.log('📞 Panggilan masuk:', JSON.stringify(call, null, 2)); // Log untuk debugging

        let nomorown = global.nomorown || '628xxxx'; // Ganti dengan nomor owner default
        let processedCalls = new Set();

        // Periksa pengaturan global anticall
        if (!global.opts['anticall']) {
            console.log('⏩ Anticall dinonaktifkan secara global');
            return;
        }

        for (let id of call) {
            if (id.status !== 'offer' || processedCalls.has(id.from)) {
                console.log(`⏩ Melewati panggilan dari ${id.from}: status=${id.status}`);
                continue;
            }

            processedCalls.add(id.from);
            console.log(`📞 Memproses panggilan dari ${id.from}`);

            try {
                await this.sendMessage(id.from, {
                    text: `⚠️ *Bot ini telah dipasang anti-call!*  
🚫 Anda telah diblokir karena menelepon bot.  
Jika ingin membuka blokir, silakan hubungi owner:  
📞 wa.me/${nomorown}`,
                    mentions: [id.from]
                });
                console.log(`✉️ Pesan peringatan dikirim ke ${id.from}`);
            } catch (e) {
                console.error(`❌ Gagal mengirim pesan ke ${id.from}:`, e);
            }

            await new Promise(resolve => setTimeout(resolve, 2000));

            try {
                await this.rejectCall(id.id, id.from);
                console.log(`📞 Panggilan dari ${id.from} ditolak`);
            } catch (e) {
                console.error(`❌ Gagal menolak panggilan dari ${id.from}:`, e);
            }

            await new Promise(resolve => setTimeout(resolve, 3000));

            try {
                await this.updateBlockStatus(id.from, 'block');
                console.log(`🚫 Nomor ${id.from} diblokir`);
            } catch (e) {
                console.error(`❌ Gagal memblokir ${id.from}:`, e);
            }
        }
    });

    console.log('✅ Event listener anticall aktif');
};

module.exports = handler;