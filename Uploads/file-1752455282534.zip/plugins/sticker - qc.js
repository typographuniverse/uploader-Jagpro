// REVELX Variation - Colorful Quote Sticker 🌟

let axios = require('axios')
let { Sticker } = require('wa-sticker-formatter')
let uploadImage = require('../lib/uploadImage.js')

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        const colorPalette = {
            1: '1C2526',  // Abu Tua 🌑
            2: 'F5F6F5',  // Abu Muda ☁️
            3: 'D90429',  // Merah Tua 🔥
            4: '2BA84A',  // Hijau Hutan 🌿
            5: '2F97C1',  // Biru Laut 🌊
            6: 'F8E9A1',  // Kuning Lembut 🌼
            7: '00C4B4',  // Toska 🐬
            8: 'C71585',  // Ungu 💜
            9: 'F4A261',  // Jingga Pasir 🏜️
            10: '7209B7', // Ungu Tua 🌌
            11: 'FFFFFF', // Putih ❄️
            12: '000000'  // Hitam ⚫
        }

        if (!text && !m.quoted) {
            const colorGuide = Object.entries(colorPalette).map(([num, _]) => 
                `${num}: ${['Abu Tua 🌑', 'Abu Muda ☁️', 'Merah Tua 🔥', 'Hijau Hutan 🌿', 'Biru Laut 🌊', 'Kuning Lembut 🌼', 'Toska 🐬', 'Ungu 💜', 'Jingga Pasir 🏜️', 'Ungu Tua 🌌', 'Putih ❄️', 'Hitam ⚫'][num-1]}`
            ).join('\n')
            return m.reply(`✨ *Buat Stiker Keren Yuk!* ✨\n\n📝 *Cara Pakai:* ${usedPrefix}${command} <teks> [nomor_warna]\n\n🎉 *Contoh:* ${usedPrefix}${command} Jadilah Diri Sendiri 3\n\n🌈 *Pilih Warna Favoritmu:*\n${colorGuide}`)
        }

        let q = m.quoted ? m.quoted : m
        let txt = text || q.text || ''
        let colorNum = 1

        if (text) {
            let parts = text.trim().split(' ')
            let last = parts[parts.length - 1]
            if (/^\d+$/.test(last) && colorPalette[last]) {
                colorNum = last
                txt = parts.slice(0, -1).join(' ')
            }
        }

        if (!txt) return m.reply('😅 *Oops!* Masukkan teks atau balas pesan dulu ya!')

        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key }})
        
        let pp = await conn.profilePictureUrl(q.sender, 'image').catch(_ => 'https://telegra.ph/file/320b066dc81928b782c7b.png')
        pp = /tele/.test(pp) ? pp : await uploadImage((await conn.getFile(pp)).data)

        const quoteObj = {
            type: 'quote',
            format: 'png',
            backgroundColor: `#${colorPalette[colorNum]}`,
            width: 512,
            height: 768,
            scale: 2,
            messages: [{
                entities: [],
                avatar: true,
                from: {
                    id: 1,
                    name: q.name || m.name,
                    photo: { url: pp }
                },
                text: txt,
                replyMessage: {}
            }]
        }

        const response = await axios.post('https://qc.botcahx.eu.org/generate', quoteObj, {
            headers: { 'Content-Type': 'application/json' }
        })

        const buffer = Buffer.from(response.data.result.image, 'base64')
        const sticker = await createSticker(buffer, global.packname, global.author)
        
        await conn.sendFile(m.chat, sticker, 'quote.webp', '', m)
        await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key }})
    } catch (e) {
        await m.reply(`😓 *Yah, ada error nih:* ${e.message}`)
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key }})
    }
}

handler.help = ['qc <teks> [nomor_warna]', 'qc warna']
handler.tags = ['sticker', 'tools']
handler.command = /^(qc|quotely)$/i

handler.before = async (m) => {
    if (m.text.match(/^[.!\/](?:qc|quotely) warna?$/i)) {
        const colors = ['Abu Tua 🌑', 'Abu Muda ☁️', 'Merah Tua 🔥', 'Hijau Hutan 🌿', 'Biru Laut 🌊', 'Kuning Lembut 🌼', 'Toska 🐬', 'Ungu 💜', 'Jingga Pasir 🏜️', 'Ungu Tua 🌌', 'Putih ❄️', 'Hitam ⚫']
        const colorList = colors.map((c, i) => `${i+1}: ${c}`).join('\n')
        await m.reply(`🌟 *Daftar Warna Keren!* 🌟\n\n${colorList}\n\n📌 *Contoh:* .qc Halo Dunia 5`)
        return true
    }
}

module.exports = handler

async function createSticker(buffer, packname, author) {
    return await new Sticker(buffer, {
        type: 'full',
        pack: packname,
        author,
        quality: 50
    }).toBuffer()
}