const fs = require('fs')
const path = require('path')

const dbPath = path.join(__dirname, '../database/sider.json')

function loadSiderDB() {
    if (!fs.existsSync(dbPath)) return {}
    return JSON.parse(fs.readFileSync(dbPath))
}

function saveSiderDB(db) {
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2))
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

let handler = async (m, { conn, command }) => {
    const chatId = m.chat
    let db = loadSiderDB()

    if (!db[chatId]) {
        db[chatId] = {
            aktif: false,
            sejak: null,
            listKick: []
        }
    }

    const sider = db[chatId]

  if (command === 'sider') {
    const aktif = sider.aktif
    const sejak = sider.sejak
    const aktifSejak = sejak ? new Date(sejak).toLocaleString() : 'Belum Pernah Aktif'
    let pesan = `📌 *Status Fitur Sider:*\n`
    pesan += `Status: ${aktif ? '✅ Aktif' : '❌ Nonaktif'}\n`
    pesan += `Aktif Sejak: ${aktifSejak}\n`

    if (aktif && sejak) {
        const msLeft = 86400000 - (Date.now() - sejak)
        if (msLeft > 0) {
            const jam = Math.floor(msLeft / 3600000)
            const menit = Math.floor((msLeft % 3600000) / 60000)
            pesan += `Sisa Waktu Kick Otomatis: *${jam} jam ${menit} menit*\n`
        } else {
            pesan += `⏱️ Sudah melewati 1 hari, siap kick...\n`
        }
    }

    const totalData = global.db.data.chats[chatId]?.total || {}
    const meta = await conn.groupMetadata(chatId)
    const peserta = meta.participants.map(p => p.id)
    const potensiKick = peserta.filter(id => (totalData[id] || 0) < 5)

    if (potensiKick.length > 0) {
        pesan += `\n⚠️ *Anggota dengan chat < 5:*\n`
        pesan += potensiKick.map((id, i) => {
            const count = totalData[id] || 0
            return `${i + 1}. @${id.split('@')[0]} (*${count} chat*)`
        }).join('\n')
        pesan += `\n\n💬 *Minimal 5 chat agar tidak di-kick!*\n> List diatas bersifat sementara, agar tidak di kick smaapi waktu tiba, segera muncul dan berinteraksi dalam grup`
    }

    return m.reply(pesan, null, {
        contextInfo: { mentionedJid: potensiKick }
    })
}



    if (command === 'sideron') {
        db[chatId] = {
            aktif: true,
            sejak: Date.now(),
            listKick: []
        }
        saveSiderDB(db)
        return m.reply('✅ Fitur Sider berhasil diaktifkan. semua user yang termasuk dalam list akan di aktifkan apabila tidak aktif sampai waktu habis.')
    }

    if (command === 'sideroff') {
        db[chatId].aktif = false
        saveSiderDB(db)
        return m.reply('❌ Fitur Sider berhasil dimatikan.')
    }

  if (command === 'siderlist') {
    const totalData = global.db.data.chats[chatId]?.total || {}
    const meta = await conn.groupMetadata(chatId)
    const peserta = meta.participants.map(p => p.id)
    const potensiKick = peserta.filter(id => (totalData[id] || 0) < 5)

    const teks = potensiKick.length
        ? potensiKick.map((jid, i) => {
            const count = totalData[jid] || 0
            return `${i + 1}. @${jid.split('@')[0]} (*${count} chat*)`
        }).join('\n')
        : '✅ Semua anggota aktif. Tidak ada yang akan di-kick.'

    return m.reply(`📋 *Anggota Potensi Kick (Chat < 5):*\n${teks}`, null, {
        contextInfo: { mentionedJid: potensiKick }
    })
}



    if (command === 'siderkick') {
        const dbChat = global.db.data.chats[chatId]
        const groupMeta = await conn.groupMetadata(chatId)
        const peserta = groupMeta.participants.map(p => p.id)
        const totalData = (dbChat && dbChat.total) || {}

        sider.listKick = []

        for (const id of peserta) {
            const total = totalData[id] || 0
            if (total < 5) {
                sider.listKick.push(id)
                try {
                    await conn.groupParticipantsUpdate(chatId, [id], 'remove')
                    await sleep(40000)
                } catch (e) {
                    m.reply(`❗ Gagal kick @${id.split('@')[0]}: ${e.message}`)
                }
            }
        }

        saveSiderDB(db)
        return m.reply(`✅ Proses kick langsung selesai. Total: ${sider.listKick.length}`, null, {
            contextInfo: { mentionedJid: sider.listKick }
        })
    }
}

handler.help = ['sider', 'sideron', 'sideroff', 'siderlist', 'siderkick']
handler.tags = ['group']
handler.command = /^(sideron|sider|sideroff|siderlist|siderkick)$/i
handler.group = true
handler.admin = true

module.exports = handler
