// ✨ Plugin downloader - tiktoksearch ✨

const fetch = require('node-fetch');

const handler = async (m, { conn, command, text }) => {
  if (!text) return m.reply(`🔎 Masukkan kata kunci!\n\nContoh:\n.${command} perfect world`);

  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/search/tiktoks?query=${encodeURIComponent(text)}&apikey=${encodeURIComponent(global.btc)}`);
    const json = await res.json();

    if (!json.status || !json.result?.data || json.result.data.length === 0) {
      return m.reply('❌ Tidak ditemukan video TikTok.');
    }

    const result = json.result.data[0]; // Ambil 1 hasil pertama
    const videoUrl = result.play;
    const title = result.title;
    const author = result.author?.nickname || 'Unknown';
    const views = result.play_count?.toLocaleString() || '0';
    const cover = result.cover;

    await conn.sendMessage(m.chat, {
      video: { url: videoUrl },
      mimetype: 'video/mp4',
      caption: `🎬 *${title}*\n👤 *${author}*\n👁️ *Views:* ${views}`
    }, { quoted: m });

  } catch (err) {
    console.error('[TTSEARCH ERROR]', err);
    m.reply('🚫 Gagal mencari video TikTok.');
  }
};

handler.command = /^ttsearch$/i;
handler.tags = ['downloader'];
handler.help = ['ttsearch <keyword>'];
handler.limit = true;

module.exports = handler;