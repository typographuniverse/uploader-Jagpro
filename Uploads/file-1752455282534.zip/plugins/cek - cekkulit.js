let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.kulit)}”`, m)
}
handler.help = ['cekkulit']
handler.tags = ['cek']
handler.command = /^(cekkulit)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.kulit = [
'Putih Bersih', 'Sawo Matang', 'Item Njir Kyk Orang Afrika', 'Putih Banget (Keputihan)', 'Putih Pink (Pantat Nya Pun Pink)', 'Gak Putih Gak Hitam', 'Hampir Hitam', 'Agak Putih', 'Kuning Langsat', 'Negro', 'Nigga', 'Putih Kyk Artis Korea', 'Lu Mirip Kyk Sadio Mane Hitam Nya', 'Awokawok Belang', 'Muka doang yang putih', 
]