let search = require('yt-search');
let fetch = require('node-fetch');

let handler = async (m, { conn, text, usedPrefix }) => {
    if (!text) throw 'Masukkan link dari youtube!';
    try {
        await m.reply('Tunggu sebentar...')
        const look = await search(text);
        const convert = look.videos[0];
        if (!convert) throw 'Video/Audio Tidak Ditemukan';
        if (convert.seconds >= 18000) {
            return conn.reply(m.chat, 'Video lebih dari 5 jam, tidak bisa!', m);
        } else {
            let audioUrl;
            let apiSource = '';
            try {
                // Coba API Botcahx terlebih dahulu
                const res = await fetch(`${global.apibtc}/api/dowloader/yt?url=${convert.url}&apikey=${btc}`);
                audioUrl = await res.json();
                
                // Periksa jika API Botcahx gagal atau respons tidak valid
                if (!audioUrl || !audioUrl.result?.mp3) {
                    throw new Error('Botcahx API gagal');
                }
                apiSource = 'pertama';
            } catch (e) {
                // Fallback ke API Ptereodactyl
                try {
                    const res = await fetch(`${global.ptereodactyl}api/ytmp3?url=${convert.url}`);
                    const pterodactylResponse = await res.json();
                    
                    // Verifikasi respons Ptereodactyl
                    if (!pterodactylResponse?.data?.status || !pterodactylResponse?.data?.result?.audio_download) {
                        throw new Error('Ptereodactyl API gagal');
                    }
                    // Sesuaikan format respons Ptereodactyl ke format yang diharapkan
                    audioUrl = {
                        result: {
                            mp3: pterodactylResponse.data.result.audio_download
                        }
                    };
                    apiSource = 'kedua';
                } catch (e) {
                    conn.reply(m.chat, 'Terjadi kesalahan saat mengunduh audio', m);
                    return;
                }
            }

            let caption = `> Hasil dari API: ${apiSource}\n\n`;
            caption += `∘ Title : ${convert.title}\n`;
            caption += `∘ Ext : Search\n`;
            caption += `∘ ID : ${convert.videoId}\n`;
            caption += `∘ Duration : ${convert.timestamp}\n`;
            caption += `∘ Viewers : ${convert.views}\n`;
            caption += `∘ Upload At : ${convert.ago}\n`;
            caption += `∘ Author : ${convert.author.name}\n`;
            caption += `∘ Channel : ${convert.author.url}\n`;
            caption += `∘ Url : ${convert.url}\n`;
            caption += `∘ Description : ${convert.description}\n`;
            caption += `∘ Thumbnail : ${convert.image}`;

            await conn.relayMessage(m.chat, {
                extendedTextMessage: {
                    text: caption,
                    contextInfo: {
                        externalAdReply: {
                            title: convert.title,
                            mediaType: 1,
                            previewType: 0,
                            renderLargerThumbnail: true,
                            thumbnailUrl: convert.image,
                            sourceUrl: convert.url
                        }
                    },
                    mentions: [m.sender]
                }
            }, {});

            await conn.sendMessage(m.chat, {
                audio: {
                    url: audioUrl.result.mp3
                },
                mimetype: 'audio/mpeg',
                contextInfo: {
                    externalAdReply: {
                        title: convert.title,
                        body: "",
                        thumbnailUrl: convert.image,
                        sourceUrl: convert.url,
                        mediaType: 1,
                        showAdAttribution: true,
                        renderLargerThumbnail: true
                    }
                }
            }, {
                quoted: m
            });
        }
    } catch (e) {
        conn.reply(m.chat, 'Terjadi kesalahan saat memproses permintaan', m)
    }
};

handler.command = handler.help = ['play', 'song', 'ds'];
handler.tags = ['downloader'];
handler.exp = 0;
handler.limit = true;
handler.premium = false;

module.exports = handler;