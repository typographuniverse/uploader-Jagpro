const fs = require('fs');
const { useMultiFileAuthState, downloadContentFromMessage, fetchLatestBaileysVersion, default: makeWASocket } = require('@whiskeysockets/baileys');

const authFile = `session`;
global.isInit = !fs.existsSync(authFile);

async function initializeAuth() {
    return await useMultiFileAuthState(authFile);
}

initializeAuth().then(({ state, saveState, saveCreds }) => {
    global.authState = state;
    global.saveState = saveState;
    global.saveCreds = saveCreds;
}).catch(console.error);

// Utility for random emoji selection
const Func = {
    random: (arr) => arr[Math.floor(Math.random() * arr.length)]
};

let handler = async (m, { text, conn, usedPrefix, command, args, isOwner, isAdmin, isROwner }) => {
    if (command === 'oncek') {
        if (!m.isGroup) return m.reply('*‼️ Oopss!!*\n\n> maaf perintah ini hanya bisa digunakan di grup!');

        let chat = global.db.data.chats[m.chat];

        let fiturGrup = {
            welcome: chat.welcome,
            antilink: chat.antiLink,
            antilinkall: chat.antiLinkAll,
            antiupsw: chat.antiupsw,
            antinomorluar: chat.antiNomorLuar,
            antipoto: chat.antiFoto,
            antisticker: chat.antiSticker,
            antinsfw: chat.antiNsfw,
            notifgempa: chat.notifgempa,
            autolevelup: chat.autolevelup,
            antisaluran: chat.antisaluran,
            antidelete: chat.antiDelete,
            autosticker: chat.stiker,
            antitoxic: chat.antiToxic,
            antibot: chat.antiBot,
            antieditchat: chat.antiEditChat,
            antipromo: chat.antiPromo
        };

        let fiturBot = {
            autoreadgc: global.opts['autoreadgc'],
            autoreadpc: global.opts['autoreadpc'],
            antispam: chat.antispam,
            pconly: global.opts['pconly'],
            gconly: global.opts['gconly'],
            reactsw: global.opts['reactsw']  // Added reactsw
        };

        let aktifGrup = Object.entries(fiturGrup)
            .filter(([_, status]) => status)
            .map(([feature]) => `✅ ${feature}`)
            .join("\n") || "tidak ada fitur yang aktif.";

        let nonaktifGrup = Object.entries(fiturGrup)
            .filter(([_, status]) => !status)
            .map(([feature]) => `❌ ${feature}`)
            .join("\n") || "semua fitur aktif.";

        let aktifBot = Object.entries(fiturBot)
            .filter(([_, status]) => status)
            .map(([feature]) => `✅ ${feature}`)
            .join("\n") || "tidak ada fitur bot yang aktif.";

        let nonaktifBot = Object.entries(fiturBot)
            .filter(([_, status]) => !status)
            .map(([feature]) => `❌ ${feature}`)
            .join("\n") || "semua fitur bot aktif.";

        let message = `⚙️ *STATUS FITUR GROUP*\n\n*🍥 Fitur aktif :*\n\n${aktifGrup}\n\n*🍥 Fitur nonaktif :*\n\n${nonaktifGrup}\n\n⚙️ *STATUS FITUR BOT*\n\n*🍥 Fitur aktif :*\n\n${aktifBot}\n\n*🍥 Fitur nonaktif :*\n\n${nonaktifBot}`;
        return m.reply(message);
    }

    if (!text) return m.reply(`
❇️ 〔 *SETTINGS GROUP* 〕

╭─➤ 🗒️ *LIST FITUR*
│  ├─ welcome
│  ├─ antilink
│  ├─ antilinkall
│  ├─ antiupsw
│  ├─ antinomorluar
│  ├─ antipoto
│  ├─ antisticker
│  ├─ antinsfw
│  ├─ notifgempa
│  ├─ autolevelup
│  ├─ antisaluran
│  ├─ antidelete
│  ├─ autosticker
│  ├─ antitoxic
│  ├─ antibot
│  ├─ antieditchat
│  ├─ antipromo
╰───────────────⭓

  ⚙️ 〔 *SETTINGS BOT* 〕
  
╭─➤ 🗒️ *LIST FITUR*
│  ├─ autoreadgc
│  ├─ autoreadpc
│  ├─ antispam
│  ├─ pconly
│  ├─ gconly
│  ├─ reactsw
╰───────────────⭓

   📝 〔 *CONTOH PENGGUNAAN* 〕

╭─➤  
│  ├─ *${usedPrefix}on welcome*
│  ├─ *${usedPrefix}off welcome*
│  └─ *${usedPrefix}on all*
╰───────────────⭓

   📝 〔 *CEK STATUS FITUR AKTIF* 〕
   
> ketik .oncek - untuk melihat fitur yang aktif
`);

    let isEnable = /true|enable|(turn)?on|1/i.test(command);
    let chat = global.db.data.chats[m.chat];
    let user = global.db.data.users[m.sender];
    let type = (args[0] || '').toLowerCase();
    let isAll = false;
    let isUser = false;

    if (type === 'all' && isEnable) {
        if (!m.isGroup) {
            if (!isOwner) {
                global.dfail('group', m, conn);
                throw false;
            }
        } else if (!(isAdmin || isOwner)) {
            global.dfail('admin', m, conn);
            throw false;
        }

        chat.welcome = true;
        chat.antiLink = true;
        chat.antiLinkAll = true;
        chat.antiupsw = true;
        chat.antiNomorLuar = true;
        chat.antiFoto = true;
        chat.antiSticker = true;
        chat.antiNsfw = true;
        chat.notifgempa = true;
        chat.autolevelup = true;
        chat.antisaluran = true;
        chat.antiDelete = true;
        chat.stiker = true;
        chat.antiToxic = true;
        chat.antiBot = true;
        chat.antiEditChat = true;
        chat.antiPromo = true;

        return m.reply(`✅ Berhasil *mengaktifkan* semua fitur group!!\n\n> ketik .oncek - untuk melihat status`);
    }

    if (type === 'all' && !isEnable) {
        if (!m.isGroup) {
            if (!isOwner) {
                global.dfail('group', m, conn);
                throw false;
            }
        } else if (!(isAdmin || isOwner)) {
            global.dfail('admin', m, conn);
            throw false;
        }

        chat.welcome = false;
        chat.antiLink = false;
        chat.antiLinkAll = false;
        chat.antiupsw = false;
        chat.antiNomorLuar = false;
        chat.antiFoto = false;
        chat.antiSticker = false;
        chat.antiNsfw = false;
        chat.notifgempa = false;
        chat.autolevelup = false;
        chat.antisaluran = false;
        chat.antiDelete = false;
        chat.stiker = false;
        chat.antiToxic = false;
        chat.antiBot = false;
        chat.antiEditChat = false;
        chat.antiPromo = false;

        return m.reply(`‼️ Berhasil *menonaktifkan* semua fitur group!\n\n> ketik .oncek - untuk melihat status.`);
    }

    switch (type) {
        case 'antipromo':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    throw false;
                }
            }
            chat.antiPromo = isEnable;
            break;
        case 'antilinkall':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    throw false;
                }
            }
            chat.antiLinkAll = isEnable;
            break;
        case 'antitoxic':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    throw false;
                }
            }
            chat.antiToxic = isEnable;
            break;
        case 'antidelete':
            if (!m.isGroup) {
                if (!isOwner) {
                    global.dfail('group', m, conn);
                    throw false;
                }
            } else if (!isAdmin) {
                global.dfail('admin', m, conn);
                throw false;
            }
            chat.antiDelete = isEnable;
            break;
        case 'antinomorluar':
            if (!m.isGroup) {
                if (!isOwner) {
                    global.dfail('group', m, conn);
                    throw false;
                }
            } else if (!isAdmin) {
                global.dfail('admin', m, conn);
                throw false;
            }
            chat.antiNomorLuar = isEnable;
            break;
        case 'antiupsw':
            if (!m.isGroup) {
                if (!isOwner) {
                    global.dfail('group', m, conn);
                    throw false;
                }
            } else if (!isAdmin) {
                global.dfail('admin', m, conn);
                throw false;
            }
            chat.antiupsw = isEnable;
            break;
        case 'antisaluran':
            if (m.isGroup && !(isAdmin || isOwner)) {
                global.dfail('admin', m, conn);
                throw false;
            }
            chat.antisaluran = isEnable;
            break;
        case 'welcome':
            if (!m.isGroup) {
                if (!isOwner) {
                    global.dfail('group', m, conn);
                    throw false;
                }
            } else if (!isAdmin) {
                global.dfail('admin', m, conn);
                throw false;
            }
            chat.welcome = isEnable;
            break;
        case 'antilink':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    throw false;
                }
            }
            chat.antiLink = isEnable;
            break;
        case 'antisticker':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    throw false;
                }
            }
            chat.antiSticker = isEnable;
            break;
        case 'antispam':
            if (!isOwner) {
                global.dfail('owner', m, conn);
                throw false;
            }
            chat.antispam = isEnable;
            break;
        case 'antipoto':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    throw false;
                }
            }
            chat.antiFoto = isEnable;
            break;
        case 'autosticker':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    throw false;
                }
            }
            chat.stiker = isEnable;
            break;
        case 'toxic':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    throw false;
                }
            }
            chat.antiToxic = !isEnable;
            break;
        case 'notifgempa':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    return false;
                }
                chat.notifgempa = isEnable;
            } else {
                return global.dfail('group', m, conn);
            }
            break;
        case 'autolevelup':
            isUser = true;
            user.autolevelup = isEnable;
            if (m.isGroup) {
                let chat = global.db.data.chats[m.chat];
                chat.autolevelup = isEnable;
            }
            break;
        case 'antibot':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    throw false;
                }
            }
            chat.antiBot = isEnable;
            break;
        case 'antinsfw':
            if (m.isGroup) {
                if (!isOwner) {
                    global.dfail('group', m, conn);
                    throw false;
                }
            } else if (!isAdmin) {
                global.dfail('admin', m, conn);
                throw false;
            }
            chat.antiNsfw = isEnable;
            break;
        case 'antieditchat':
            if (m.isGroup) {
                if (!(isAdmin || isOwner)) {
                    global.dfail('admin', m, conn);
                    throw false;
                }
            }
            chat.antiEditChat = isEnable;
            break;
        case 'autoreadgc':
            isAll = true;
            if (!isROwner) {
                global.dfail('rowner', m, conn);
                throw false;
            }
            global.opts['autoreadgc'] = isEnable;
            break;
        case 'autoreadpc':
            isAll = true;
            if (!isROwner) {
                global.dfail('rowner', m, conn);
                throw false;
            }
            global.opts['autoreadpc'] = isEnable;
            break;
        case 'pconly':
        case 'privateonly':
            isAll = true;
            if (!isROwner) {
                global.dfail('rowner', m, conn);
                throw false;
            }
            global.opts['pconly'] = isEnable;
            break;
        case 'gconly':
        case 'grouponly':
            isAll = true;
            if (!isROwner) {
                global.dfail('rowner', m, conn);
                throw false;
            }
            global.opts['gconly'] = isEnable;
            break;
        case 'reactsw': // Added reactsw case
            isAll = true;
            if (!isROwner) {
                global.dfail('rowner', m, conn);
                throw false;
            }
            global.opts['reactsw'] = isEnable;
            break;
        default:
            if (!/[01]/.test(command)) return m.reply(`
❇️ 〔 *SETTINGS GROUP* 〕

╭─➤ 🗒️ *LIST FITUR*
│  ├─ welcome
│  ├─ antilink
│  ├─ antilinkall
│  ├─ antiupsw
│  ├─ antinomorluar
│  ├─ antipoto
│  ├─ antisticker
│  ├─ antinsfw
│  ├─ notifgempa
│  ├─ autolevelup
│  ├─ antisaluran
│  ├─ antidelete
│  ├─ autosticker
│  ├─ antitoxic
│  ├─ antibot
│  ├─ antieditchat
│  ├─ antipromo
╰───────────────⭓

  ⚙️ 〔 *SETTINGS BOT* 〕
  
╭─➤ 🗒️ *LIST FITUR*
│  ├─ autoreadgc
│  ├─ autoreadpc
│  ├─ antispam
│  ├─ pconly
│  ├─ gconly
│  ├─ reactsw
╰───────────────⭓

   📝 〔 *CONTOH PENGGUNAAN* 〕

╭─➤  
│  ├─ *${usedPrefix}on welcome*
│  ├─ *${usedPrefix}off welcome*
│  └─ *${usedPrefix}on all*
╰───────────────⭓

   📝 〔 *CEK STATUS FITUR AKTIF* 〕
   
> ketik .oncek - untuk melihat fitur yang aktif
`);
            throw false;
    }
    m.reply(`✅ Berhasil menyetel fitur!!\n\n– 🍥 nama : ${type}\n– 🍿 status : ${isEnable ? 'aktif' : 'nonaktif'} ${isAll ? 'untuk bot ini' : isUser ? '' : 'untuk chat ini'}`.trim());
};

conn.ev.on('group-participants.update', async (update) => {
    try {
        let { id, participants, action } = update;
        if (action !== 'add') return;

        let chat = global.db.data.chats[id];
        if (!chat.antiNomorLuar) return;

        for (let user of participants) {
            let nomor = user.split('@')[0];
            if (!nomor.startsWith('62') && !nomor.startsWith('60')) {
                await conn.sendMessage(id, { text: `*‼️ ANTI NOMOR LUAR AKTIF*\n\n– nomor @${nomor} bukan dari indonesia atau malaysia!\n\n> user akan dikeluarkan dari grup!`, contextInfo: { mentionedJid: [user] } });
                await conn.groupParticipantsUpdate(id, [user], 'remove');
            }
        }
    } catch (error) {
        console.error('❌ Error dalam mendeteksi nomor luar:', error);
    }
});

require("events").EventEmitter.defaultMaxListeners = 20;

async function deleteMessage(conn, m) {
    try {
        if (m.key && m.key.remoteJid) {
            await conn.sendMessage(m.key.remoteJid, { delete: m.key });
        }
    } catch (error) {
        console.error("❌ Gagal menghapus pesan:", error);
    }
}

conn.ev.removeAllListeners("messages.upsert");

conn.ev.on("messages.upsert", async (v) => {
    try {
        const { messages } = v;
        for (const m of messages) {
            if (!m.message || m.key.fromMe) continue;

            // Handle reactsw for status updates
            if (m.key.remoteJid === 'status@broadcast' && global.opts['reactsw']) {
                const sender = m.key.participant || m.sender; // Gunakan m.key.participant sebagai fallback
                if (!sender) {
                    console.error("Pengirim tidak ditemukan:", m);
                    continue; // Lewati jika sender tidak ada
                }

                // Inisialisasi conn.storyJid jika belum ada
                conn.storyJid = conn.storyJid || [];
                if (!conn.storyJid.includes(sender) && sender !== conn.decodeJid(conn.user.id)) {
                    conn.storyJid.push(sender);
                }

                console.log('Pengirim:', sender, 'Daftar Story JID:', conn.storyJid);

                if ([...new Set(conn.storyJid)].includes(sender) && !/protocol/.test(m.mtype)) {
                    try {
                        await conn.relayMessage(
                            'status@broadcast',
                            {
                                reactionMessage: {
                                    key: {
                                        remoteJid: 'status@broadcast',
                                        id: m.key.id,
                                        participant: sender, // Gunakan sender
                                        fromMe: false
                                    },
                                    text: Func.random(['🤣', '😂', '😋', '😎', '🤓', '🤪', '🥳', '😠', '😱', '🤔', '🥶'])
                                }
                            },
                            {
                                messageId: m.key.id,
                                statusJidList: [sender] // Gunakan sender
                            }
                        );
                        console.log('Reaksi terkirim ke:', sender);
                    } catch (error) {
                        console.error('Gagal mengirim reaksi:', error);
                    }
                }
            }

            // Kode antisaluran tetap sama
            const recentWarnings = new Set(); // Tambahkan ini di awal
            let chat = global.db.data.chats[m.key.remoteJid];
            if (!chat || !chat.antisaluran) continue;

            const nljid = Object.values(m.message || {}).find(msg => 
                msg?.contextInfo?.forwardedNewsletterMessageInfo?.newsletterJid
            )?.contextInfo?.forwardedNewsletterMessageInfo?.newsletterJid;

            if (nljid && nljid !== "120363315304652958@newsletter") {
                if (recentWarnings.has(m.key.id)) continue;

                recentWarnings.add(m.key.id);
                setTimeout(() => recentWarnings.delete(m.key.id), 30000);

                await conn.sendMessage(m.key.remoteJid, { 
                    text: "*‼️ ANTI SALURAN AKTIF*\n\n– dilarang membagikan link saluran ataupun pesan dari saluran disini!!" 
                }, { quoted: m });

                await new Promise(resolve => setTimeout(resolve, 2000));
                await deleteMessage(conn, m);
                return;
            }
        }
    } catch (error) {
        console.error("❌ Error dalam messages.upsert:", error);
    }
});

handler.help = [
    ...['welcome', 'antipromo', 'antilink', 'antilinkall', 'antiupsw', 'antinomorluar', 'antipoto', 'antisticker', 'antinsfw', 'notifgempa', 'autolevelup', 'antisaluran', 'antidelete', 'autosticker', 'antitoxic', 'antibot', 'antieditchat', 'autoreadgc', 'autoreadpc', 'antispam', 'pconly', 'gconly', 'reactsw']
        .map(v => `on/off ${v}`),
    'on all', 'oncek'
];
handler.tags = ['group'];
handler.command = /^(enable|disable|on|off|oncek)$/i;

module.exports = handler;