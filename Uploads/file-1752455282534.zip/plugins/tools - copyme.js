// 📝 plugin tools - copyme

// 📝 plugin tools - copyme

let handler = async (m, { conn }) => {
  // Ambil JID pengirim
  let sender = m.sender || m.key.participant || m.key.remoteJid;
  
  // Hapus domain @s.whatsapp.net jika ada
  let number = sender.replace(/[^0-9]/g, '');

  const interactiveMessage = {
    text: `\n 🪀 nomor kamu\n ╰┈➤ *${number}*`,
    title: "✅ *BERHASIL COPY NOMOR*",
    footer: "\nᴛᴇᴋᴀɴ ᴛᴏᴍʙᴏʟ ᴅɪʙᴀᴡᴀʜ ɪɴɪ ᴜɴᴛᴜᴋ ᴍᴇɴʏᴀʟɪɴ ɴᴏᴍᴏʀ.",
    interactiveButtons: [
      {
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
          display_text: "📋 SALIN NOMOR",
          id: "copy_number",
          copy_code: number
        })
      }
    ]
  };

  await conn.sendMessage(m.chat, interactiveMessage, { quoted: m });
};

handler.help = ['copyme'];
handler.tags = ['tools'];
handler.command = /^copyme$/i;

module.exports = handler;