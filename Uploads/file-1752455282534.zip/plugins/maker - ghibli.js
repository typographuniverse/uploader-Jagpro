// ✨ Plugin maker - ghibli ✨

const axios = require('axios')
const crypto = require('crypto')
const FormData = require('form-data')
 
const Uguu = async (buffer, filename) => {
  const form = new FormData()
  form.append('files[]', buffer, { filename })
  const { data } = await axios.post('https://uguu.se/upload.php', form, { headers: form.getHeaders() })
  if (data?.files?.[0]?.url) return data.files[0].url
  throw new Error('Upload gagal')
}
 
const ghibliAI = async imageUrl => {
  const sessionId = crypto.randomUUID().replace(/-/g, '')
  const payload = {
    imageUrl,
    sessionId,
    prompt: "Please convert this image into Studio Ghibli art style with the Ghibli AI generator.",
    timestamp: Date.now().toString()
  }
  const { data: { taskId } } = await axios.post("https://ghibliai.ai/api/transform-stream", payload)
  while (true) {
    const { data } = await axios.get(`https://ghibliai.ai/api/transform-stream?taskId=${taskId}`)
    if (data.status === 'success') return data.result || data.imageUrl
    if (data.status === 'error') throw new Error(data.error || "Proses gagal")
    await new Promise(r => setTimeout(r, 2000))
  }
}
 
const handler = async (m, { conn, args }) => {
  try {
    let imageUrl
    if (args[0]) {
      if (!/^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)$/i.test(args[0])) return m.reply("Link tidak valid")
      imageUrl = args[0]
    } else {
      const q = m.quoted || m
      const mime = (q.msg || q).mimetype || ''
      if (!mime.startsWith('image/')) return m.reply("Kirim gambar atau URL gambar terlebih dahulu")
      const media = await q.download()
      imageUrl = await Uguu(media, `ghibli.${mime.split('/')[1]}`)
    }
 
    await m.reply("Tunggu 1-4 menit Ya...")
    const result = await ghibliAI(imageUrl)
    if (result?.startsWith('http')) {
      await conn.sendMessage(m.chat, { image: { url: result } }, { quoted: m })
    } else {
      await m.reply("Error Bejir")
    }
  } catch (e) {
    m.reply(e.message)
  }
}
 
handler.help = ['ghibli']
handler.command = ['ghibli', 'toghibli']
handler.tags = ['ai']
module.exports = handler