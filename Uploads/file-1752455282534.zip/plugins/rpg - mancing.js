const { proto } = require('@whiskeysockets/baileys');
global.fishingPlayers = global.fishingPlayers || new Map();

const ikanList = [
    { emoji: '🐟', nama: 'ikan mujair', harga: 100 },
    { emoji: '🐠', nama: 'ikan koi', harga: 120 },
    { emoji: '🐡', nama: 'ikan buntal', harga: 150 },
    { emoji: '🦐', nama: 'udang galah', harga: 200 },
    { emoji: '🦑', nama: 'cumi-cumi', harga: 250 },
    { emoji: '🦀', nama: 'kepiting', harga: 300 },
    { emoji: '🐙', nama: 'gurita', harga: 350 },
    { emoji: '🦞', nama: 'lobster', harga: 400 },
    { emoji: '🐬', nama: 'lumba-lumba', harga: 500 },
    { emoji: '🐋', nama: 'paus biru', harga: 600 },
    { emoji: '🐳', nama: 'paus beluga', harga: 650 },
    { emoji: '🦈', nama: 'hiu putih', harga: 700 },
    { emoji: '🦪', nama: 'kerang mutiara', harga: 800 },
    { emoji: '🪼', nama: 'ubur-ubur', harga: 900 },
];

let handler = async (m, { conn, command, args, usedPrefix }) => {
    let user = global.db.data.users[m.sender];
    user.hasilPancing = user.hasilPancing || {};
    user.alatPancing = user.alatPancing || { kail: 1, joran: 1, roll: 1, senar: 1 };
    user.money = user.money || 0;

    if (command === 'mancing') {
        const cooldown = 1800000 ; // 30 detik
        const now = Date.now();

        // Cek apakah pengguna sedang mancing
        if (global.fishingPlayers.has(m.sender)) {
            return conn.reply(m.chat, '⏳ Kamu sedang mancing! Gunakan *.strike* saat umpan dimakan ikan!', m);
        }

        // Cek cooldown
        if (user.lastmancing && (now - user.lastmancing) < cooldown) {
            let remaining = formatTime(cooldown - (now - user.lastmancing));
            return conn.reply(m.chat, `⏳ Tunggu *${remaining}* sebelum bisa mancing lagi!`, m);
        }

        user.lastmancing = now;
        await conn.sendMessage(m.chat, { 
            audio: { url: 'https://github.com/ChandraGO/Data-Jagoan-Project/raw/refs/heads/master/src/mancing.mp3' }, 
            mimetype: 'audio/mpeg', 
            ptt: true 
        });
        let sent = await conn.sendMessage(m.chat, { text: '🚣‍♂️ Pergi mancing...' });

        let frames = [
            "                          🐟                       🐠                                      \n🐡                   🦑                     🐙\n              🦀                   🐟\n\n🌿🌱🌿🌿🌱🌱🌿",
            "              🦞                      🐟                                \n   🐠               🦑            🐡\n              🦀            🦞\n\n🌿🌱🌿🌿🌱🌱🌿",
            "       🐋                 🐟                    🦑            \n             🦀            🐙            🐡\n         🐠            🦞\n\n🌿🌱🌿🌿🌱🌱🌿",
            "🐙              🦑              🦞              🐟\n         🐠              🐋            🦀\n         🦀              🦞\n\n🌿🌱🌿🌿🌱🌱🌿",
            "        🦞              🐙              🐟\n         🦀              🦑              🐡\n🐋                     🦀\n\n🌿🌱🌿🌿🌱🌱🌿"
        ];

        for (let i = 0; i < 5; i++) {
            await new Promise(res => setTimeout(res, 1500));
            let frame = frames[Math.floor(Math.random() * frames.length)];
            await conn.relayMessage(m.chat, {
                protocolMessage: {
                    key: sent.key,
                    type: 14,
                    editedMessage: { conversation: frame }
                }
            }, {});
        }

        await new Promise(res => setTimeout(res, 2000));
        await conn.relayMessage(m.chat, {
            protocolMessage: {
                key: sent.key,
                type: 14,
                editedMessage: {
                    conversation: '‼️ Umpanmu dimakan ikan!!\n> 🎣 Umpan dimakan ikan!!\n> 🎣 Umpan dimakan ikan!!\n> 🎣 Umpan dimakan ikan!!\n> 🎣 Umpan dimakan ikan!!\n\n– Cepat ketik *.strike* dalam 15 detik sebelum ikan lepas!'
                }
            }
        }, {});

        let totalLevel = (user.alatPancing.kail || 1) + (user.alatPancing.joran || 1) + 
                        (user.alatPancing.roll || 1) + (user.alatPancing.senar || 1);
        
        global.fishingPlayers.set(m.sender, {
            start: now,
            level: totalLevel,
            messageKey: sent.key
        });

        setTimeout(() => {
            if (global.fishingPlayers.has(m.sender)) {
                global.fishingPlayers.delete(m.sender);
                conn.sendMessage(m.chat, { text: '❌ Terlambat! Ikan sudah lepas. 🎣' });
            }
        }, 15000);
    }

    if (command === 'strike') {
        let info = global.fishingPlayers.get(m.sender);
        if (!info) {
            return m.reply('⚠️ Kamu belum mulai mancing atau sudah telat.\n\n> Ketik *.mancing* dulu!');
        }

        global.fishingPlayers.delete(m.sender);
        let level = info.level || 1;
        let jumlah = Math.floor(Math.random() * ((Math.floor(level / 2) + 2) - Math.floor(level / 4) + 1)) + Math.floor(level / 4);
        let hasil = ikanList[Math.floor(Math.random() * ikanList.length)];

        user.hasilPancing[hasil.emoji] = (user.hasilPancing[hasil.emoji] || 0) + jumlah;
        m.reply(`🎣 Strike berhasil!\n\n– Kamu menangkap:\n\n– ${hasil.emoji} ${hasil.nama}\n– Sebanyak ${jumlah} ekor\n\n> Level pancing: ${level}`);
    }

    if (command === 'jualikan') {
        let total = 0;
        let hasilJual = [];

        for (let ikan of ikanList) {
            let jumlah = user.hasilPancing[ikan.emoji] || 0;
            if (jumlah > 0) {
                let subtotal = jumlah * ikan.harga;
                hasilJual.push(`${ikan.emoji} x ${jumlah} = Rp${subtotal}`);
                total += subtotal;
            }
        }

        if (total === 0) {
            return conn.reply(m.chat, '❌ Kamu tidak punya hasil pancingan untuk dijual.', m);
        }

        user.money += total;
        user.hasilPancing = {};
        return conn.reply(m.chat, `✅ Berhasil menjual hasil pancingan:\n\n– ${hasilJual.join('\n')}\n\n💵 Total uang: *Rp${total}*`, m);
    }

    if (command === 'upgradepancing') {
        let pilih = args[0]?.toLowerCase();
        if (!pilih || !['kail', 'joran', 'roll', 'senar'].includes(pilih)) {
            return m.reply(`⚙️ Contoh penggunaan:\n${usedPrefix + command} kail\n${usedPrefix + command} joran\n${usedPrefix + command} roll\n${usedPrefix + command} senar`);
        }

        let levelNow = user.alatPancing[pilih];
        let biaya = levelNow * 1000;

        if (user.money < biaya) {
            return m.reply(`❌ Uang tidak cukup!\n💸 Dibutuhkan: Rp${biaya}\n💰 Uangmu: Rp${user.money}`);
        }

        user.money -= biaya;
        user.alatPancing[pilih]++;
        return conn.reply(m.chat, `✅ *${pilih.toUpperCase()}* berhasil di-upgrade ke level ${user.alatPancing[pilih]}!\n💸 -Rp${biaya}`, m);
    }

    if (command === 'pancingku') {
        let p = user.alatPancing;
        let getBar = (lvl) => {
            let filled = '■'.repeat(Math.min(lvl, 10));
            let empty = '□'.repeat(Math.max(0, 10 - lvl));
            return filled + empty;
        };

        let teks = `🎣 *Spesifikasi Alat Pancingmu* 🎣\n\n` +
            `🪝 *Kail*   : Level ${p.kail} [${getBar(p.kail)}]\n` +
            `🎣 *Joran*  : Level ${p.joran} [${getBar(p.joran)}]\n` +
            `🎡 *Roll*   : Level ${p.roll} [${getBar(p.roll)}]\n` +
            `🧵 *Senar*  : Level ${p.senar} [${getBar(p.senar)}]\n\n` +
            `⚙️ Total Kekuatan Pancing: *${p.kail + p.joran + p.roll + p.senar}*\n` +
            `💰 Uangmu: Rp${user.money.toLocaleString()}\n\n` +
            `Kamu bisa upgrade alat pancingmu dengan command:\n` +
            `*.upgradepancing kail/joran/roll/senar*`;

        return conn.reply(m.chat, teks, m);
    }
};

handler.help = ['mancing', 'strike', 'jualikan', 'upgradepancing <kail|joran|roll|senar>', 'pancingku'];
handler.tags = ['rpg'];
handler.command = /^mancing|strike|jualikan|upgradepancing|pancingku$/i;

module.exports = handler;

function formatTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return `${h} jam ${m} menit ${s} detik`;
}