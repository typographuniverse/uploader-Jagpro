let handler = async (m, { conn }) => {
      let caption = `
  Hai! Kamu Mau Beli SC Ini? hubungi creator sekarang juga
  
  Script Jagoan Project ini memiliki banyak keuntungan:
  ✅ Free Panel Selama Sebulan
  ✅ Masuk grup khusus Update dan Grup Diskusi
  ✅ Type Plugin – Bebas menambahkan fitur
  ✅ 100% NO ENC – Leluasa dimodifikasi
  ✅ Banyak fitur menggunakan scrape
  ✅ Pakai API premium yang selalu diperpanjang
  ✅ Saat ini ada total 900+ fitur
  ✅ Bebas Request Fitur
  
  Harga SC Saat Ini: *Rp. 70.000*
  Mohon hargai developer yang telah membuatnya dengan sepenuh hati! 😊
      `;

      const p = '62895362282300'; // Nomor dari URL button sebelumnya
      let pp = await conn.profilePictureUrl(`${p}@s.whatsapp.net`, 'image').catch((_) => "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/SCRIPT.png");
      let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:Jagoan;Project\nNICKNAME:🔰 DEVELOPER\nORG:Jagoan Project\nTITLE:Developer\nitem1.TEL;waid=${p}:${p}\nitem1.X-ABLabel:Contact Developer\nitem2.URL:https://wa.me/${p}\nitem2.X-ABLabel:💬 More\nitem3.EMAIL;type=INTERNET:wa.me/${p}\nitem3.X-ABLabel:Email\nitem4.ADR:;;🏴‍☠️ Indonesia;;;;\nitem4.X-ABADR:💬 More\nitem4.X-ABLabel:Lokasi\nEND:VCARD`;

      // Kirim caption dengan gambar terlebih dahulu
      const sentCaption = await conn.sendMessage(m.chat, {
        image: { url: "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/SCRIPT.png" },
        caption: caption
      }, { quoted: m });

      // Kirim kontak setelah caption
      await conn.sendMessage(m.chat, {
        contacts: {
          displayName: 'Jagoan Project',
          contacts: [{ vcard }]
        },
        contextInfo: {
          externalAdReply: {
            title: 'Script Jagoan Project',
            body: 'Chat Untuk Beli..!!',
            thumbnailUrl: pp,
            sourceUrl: null,
            mediaType: 1,
            showAdAttribution: true,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: sentCaption });
}

handler.help = ['script'];
handler.tags = ['main'];
handler.command = /^sc|script$/i;

module.exports = handler;