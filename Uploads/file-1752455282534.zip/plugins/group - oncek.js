let handler = async (m, { conn, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("❌ Fitur ini hanya bisa digunakan di dalam grup.");
    if (!(isAdmin || isOwner)) return m.reply("❌ Fitur ini hanya bisa digunakan oleh admin.");

    let chat = global.db.data.chats[m.chat];

    let fiturGrup = {
        welcome: chat.welcome,
        antilink: chat.antiLink,
        antiupsw: chat.antiupsw,
        antinomorluar: chat.antiNomorLuar,
        antipoto: chat.antiFoto,
        antisticker: chat.antiSticker,
        antinsfw: chat.antiNsfw,
        notifgempa: chat.notifgempa,
        autolevelup: chat.autolevelup,
        antisaluran: chat.antisaluran,
        antitoxic: chat.antiToxic,
        antibot: chat.antiBot,
        autosticker: chat.stiker
        
    };

    let fiturBot = {
        autoread: global.opts['autoread'],
        antispam: chat.antispam,
        pconly: global.opts['pconly'],
        gconly: global.opts['gconly'],
        swonly: chat.swonly
    };

    let aktifGrup = Object.entries(fiturGrup)
        .filter(([_, status]) => status)
        .map(([feature]) => `✅ ${feature}`)
        .join("\n") || "Tidak ada fitur yang aktif.";

    let nonaktifGrup = Object.entries(fiturGrup)
        .filter(([_, status]) => !status)
        .map(([feature]) => `❌ ${feature}`)
        .join("\n") || "Semua fitur aktif.";

    let aktifBot = Object.entries(fiturBot)
        .filter(([_, status]) => status)
        .map(([feature]) => `✅ ${feature}`)
        .join("\n") || "Tidak ada fitur bot yang aktif.";

    let nonaktifBot = Object.entries(fiturBot)
        .filter(([_, status]) => !status)
        .map(([feature]) => `❌ ${feature}`)
        .join("\n") || "Semua fitur bot aktif.";

    let message = `📌 *Status Fitur Grup*\n\n*Aktif:*\n${aktifGrup}\n\n*Nonaktif:*\n${nonaktifGrup}\n\n⚙ *Status Fitur Bot*\n\n*Aktif:*\n${aktifBot}\n\n*Nonaktif:*\n${nonaktifBot}`;
    m.reply(message);
};


handler.help = ['oncek'];
handler.tags = ['group'];
handler.command = /^oncek$/i;

module.exports = handler;
