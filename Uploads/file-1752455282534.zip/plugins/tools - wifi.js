let handler = (m, { text, usedPrefix, command }) => {
    if (!text) throw '_Masukkan nama wifi!_\n\nContoh:\n' + usedPrefix + command + ' fh_8eaf58';

    // Validasi format wifi harus diawali "fh_" diikuti 6 karakter
    if (!/^fh_[0-9a-f]{6}$/.test(text.toLowerCase())) {
        throw '_Format nama wifi salah!_\nGunakan format: fh_xxxxxx (6 karakter setelah fh_)';
    }

    // Dictionary enkripsi
    const encryptDict = {
        '1': 'e', '2': 'd', '3': 'c', '4': 'b', '5': 'a',
        '6': '9', '7': '8', '8': '7', '9': '7', '0': 'f',
        'f': '0', 'e': '1', 'a': '5'
    };

    // Dictionary dekripsi (untuk mencari kemungkinan balik)
    const decryptDict = {
        'e': ['1'], 'd': ['2'], 'c': ['3'], 'b': ['4'], 'a': ['5'],
        '9': ['6'], '8': ['7'], '7': ['8', '9'], 'f': ['0'], '0': ['f'],
        '1': ['e'], '5': ['a']
    };

    // Ambil bagian kode setelah "fh_"
    let code = text.toLowerCase().slice(3); // fh_ dihapus, ambil 6 karakter setelahnya
    let encrypted = 'wlan'; // Prefix password

    // Enkripsi kode ke password
    encrypted += code.split('').map(char => encryptDict[char] || char).join('');

    // Mencari kemungkinan password lain (dekripsi balik)
    let possibilities = [''];
    code.split('').forEach(char => {
        let options = decryptDict[encryptDict[char]] || [char];
        let newPossibilities = [];
        possibilities.forEach(p => {
            options.forEach(o => {
                newPossibilities.push(p + o);
            });
        });
        possibilities = newPossibilities;
    });

    // Format hasil dengan emoticon
    let result = `🌐 *Nama Wifi:* ${text}\n🔑 *Password Utama:* ${encrypted}\n\n`;
    
    if (possibilities.length > 1) {
        result += '🔍 *Kemungkinan Password Lain:*\n';
        possibilities.forEach((opt, i) => {
            if ('wlan' + opt !== encrypted) {
                result += `${i + 1}. wlan${opt}\n`;
            }
        });
    }

    result += '\n✨ Gunakan password dengan bijak ya!';

    m.reply(result);
};

handler.tags = ['tools', 'fun'];
handler.command = ['wifi'];
handler.help = ['wifi <fh_xxxxxx>'];
module.exports = handler;