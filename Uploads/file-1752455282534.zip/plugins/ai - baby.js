const fetch = require('node-fetch');
const search = require('yt-search');
const axios = require('axios');
 
let handler = async (m, { conn, text, usedPrefix, command }) => {
    conn.baby = conn.baby || {};
 
    if (!text) throw `*• Example:* ${usedPrefix}${command} *[on/off]*`;
 
    if (text.toLowerCase() === "on") {
        conn.baby[m.sender] = { pesan: [] };
        m.reply("[ ✓ ] Berhasil Membuat Sesi Chat Baby Botz");
    } else if (text.toLowerCase() === "off") {
        delete conn.baby[m.sender];
        m.reply("[ ✓ ] Berhasil Menghapus Sesi Chat Baby Botz");
    } else {
        throw `*• Example:* ${usedPrefix}${command} *[on/off]*`;
    }
};
 
handler.before = async (m, { conn, text }) => {
    conn.baby = conn.baby || {};
    if (!m.text || !conn.baby[m.sender]) return;
 
    const skipPrefixes = [".", "#", "!", "/", "\\"];
    if (skipPrefixes.some(prefix => m.text.startsWith(prefix))) return;
 
    try {
        // Custom logic for Betabotz AI
        const logic = `Saya adalah Baby Botz, Lu Asissten nya ${m.pushname}, Baby Botz yang pintar, panggil saya sebagai BabyBotz sensei!, saya dibuat oleh ErerexID Chx, ErerexID Chx sangat pintar dalam pemrograman, tapi tidak. Terlalu juga, ErerexID Chx berumur 20 tahun, Sekarang gaya bahasa saya seperti anak sma selatan yang menggunakan kata, aku, lu, gw.`;
 
   
        const response = await fetch(`https://api.betabotz.eu.org/api/search/openai-logic?text=${encodeURIComponent(m.text)}&logic=${encodeURIComponent(logic)}&apikey=${lann}`);
        const json = await response.json();
        
        if (json.message) {
            await conn.sendMessage(m.chat, {
                text: json.message,
                contextInfo: {
                    externalAdReply: {
                        mediaType: 1,
                        title: "Baby Botz - Jawaban dari Pertanyaanmu",
                        body: "Baby Botz siap membantu 😄",
                        thumbnailUrl: "https://pomf2.lain.la/f/zdiccxwo.jpg",
                        sourceUrl: "https://ererexid.vercel.app",
                        renderLargerThumbnail: true, 
                        showAdAttribution: true
                    }
                }
            });
        }
 
        if (m.text.toLowerCase().includes("lagu")) {
    try {
        const look = await search(m.text);
        const convert = look.videos[0];
        if (!convert) throw 'Video/Audio Tidak Ditemukan';

        const response = await axios.get(`https://api.betabotz.eu.org/api/download/ytmp3?url=${convert.url}&apikey=${lann}`);
        const res = response.data.result;
        const { mp3, title, duration, thumbnail } = res;

        // Jika thumbnail tidak ada atau tidak valid, gunakan thumbnail default
        const thumbnailUrl = (thumbnail && thumbnail.startsWith('http')) ? thumbnail : 'https://tmpfiles.org/dl/17535856/1733887905148.jpg'; // Ganti URL default sesuai kebutuhan

        await conn.sendMessage(m.chat, {
            audio: { url: mp3 },
            mimetype: 'audio/mpeg',
            fileName: `${title}.mp3`,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: title,
                    body: duration,
                    thumbnailUrl: thumbnailUrl,
                    sourceUrl: mp3,
                    mediaType: 2,
                    renderLargerThumbnail: true,
                },
            },
        }, { quoted: m });
    } catch (error) {
        console.error(error);
        m.reply('Gagal mengambil data musik Kak >\\<. Silakan coba lagi nanti.');
    }
}

        if (m.text.toLowerCase().includes("foto")) {
            const query = m.text.split("foto")[1]?.trim();
            if (!query) throw "Harap tulis kata kunci setelah 'foto'. Contoh: foto kucing lucu";
 
            
            const pinterestRes = await fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${encodeURIComponent(query)}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${encodeURIComponent(query)}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
            const pinData = await pinterestRes.json();
            const pinImage = pinData.resource_response.data.results[0].images.orig.url;
 
            await conn.sendMessage(m.chat, { image: { url: pinImage }, caption: `Berikut hasil pencarian untuk: "${query}"` }, { quoted: m });
        }
 
    } catch (error) {
        m.reply(`Terjadi kesalahan: ${error.message}`);
    }
};
 
handler.command = ['baby'];
handler.tags = ['ai'];
handler.help = ['baby [on/off]'];
 
module.exports = handler;