// ✨ Plugin rpg - mobil - balap ✨

// ✨ Plugin rpg - mobil - balap ✨

let balapMobilRooms = {};

let handler = async (m, { conn, args, usedPrefix }) => { let user = global.db.data.users[m.sender];

if (!user.cars || user.cars.length === 0) {
    return conn.reply(m.chat, '🥲 Kamu tidak memiliki mobil untuk balapan!', m);
}

if (!args.length) {
    return conn.reply(m.chat,
        `❌ Format salah!

Gunakan :

> ${usedPrefix}balapmobil buat - buat room balapan\n> ${usedPrefix}balapmobil ikut <mobil> - ikut balapan\n> ${usedPrefix}balapmobil mulai - mulai balapan\n> ${usedPrefix}balapmobil hapus - hapus room balapan`, m); }

let action = args[0].toLowerCase();

if (action === 'buat') {
    if (balapMobilRooms[m.chat]) {
        return conn.reply(m.chat, '🚧 Room balap telah dibuatl\n\nKetik :\n\n> .balapmobil ikut <mobil> untuk ikut balapan.', m);
    }
    balapMobilRooms[m.chat] = { players: [], started: false };
    return conn.reply(m.chat, '🏁 Room balap mobil telah dibuat!\n\nKetik :\n\n> .balapmobil ikut <mobil> untuk ikut balapan.', m);
}

if (action === 'ikut') {
    if (!balapMobilRooms[m.chat] || balapMobilRooms[m.chat].started) {
        return conn.reply(m.chat, '⚠️ Tidak ada room balap yang tersedia.\n\n Buat dengan :\n\n> .balapmobil buat', m);
    }
    if (balapMobilRooms[m.chat].players.some(player => player.id === m.sender)) {
        return conn.reply(m.chat, '🏁 Kamu sudah terdaftar dalam balapan ini.', m);
    }

    let carChoice = args.slice(1).join(" ");
    if (!carChoice) {
        return conn.reply(m.chat, '❌ Pilih mobil yang kamu miliki!\n\n Contoh :\n\n> .balapmobil ikut Rolls-Royce Phantom', m);
    }

    let userCar = user.cars.find(car => car.toLowerCase() === carChoice.toLowerCase());
    if (!userCar || (user.carHealth[userCar] && user.carHealth[userCar] < 80)) {
        return conn.reply(m.chat, '❌ Mobil tidak ditemukan atau kesehatannya kurang dari 80%!', m);
    }

    balapMobilRooms[m.chat].players.push({ id: m.sender, car: userCar, level: user.carLevel[userCar] || 1 });
    return conn.reply(m.chat, `✅ Berhasil Bergabung!\n\n 🧑🏻‍🦰 pembalap : @${m.sender.split('@')[0]}\n 🚘 mobil : ${userCar}`, m, { mentions: [m.sender] });
}

if (action === 'mulai') {
    if (!balapMobilRooms[m.chat] || balapMobilRooms[m.chat].started) {
        return conn.reply(m.chat, '⚠️ Tidak ada balapan yang bisa dimulai!', m);
    }
    if (balapMobilRooms[m.chat].players.length < 2) {
        return conn.reply(m.chat, '❌ Minimal 2 peserta untuk memulai balapan.', m);
    }

    balapMobilRooms[m.chat].started = true;
    conn.reply(m.chat, '_🏁 Balapan dimulai! 3... 2... 1... GO!_', m);

    let progressMessages = [
        '🚗💨 Semua pembalap mulai melaju dengan kecepatan tinggi!',
        '⚡ Tikungan pertama! Siapa yang akan menyalip?',
        '🔥 Aksi drift memukau! Salah satu mobil hampir kehilangan kendali!',
        '💥 Sebuah mobil hampir menabrak pembatas jalan, tapi berhasil menghindar!',
        '🚀 NOS diaktifkan! Mobil melesat dengan kecepatan penuh!',
        '🔄 Tikungan tajam! Beberapa pembalap harus mengerem mendadak!',
        '🏁 Garis finish semakin dekat! Semua pembalap berusaha keras!',
        '🏆 Semua pembalap sudah mencapai Finish, balapan berakhir!!'
    ];

    for (const message of progressMessages) {
        await new Promise(resolve => setTimeout(resolve, 3000));
        conn.reply(m.chat, message, m);
    }

    let sortedPlayers = balapMobilRooms[m.chat].players.sort((a, b) => b.level - a.level);
    let winners = sortedPlayers.slice(0, 3);
    let rewards = [2000, 1500, 1000];
    let xpRewards = [100, 70, 50];

    let resultText = '🏆 Hasil Balapan:\n';
    winners.forEach((player, index) => {
        let userWinner = global.db.data.users[player.id];
        userWinner.money = (userWinner.money || 0) + rewards[index];
        userWinner.exp = (userWinner.exp || 0) + xpRewards[index];
        userWinner.carHealth[player.car] = Math.max((userWinner.carHealth[player.car] || 100) - (Math.floor(Math.random() * 15) + 5), 0);
        resultText += `🥇${index + 1}. @${player.id.split('@')[0]}\n - 💰 +${rewards[index]} | 🏅 +${xpRewards[index]} XP\n`;
    });

    conn.reply(m.chat, resultText, m, { mentions: winners.map(p => p.id) });
    delete balapMobilRooms[m.chat];
}

if (action === 'hapus') {
    if (!balapMobilRooms[m.chat]) {
        return conn.reply(m.chat, '⚠️ Tidak ada room balap yang bisa dihapus!', m);
    }
    delete balapMobilRooms[m.chat];
    return conn.reply(m.chat, '🚮 Room balapan telah dihapus.', m);
}

};

handler.help = ['balapmobil buat', 'balapmobil hapus', 'balapmobil ikut <mobil>', 'balapmobil mulai']; handler.tags = ['rpg']; handler.command = /^balapmobil$/i; handler.group = true;

module.exports = handler;