let ms = require('ms');

let handler = async (m, { conn }) => {
    let users = global.db.data.users;
    let chats = global.db.data.chats;

    // Auto unban jika waktu habis
    for (let [id, u] of Object.entries(users)) {
        if (u.banned && u.bannedUntil && Date.now() >= u.bannedUntil) {
            u.banned = false;
            delete u.bannedUntil;
        }
    }

    for (let [id, c] of Object.entries(chats)) {
        if (c.isBanned && c.bannedUntil && Date.now() >= c.bannedUntil) {
            c.isBanned = false;
            delete c.bannedUntil;
        }
    }

    // Filter berdasarkan tipe ID
    let bannedUsers = Object.entries(users).filter(([jid, data]) => jid.endsWith('@s.whatsapp.net') && data.banned);
    let bannedChats = Object.entries(chats).filter(([jid, data]) => jid.endsWith('@g.us') && data.isBanned);

    let teks = `┏━━━〔 *BANNED CHAT LIST* 〕━━━━┓\n┃\n`;
    teks += `┃  🌍 *total banned chat :* ${bannedChats.length} chat\n`;
    if (bannedChats.length === 0) {
        teks += `┃  tidak ada chat yang dibanned.\n`;
    } else {
        let no = 1;
        for (let [jid] of bannedChats) {
            teks += `┃  ${no++}. 🏘️ ${jid}\n`;
        }
    }
    teks += `┃\n┗━━━━━━━━━━━━━━━━━━━┛\n\n`;

    teks += `┏━━━〔 *BANNED USERS LIST* 〕━━━┓\n┃\n`;
    teks += `┃  🧌 *total banned users :* ${bannedUsers.length} user\n`;
    if (bannedUsers.length === 0) {
        teks += `┃  tidak ada user yang dibanned.\n`;
    } else {
        let no = 1;
        for (let [jid, data] of bannedUsers) {
            let dur = data.bannedUntil
                ? ms(data.bannedUntil - Date.now(), { long: true })
                : 'permanent';
            let name = data?.name || 'unknown';
            teks += `┃  ${no++}. ${name}\n`;
            teks += `┃   🪀 https://wa.me/${jid.split('@')[0]}\n`;
            teks += `┃   ⏳ *durasi :* ${dur}\n`;
        }
    }
    teks += `┃\n┗━━━━━━━━━━━━━━━━━━━┛`;

    m.reply(teks);
};

handler.help = ['listban'];
handler.tags = ['owner'];
handler.command = /^listban$/i;
handler.rowner = true;

module.exports = handler;