/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

const fs = require('fs').promises;
const path = require('path');

const handler = async (m, { text, conn }) => {
  try {
    if (!text) {
      return conn.sendMessage(m.chat, {
        text: `❌ Format perintah salah!\n\n📌 *Gunakan format berikut:*\n.hbd Judul|Pesan1|Pesan2|Pesan3|Pesan4|Pesan5|628xxxx|NamaPengirim\n\n📍 *Contoh:*\n.hbd Happy Birthday|Semoga sehat|Panjang umur|Selalu bahagia|Dimudahkan rezekinya|Aamiin|6281234567890|Ardiansyah`,
        contextInfo: {
          externalAdReply: {
            title: 'Format Salah 😓',
            body: 'Contoh lengkap ada di sini ⬇️',
            thumbnailUrl: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1752328512430.jpeg',
            sourceUrl: 'https://baca mek/' + m.sender.replace('@s.whatsapp.net', ''),
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true
          }
        }
      }, { quoted: m });
    }

    const [judul, p1, p2, p3, p4, p5, nomor, nama] = text.split('|');
    if (![judul, p1, p2, p3, p4, p5, nomor, nama].every(Boolean)) {
      return conn.sendMessage(m.chat, {
        text: `⚠️ *Semua bagian wajib diisi!*\n\nGunakan format:\n.hbd Judul|Pesan1|Pesan2|Pesan3|Pesan4|Pesan5|628xxxx|NamaPengirim\n\n📝 *Contoh:*\n.hbd Happy Birthday|Semoga sehat|Panjang umur|Selalu bahagia|Dimudahkan rezekinya|Aamiin|6281234567890|Ardiansyah`,
        contextInfo: {
          externalAdReply: {
            title: 'Format Belum Lengkap 😬',
            body: 'Perbaiki format sesuai contoh ya!',
            thumbnailUrl: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1752328512430.jpeg',
            sourceUrl: 'https://baca mek/' + m.sender.replace('@s.whatsapp.net', ''),
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true
          }
        }
      }, { quoted: m });
    }

    const musik = 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1752324733301.mpeg';
    const pesanList = [p1, p2, p3, p4, p5];

    const pesanHtml = pesanList.map(p => `<p data-aos="zoom-in">${p}</p>`).join('\n    ') + `
    <p data-aos="zoom-in">💓 Pencet Love dulu 
      <i onclick="tanya()"> "💓" </i>
    </p>`;

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>${judul}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet" />
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.4/dist/sweetalert2.all.min.js"></script>
  <style>
    html { scroll-behavior: smooth; }
    * { padding: 0; margin: 0; font-family: "Ubuntu"; color: rgb(56, 56, 56); }
    body {
      background: linear-gradient(#ff71c0, #b983ff, #5aaeff);
      background-position: center;
      background-size: cover;
      overflow: hidden;
    }
    .open {
      background-image: linear-gradient(#ff71c0, #b983ff);
      height: 100vh;
      width: 100vw;
      position: fixed;
      top: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      z-index: 1;
    }
    .open .card {
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 10px 10px 30px rgba(0, 0, 0, 0.123);
      text-align: center;
    }
    .open .card img {
      height: 100px;
      background: white;
      border-radius: 20px;
    }
    .atas {
      height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
    .atas img {
      height: 200px;
      margin-bottom: 50px;
      padding: 20px 30px;
      background: white;
      border-radius: 20px;
      box-shadow: 10px 10px 30px rgba(0, 0, 0, 0.123);
    }
    .atas h2 {
      font-size: 1.5em;
      padding: 20px 30px;
      background: white;
      border-radius: 20px;
      box-shadow: 10px 10px 30px rgba(0, 0, 0, 0.123);
    }
    p {
      text-align: center;
      background: white;
      font-weight: bold;
      font-size: 1.5em;
      padding: 50px 30px;
      margin: 40px 20px;
      border-radius: 20px;
      box-shadow: 10px 10px 30px rgba(0, 0, 0, 0.123);
    }
    p.wm {
      margin-top: 70px;
      padding: 25px;
      border-radius: 20px 20px 0 0;
      font-weight: 500;
      font-size: 1.1em;
      color: red;
      text-align: center;
    }
    p.wm a {
      color: red;
      text-decoration: none;
    }
    i {
      cursor: pointer;
      font-style: normal;
      color: red;
      font-size: 1.2em;
      animation: kenyal 2s ease infinite;
    }
    @keyframes kenyal {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.2); }
    }
  </style>
</head>
<body class="body">
  <audio class="audio" src="${musik}" autoplay loop></audio>

  <div class="open">
    <div class="card">
      <h2>📩 Ada pesan buat kamu</h2>
      <img onclick="mulai()" src="https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1752326174084.png" />
      <h3>👇 Tekan untuk membuka 👇</h3>
    </div>
  </div>

  <div class="atas" id="atas">
    <img onclick="mulai()" src="https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1752326347175.gif" />
    <h2>🌸 Scroll kebawah ya 🥰</h2>
  </div>

  ${pesanHtml}

  <script>
    AOS.init({ once: true });
    const audio = document.querySelector(".audio");
    function mulai() {
      audio.play();
      document.querySelector(".open").style.display = "none";
      document.querySelector(".body").style.overflowY = "scroll";
    }
    function wa(isi) {
      window.open("https://wa.me/${nomor}?text=" + encodeURIComponent(isi));
    }
    async function tanya() {
      const { value: kado } = await Swal.fire({
        title: "💌 Pastikan yang buka ini Sayangnya Akuuu",
        input: "text",
        inputPlaceholder: "Tulis jawaban kamu di sini",
        confirmButtonText: "Kirim ke WA aku",
        showCancelButton: false,
      });
      if (kado) {
        await Swal.fire("🎁 Kirim jawabannya ke wa aku ya 😍");
        wa(kado);
      } else {
        await Swal.fire("😢 Jangan dikosongin dong 😭");
        tanya();
      }
    }
  </script>

  <p class="wm"><a href="https://wa.me/${nomor}">From : ${nama}</a></p>
</body>
</html>`;

    const fileName = `hbd_${Date.now()}.html`;
    const filePath = path.join(__dirname, fileName);
    await fs.writeFile(filePath, html);

    await conn.sendMessage(m.chat, {
      document: { url: filePath },
      mimetype: 'text/html',
      fileName: '🎉 Kado Ulang Tahun.html',
      caption: `🎊 *HTML Kado Ulang Tahun berhasil dibuat!* 🎊\n📤 Dari: ${nama} (wa.me/${nomor})\n\n✨ Buka file di browser untuk melihat hasilnya!`
    }, { quoted: m });

    setTimeout(() => fs.unlink(filePath).catch(console.error), 10_000);
  } catch (err) {
    console.error(err);
    m.reply(typeof err === 'string' ? err : '❌ Terjadi kesalahan saat membuat HTML.');
  }
};

handler.command = /^hbd|tohbd$/i;
handler.tags = ['web','premium'];
handler.limit = 10
handler.help = ['hbd Judul|Pesan1|Pesan2|Pesan3|Pesan4|Pesan5|628xxxx|NamaPengirim'];

module.exports = handler;
