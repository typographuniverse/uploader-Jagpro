const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');

// Main Handler
let handler = async (m, { conn, text }) => {
    if (!text) return m.reply('Masukkan URL video Nekopoi yang ingin Anda download.\n*Contoh:*\n > .nekopoi https://nekopoi.care/view/video-URL');

    try {
        const result = await getVideo(text);
        let message = `\`[ Video Metadata ]\`\n\n`;
        message += `> *- Title:* ${result.title}\n`;
        message += `> *- Links:* \n${result.links.join('\n')}`;

        await m.reply(message);

        // Download the video
        const videoUrl = result.links[0]; // Use the first link for the video
        const videoPath = path.resolve(__dirname, 'temp-video.mp4');
        const writer = fs.createWriteStream(videoPath);

        const response = await axios({
            url: videoUrl,
            method: 'GET',
            responseType: 'stream',
        });

        response.data.pipe(writer);

        writer.on('finish', async () => {
            await conn.sendFile(m.chat, videoPath, 'video.mp4', 'Here is your Nekopoi video!', m);
            fs.unlinkSync(videoPath); // Delete the temporary video file
        });

        writer.on('error', (error) => {
            throw new Error('Gagal mengunduh video');
        });
    } catch (error) {
        await m.reply(m.chat, `Gagal mengambil data: ${error.message}`);
    }
};

handler.command = /^(nekopoi)$/i;
handler.help = ["nekopoi [URL Video]"];
handler.tags = ["downloader","premium"];
handler.premium = true;

module.exports = handler;

// Function to get the latest videos from Nekopoi
const getLatest = () => new Promise((resolve, reject) => {
    const url = 'http://nekopoi.care';
    axios.get(url)
        .then((req) => {
            const title = [];
            const link = [];
            const image = [];
            const soup = cheerio.load(req.data);
            soup('div.eropost').each((i, e) => {
                soup(e).find('h2 a').each((j, s) => {
                    title.push(soup(s).text().trim());
                    link.push(soup(s).attr('href'));
                });
                image.push(soup(e).find('img').attr('src'));
            });
            if (title.length === 0) {
                reject('No result :(');
            } else {
                let i = Math.floor(Math.random() * title.length);
                let hehe = {
                    "title": title[i],
                    "image": image[i],
                    "link": link[i]
                };
                resolve(hehe);
            }
        })
        .catch((err) => reject(err));
});

// Function to get Nekopoi video metadata
const getVideo = (url) => new Promise((resolve, reject) => {
    axios.get(url)
        .then((req) => {
            try {
                const links = [];
                const soup = cheerio.load(req.data);
                const title = soup("title").text();
                soup('div.liner').each((i, e) => {
                    soup(e).find('div.listlink a').each((j, s) => {
                        links.push(soup(s).attr('href'));
                    });
                });
                const data = {
                    "title": title,
                    "links": links
                };
                resolve(data);
            } catch (err) {
                reject(err);
            }
        })
        .catch((err) => reject(err));
});