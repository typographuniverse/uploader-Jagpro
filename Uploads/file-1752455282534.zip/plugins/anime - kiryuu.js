const {
    searchKiryuu,
    getKiryuuDetail,
    getDownloadLink,
    downloadFile,
    deleteFile,
    nazandCounter
} = require('../scrape/kiryuu');

let handler = async (m, { conn, args }) => {
    try {
        if (args.length === 0) {
            return conn.sendMessage(m.chat, {
                text: `Salah
                ☘️ Example:
                - 📌kiryuu search query
                - 📌kiryuu detail url
                - 📌kiryuu download url`
            }, { quoted: m });
        }

        if (args[0] === 'search') {
            const query = args.slice(1).join(' ');
            const results = await searchKiryuu(query);
            if (results.length === 0) {
                return conn.sendMessage(m.chat, { text: 'Tidak ada hasil untuk pencarian tersebut.' }, { quoted: m });
            }
            const message = results.map((result, index) => {
                return `- ${index + 1}. *${result.title}*\nLink: ${result.link}`;
            }).join('\n\n');
            return conn.sendMessage(m.chat, { text: message }, { quoted: m });
        } else if (args[0] === 'detail') {
            const url = args[1];
            const detail = await getKiryuuDetail(url);
            if (!detail) {
                return conn.sendMessage(m.chat, { text: 'Detail manga tidak ditemukan.' }, { quoted: m });
            }

            const message = `
*Title:* ${detail.title}
*Chapters:* ${detail.chapters.length} chapters
            `.trim();
            return conn.sendMessage(m.chat, { text: message }, { quoted: m });
        } else if (args[0] === 'download') {
            const url = args[1];
            const downloadLink = await getDownloadLink(url);
            if (!downloadLink) {
                return conn.sendMessage(m.chat, { text: 'Link download tidak ada.' }, { quoted: m });
            }
            const detail = await getKiryuuDetail(url);
            const chapter = detail.chapters[0];
            const filename = `${detail.title.replace(/[^a-zA-Z0-9]/g, '-')}-chapter1-${nazandCounter}.zip`;
            await downloadFile(downloadLink, filename);
            nazandCounter++;

            await conn.sendMessage(m.chat, {
                document: { url: `./${filename}` },
                mimetype: 'application/zip',
                fileName: filename
            }, { quoted: m });
            await deleteFile(filename);
        }

        return conn.sendMessage(m.chat, {
            text: `Salah
            ☘️ Example:
            - 📌kiryuu search query
            - 📌kiryuu detail url
            - 📌kiryuu download url`
        }, { quoted: m });

    } catch (error) {
        console.error(error);
        return conn.sendMessage(m.chat, { text: `${error.message}` }, { quoted: m });
    }
};

handler.command = ['kiryuu'];
handler.tags = ['anime'];
handler.help = ['kiryuu search query', 'kiryuu detail link', 'kiryuu download link'];
handler.limit = true;

module.exports = handler;