let handler = async (m, { conn, text, participants, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("Fitur ini hanya bisa digunakan di grup!");
    if (!isAdmin && !isOwner) return m.reply("Hanya admin yang bisa menggunakan perintah ini!");

    let member = participants.map(v => v.id) || []; // Ambil semua ID anggota grup

    let sentMessage = await conn.sendMessage(m.chat, { 
        text: text || ' ', // Tetap kirim pesan meskipun kosong
        mentions: member // Gunakan array langsung, tidak perlu spread operator
    }, { quoted: m });

    // Kirim reaksi ke pesan bot sendiri
    await conn.sendMessage(m.chat, { 
        react: { text: "📢", key: sentMessage.key } // Reaksi dengan emoji pengeras suara
    });

    if (handler.deleteUserMessage) {
        await conn.sendMessage(m.chat, { delete: m.key }); // Hapus pesan pengguna
    }
}

handler.help = ['hidetag <pesan>', 'h <pesan>', 'ht <pesan>']
handler.tags = ['group']
handler.command = /^(h|ht|hidetag)$/i

handler.group = true
handler.admin = true // Hanya bisa digunakan oleh admin grup

handler.deleteUserMessage = true; // Ubah ke false jika tidak ingin menghapus pesan pengguna

module.exports = handler;