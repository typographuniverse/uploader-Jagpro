const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter');  // Contoh library sticker

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        // Daftar beberapa gambar URL
        const imageUrls = [
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/44603fec75c46245262c36987492a61d.gif',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/702cff463734295a5f153e01b8714d95.jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/7752b14b010db94a40132bf4f7aede8f.jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/be145984-dc31-48e7-a38f-c973c1830e21.png',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/cf1d844923f2756b7eba69475d282938.jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/doigts-du-milieu-baisez-hors-bande-dessinee-humor.jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/702cff463734295a5f153e01b8714d95.jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images%20(6).jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images%20(5).jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images%20(4).jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images%20(3).png',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images%20(3).jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images%20(2).png',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images%20(2).jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images%20(1).png',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images%20(1).jpg',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/pngtree-angry-cartoon-illustration-to-create-angry-stickerfree-vector-png-image_6819886.png',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/main.png',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/main%20(2).png',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/main%20(1).png',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images.png',
    'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/marah/images.jpg'
];


        // Pilih gambar secara acak dari daftar
        const randomImageUrl = imageUrls[Math.floor(Math.random() * imageUrls.length)];

        const response = await axios.get(randomImageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data);

        // Konversi menjadi sticker menggunakan library sticker Anda
        const stiker = new Sticker(buffer, {
            packname: global.packname,
            author: global.author
        });

        const stickerBuffer = await stiker.toBuffer();  // Konversi menjadi buffer

        // Kirim sticker
        await conn.sendFile(m.chat, stickerBuffer, 'sticker.webp', '', m);
    } catch (error) {
        console.error(error);
        throw new Error('Gagal membuat sticker');
    }

    // Mengambil nama pengirim (atau nomor jika tidak ada nama)
    const pushname = m.pushName || m.sender.split('@')[0];

    // 20 respon marah kepada pengguna yang men-tag owner
    const responses = [
        `Apa tag-tag ownerku, jangan tag ownerku sembarangan, ${pushname} ! sini lo semua  😡`,
        `Woi ${pushname}, jangan sembarangan tag ownerku! 😠`,
        `Gak boleh gitu loh, ${pushname}! Tag sang raja adalah bentuk ketidaksopanan! 🖕🏻`,
        `${pushname}!!! Jangan tag owner sembarangan, sadar diri aja, lu itu babu saya kayak gue 😤`,
        `Sini lo semua, jangan seenaknya tag owner ownerku, kau lagi ${pushname} 😡`,
        `Apa lo ${pushname} tag owner  tanpa izin! 😠`,
        `Tag ownerku.!! gak pake sopan, ${pushname}! 😤`,
        `Apa lo pikir owner bisa sembarangan lo tag, ${pushname}? 😡`,
        `Ayo kelai ${pushname}, ngapain lo tag owner gue?! 😡`,
        `Jangan suka tag owner sembarangan, ${pushname}! 🖕🏻`,
        `Jangan cuma tag owner gitu aja, ${pushname}, lo harus izin sama gua! 😡`,
        `Tahu diri dikit ${pushname}, tag owner sembarangan gitu ada pasalnya! 😠`,
        `Lo pada kira owner itu siapa? Jangan asal tag, ${pushname}! 😡`,
        `Udah, jangan banyak tag owner sembarangan, ${pushname}! 😤`,
        `Tag owner harus sopan, jangan seenaknya, ${pushname}! 😡`,
        `Kapan lo pada tahu sopan? hah?  ${pushname}, gak bisa gitu tag owner! 😠`,
        `Sini lo, ${pushname}, lo pikir owner gw itu siapa lo? 🖕🏻`,
        `Bisa-bisanya lo tag owner tanpa permisi, ${pushname}! 😠`,
        `Eh ${pushname}, lain kali jangan tag ownerku sembarangan! 😡`,
        `Tolong, jangan tag Paduka sembarangan, ${pushname}! 😤`
    ];

    // Pilih respons secara acak
    const response = responses[Math.floor(Math.random() * responses.length)];

    // Kirim pesan teks marah (pastikan format yang benar)
    const messageContent = {
        text: response,  // Tambahkan properti 'text' di sini
        quoted: m        // Agar pesan ini menjadi balasan terhadap pesan yang ada
    };

    await conn.sendMessage(m.chat, messageContent);
}

// Buat regex dinamis berdasarkan global.owner
const ownerNumbers = global.owner.map(([number]) => `@${number}`).join('|');
handler.customPrefix = new RegExp(ownerNumbers, 'i');
handler.command = new RegExp();

module.exports = handler;