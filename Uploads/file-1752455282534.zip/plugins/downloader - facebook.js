const fetch = require('node-fetch');

let handler = async (m, { conn, args, usedPrefix, command }) => {  
    if (!args[0]) throw `Gunakan contoh ${usedPrefix}${command} https://www.facebook.com/watch/?v=1393572814172251`;

    try {
        await m.reply('🔄 Sedang memproses link, mohon tunggu...');

        // Try AIO API first (primary)
        try {
            const res = await fetch(`https://r-nozawa.hf.space/aio?url=${encodeURIComponent(args[0])}`);
            const json = await res.json();

            if (json.error) throw new Error(json.message || 'URL tidak valid atau tidak didukung.');

            if (!json.medias || !Array.isArray(json.medias) || json.medias.length === 0) {
                throw new Error('Tidak menemukan media untuk didownload.');
            }

            // Send all available media
            for (let i = 0; i < json.medias.length; i++) {
                const media = json.medias[i];
                let mediatype = media.type || 'media';
                let resulturl = media.url;
                let quality = media.quality || `Media-${i + 1}`;

                if (!resulturl) continue; // Skip if no URL

                let caption = `*Facebook Downloader (AIO API)*\n\n*Judul:* ${json.title || '-'}\n*Source:* ${json.source || '-'}\n*Tipe:* ${mediatype}\n*Media:* ${quality}`;

                if (mediatype === 'image') {
                    await conn.sendMessage(m.chat, { image: { url: resulturl }, caption }, { quoted: m });
                } else if (mediatype === 'video') {
                    await conn.sendMessage(m.chat, { video: { url: resulturl }, caption }, { quoted: m });
                } else if (mediatype === 'audio') {
                    await conn.sendMessage(m.chat, { audio: { url: resulturl }, mimetype: 'audio/mp4' }, { quoted: m });
                } else {
                    await conn.sendMessage(m.chat, { document: { url: resulturl }, fileName: `result-${i + 1}.${media.extension || 'file'}`, caption }, { quoted: m });
                }
            }

            await m.reply('✅ Proses download selesai.');
            return; // Exit after successful AIO download
        } catch (aioError) {
            console.log('AIO API Error:', aioError);
            console.log('Mencoba fallback ke Botcha API...');
        }

        // Fallback to Botcha APIs (fbdown4, fbdown3, fbdown2, fbdown)
        const apiEndpoints = ['fbdown4', 'fbdown3', 'fbdown2', 'fbdown'];

        for (const endpoint of apiEndpoints) {
            try {
                const res = await fetch(`${global.apibtc}/api/dowloader/${endpoint}?url=${args[0]}&apikey=${btc}`);
                const json = await res.json();

                if (!json.status || json.result.status !== 'success') {
                    throw new Error(`API ${endpoint} mengembalikan status gagal.`);
                }

                let urls = json.result.url.urls;
                if (!Array.isArray(urls) || urls.length === 0) {
                    throw new Error(`Tidak dapat mendapatkan URL video dari ${endpoint}.`);
                }

                let sent = false;
                for (let url of urls) {
                    if (url.hd) {
                        await conn.sendFile(m.chat, url.hd, 'fb_hd.mp4', `*Facebook Downloader (Botcha ${endpoint.toUpperCase()} API) - HD*`, m);
                        sent = true;
                        break;
                    } else if (url.sd) {
                        await conn.sendFile(m.chat, url.sd, 'fb_sd.mp4', `*Facebook Downloader (Botcha ${endpoint.toUpperCase()} API) - SD*`, m);
                        sent = true;
                        break;
                    }
                }

                if (sent) {
                    await m.reply('✅ Proses download selesai.');
                    return; // Exit after successful download from this endpoint
                }

                throw new Error(`Video tidak tersedia dalam kualitas SD maupun HD di ${endpoint}.`);
            } catch (error) {
                console.log(`Botcha ${endpoint} Error:`, error);
                console.log(`Gagal menggunakan Botcha ${endpoint} API, mencoba API berikutnya...`);
            }
        }

        throw '❌ Semua API gagal memproses video.';

    } catch (error) {
        console.log(error);
        throw '❌ Terjadi kesalahan saat memproses video. Pastikan link valid atau coba beberapa saat lagi.';
    }
}

handler.help = ['facebook'].map(v => v + ' <url>');
handler.command = /^(fb|facebook|facebookdl|fbdl|fbdown|dlfb)$/i;
handler.tags = ['downloader'];
handler.limit = true;
handler.group = false;
handler.premium = false;
handler.owner = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.private = false;

module.exports = handler;