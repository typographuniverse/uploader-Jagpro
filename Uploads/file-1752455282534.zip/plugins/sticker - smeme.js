const fetch = require('node-fetch');
const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs').promises;
const uploadImage = require('../function/uploadFile'); // Adjust path to match your setup

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `• *Example :* ${usedPrefix + command} *[Top Text|Bottom Text]* or *[Top Text]* or *|Bottom Text*`;

    // Parse text for top, bottom, or both
    let [atas, bawah] = text.split('|');
    atas = atas ? atas.trim() : '';
    bawah = bawah ? bawah.trim() : '';

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';
    if (!mime) throw `• *Example :* ${usedPrefix + command} *[reply/send media]*`;

    let fileSizeLimit = 5 * 1024 * 1024; // 5MB limit from tourl.js
    let media = await q.download();
    if (media.length > fileSizeLimit) {
        throw 'Ukuran media tidak boleh melebihi 5MB';
    }

    let isAnimated = /video\/mp4|image\/gif|image\/webp/.test(mime);
    let url;

    try {
        if (isAnimated) {
            // Animated media: MP4, WebP, GIF
            if (/video\/mp4|image\/webp/.test(mime)) {
                // Convert MP4 or WebP to GIF
                url = await toGif(media, mime);
            } else {
                // GIF: upload directly
                url = await uploadImage(media);
            }
            // Use custom template with GIF background
            meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas || '_')}/${encodeURIComponent(bawah || '_')}.gif?background=${encodeURIComponent(url)}`;
        } else if (/image\/png|image\/jpeg/.test(mime)) {
            // Static images: PNG, JPEG
            url = await uploadImage(media);
            // Use custom template with JPEG background
            meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas || '_')}/${encodeURIComponent(bawah || '_')}.jpg?background=${encodeURIComponent(url)}`;
        } else {
            throw `Unsupported media type. Please use PNG, JPEG, GIF, WebP, or MP4.`;
        }

        console.log(`Uploaded URL: ${url}`);
        console.log(`Meme URL: ${meme}`);

        // Handle sticker output
        if (isAnimated) {
            // Fetch GIF meme and convert to WebP for animated sticker
            const response = await fetch(meme);
            if (!response.ok) throw `Failed to fetch meme: ${response.statusText}`;
            const gifBuffer = Buffer.from(await response.arrayBuffer());
            const sticker = await createSticker(gifBuffer, false, global.packname || 'xAI', global.author || 'Grok');
            await conn.sendFile(m.chat, sticker, 'sticker.webp', '', m);
        } else {
            // Static JPEG sticker
            await conn.sendImageAsSticker(m.chat, meme, m, { 
                packname: global.packname , 
                author: global.author 
            });
        }

    } catch (e) {
        console.error(e);
        await m.reply(`Error: ${e.message || e}`);
    }
};

// Convert MP4 or WebP to GIF using ffmpeg (max 8 seconds)
async function toGif(media, mime) {
    const tempInput = `temp.${mime === 'video/mp4' ? 'mp4' : 'webp'}`;
    const tempOutput = 'temp.gif';
    await fs.writeFile(tempInput, media);
    return new Promise((resolve, reject) => {
        ffmpeg(tempInput)
            .outputOptions([
                '-vf', 'fps=30,scale=320:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse',
                '-t', '8', // Max 8 seconds
                '-loop', '0'
            ])
            .toFormat('gif')
            .on('end', async () => {
                const gifBuffer = await fs.readFile(tempOutput);
                const url = await uploadImage(gifBuffer);
                await fs.unlink(tempInput).catch(() => {});
                await fs.unlink(tempOutput).catch(() => {});
                resolve(url);
            })
            .on('error', reject)
            .save(tempOutput);
    });
}

// Reuse createSticker from sticker.js for GIF to WebP conversion
async function createSticker(img, url, packName, authorName, quality = 15) {
    const { Sticker } = require('wa-sticker-formatter');
    let stickerMetadata = {
        type: 'full',
        pack: packName,
        author: authorName,
        quality,
    };
    return new Sticker(img ? img : url, stickerMetadata).toBuffer();
}

handler.help = ['stickermeme'].map(a => a + ' *[Top|Bottom text]*');
handler.tags = ['tools'];
handler.command = /^(s(tic?ker)?me(me)?)$/i;
handler.limit = false;

module.exports = handler;