// ✨ Plugin group - linkgc ✨

let handler = async (m, { conn }) => {
  const isGroup = m.chat.endsWith('@g.us');
  const bot = await conn.groupMetadata(m.chat).then(res => res.participants.find(p => p.id === conn.user.jid));
  const isBotAdmin = bot?.admin === 'admin' || bot?.admin === 'superadmin';

  if (!isGroup) return m.reply('‼️ Fitur ini hanya bisa digunakan di dalam grup!');
  if (!isBotAdmin) return m.reply('‼️ Bot harus menjadi admin untuk mengambil link grup!');

  try {
    let link = await conn.groupInviteCode(m.chat);
    m.reply(`📝 Link group ini :\n\nhttps://chat.whatsapp.com/${link}`);
  } catch (e) {
    m.reply('❌ Gagal mengambil link grup, mungkin bot belum jadi admin atau ada kesalahan lain.');
    console.error(e);
  }
};

handler.help = ['linkgc'];
handler.tags = ['group'];
handler.command = /^linkgc$/i;

module.exports = handler;