const sharp = require('sharp');
const fetch = require('node-fetch');

let handler = async (m, { conn, args }) => {
  if (!args.length) return m.reply('⚠️ Masukkan teks untuk ditulis! Contoh: `.nulis Halo dunia` 😓');

  const teks = args.join(' ');
  await conn.sendMessage(m.chat, { react: { text: '⚙️', key: m.key } });

  try {
    // Fetch gambar dari API
    const response = await fetch(`https://abella.icu/nulis?text=${encodeURIComponent(teks)}`);
    const buffer = await response.buffer();

    // Potong bagian bawah gambar (ubah 0.1 ke nilai lain jika ingin potong lebih/banyak, misal 0.2 untuk 20%)
    const image = sharp(buffer);
    const metadata = await image.metadata();
    const cropHeight = Math.floor(metadata.height * 0.03); // Potong 10% dari bawah
    const trimmedImage = await image
      .extract({
        left: 0,
        top: 0,
        width: metadata.width,
        height: metadata.height - cropHeight
      })
      .toBuffer();

    // Kirim gambar yang sudah dipotong
    await conn.sendMessage(m.chat, {
      image: trimmedImage,
      caption: `Nih pemalas dah jadi, kagak usah sekolah deh lu... 😤`
    }, { quoted: m });
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  } catch (e) {
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply('😵 Oops, gagal menulis! Coba lagi nanti ya~ 🙏');
  }
};

handler.help = ['nulis <teks>'];
handler.tags = ['tools'];
handler.command = /^nulis$/i;

module.exports = handler;