const { toAudio, toPTT } = require('../scrape/converter')

let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (m.quoted ? m.quoted : m.msg).mimetype || ''
  
  if (!/video|audio/.test(mime)) {
    throw `Balas video/audio dengan perintah *${usedPrefix + command}*`
  }

  let media = await q.download()
  if (!media) throw 'Media tidak dapat diunduh'

  if (/^(tomp3|toaudio)$/i.test(command)) {
    let audio = await toAudio(media, 'mp4')
    if (!audio.data) throw 'Gagal mengonversi ke MP3.'
    await conn.sendMessage(m.chat, {
      audio: audio.data,
      mimetype: 'audio/mpeg'
    }, { quoted: m })

  } else if (/^tovn$/i.test(command)) {
    let ptt = await toPTT(media, 'mp4')
    if (!ptt.data) throw 'Gagal mengonversi ke voice note.'
    await conn.sendMessage(m.chat, {
      audio: ptt.data,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true
    }, { quoted: m })
  }
}

handler.help = ['tomp3 (reply)', 'toaudio (reply)', 'tovn (reply)']
handler.tags = ['tools']
handler.command = /^tomp3|toaudio|tovn$/i

module.exports = handler
