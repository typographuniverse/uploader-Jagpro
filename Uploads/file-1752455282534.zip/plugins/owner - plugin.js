// ✨ Plugin owner - plugin ✨

const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) {
    return m.reply(`📌 Contoh penggunaan :\n\n${usedPrefix + command} ai\n${usedPrefix + command} rpg\n${usedPrefix + command} tools`);
  }

  const prefix = args[0].toLowerCase();
  const pluginFolder = path.join(__dirname); // Folder plugin ini
  let files = fs.readdirSync(pluginFolder);

  let matched = files.filter(file => file.endsWith('.js') && file.toLowerCase().startsWith(prefix));

  if (matched.length === 0) {
    return m.reply(`❌ Plugin dengan tags *${prefix}* tidak ditemukan`);
  }

  let list = matched.map(file => `📁 ${file.replace(/\.js$/, '')}`).join('\n');

  m.reply(`📝 List plugin dengan tags *${prefix}*:\n\n${list}`);
};

handler.help = ['plugin'];
handler.tags = ['tools'];
handler.command = /^plugin$/i;
handler.owner = true;

module.exports = handler;