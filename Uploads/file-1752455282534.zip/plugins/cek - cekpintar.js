let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.pintar)}”`, m)
}
handler.help = ['cekpintar']
handler.tags = ['cek']
handler.command = /^(cekpintar)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.pintar = [
'Aowkaowk Lu Gak Pintar Cok\nSekolah dulu sana yang bener',
'Masih Lebih Pintar Adek Gw Ketimbang Elu',
'15% Lah Ya, Masih Pinteran Kucing Gw',
'69%, Lu Sebenarnya Pinter Cuma Sayang Nya Lu Pedo',
'10% Doang, Semut Juga Lebih Pinter Daripada Elu',
'20%, Bisa Tuh, Kembangin Aja Terus\nSiapa Tau Bisa Ngalahin Kepintaran Ayam',
'25%, Jangan Kebanyakan Jomok\nBtw Ada Doksli Kecap Buk Buk Gak Cik?',
'30% Lah Ya, Lu Pinter Kok, Kembangin Lagi',
'40%\nJangan Kebanyakan Nonton Bokep\nHehe',
'50%\nOtak Lu Setengah Setengah Cok\nkadang Pinter Kadang Enggak',
'60%\nIQ Lu Udah Boleh Lah Ya\nTinggal Kurangin Nonton Bokep Anak Kecil 🤨',
'Gile Cok Lu Terlalu Pinter\nSampe Sampe Cuma 1% Doang Gila 😎',
'100%\nWahh Salut Gwe, Lu Sering Juara Kelas Ya?\nJadiin Gwe Murid Mu Plis',
'Lu Setara Albert Einstein Njir\nJangan Jangan Teori Teori Fisika Lu Yang Nemuin?\n😨😨😨',
]