// ✨ Plugin tools - detect ✨

const axios = require("axios");
const { fromBuffer } = require("file-type");
const qs = require("qs");

const pxpic = {
  upload: async (buffer) => {
    const { ext, mime } = (await fromBuffer(buffer)) || {};
    const fileName = `${Date.now()}.${ext}`;
    const folder = "uploads";

    const response = await axios.post("https://pxpic.com/getSignedUrl", { folder, fileName }, {
      headers: { "Content-Type": "application/json" },
    });

    const { presignedUrl } = response.data;
    await axios.put(presignedUrl, buffer, { headers: { "Content-Type": mime } });

    return `https://files.fotoenhancer.com/uploads/${fileName}`;
  },

  enhance: async (buffer) => {
    const url = await pxpic.upload(buffer);
    const data = qs.stringify({
      imageUrl: url,
      targetFormat: "png",
      needCompress: "no",
      imageQuality: "100",
      compressLevel: "6",
      fileOriginalExtension: "png",
      aiFunction: "enhance",
      upscalingLevel: "",
    });

    const res = await axios.post("https://pxpic.com/callAiFunction", data, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        "Content-Type": "application/x-www-form-urlencoded",
      },
    });

    if (!res.data || !res.data.resultImageUrl) throw new Error("Gagal enhance gambar");
    return res.data.resultImageUrl;
  }
};

let handler = async (m, { conn }) => {
  try {
    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype || "";
    if (!/image/.test(mime)) return m.reply("❌ Kirim atau balas gambar untuk dideteksi.");

    const waitMsg = await conn.sendMessage(m.chat, { text: "🔍 Mendeteksi objek pada gambar..." }, { quoted: m });

    const media = await q.download();
    const blob = new Blob([media], { type: mime });

    const { Client } = await import("@gradio/client");
    const client = await Client.connect("iashin/YOLOv3");
    const result = await client.predict("/predict", { source_img: blob });

    const fileData = result.data?.[0];
    if (!fileData || !fileData.url) {
      await conn.sendMessage(m.chat, { edit: waitMsg.key, text: "❌ Gagal mendeteksi objek." });
      return;
    }

    const response = await axios.get(fileData.url, { responseType: "arraybuffer" });
    const detectedBuffer = Buffer.from(response.data);

    await conn.sendMessage(m.chat, { edit: waitMsg.key, text: "✨ Memperjelas hasil deteksi..." });
    const enhancedUrl = await pxpic.enhance(detectedBuffer);

    await conn.sendMessage(m.chat, { edit: waitMsg.key, text: "🖼 Mengirim gambar akhir..." });
    await conn.sendFile(m.chat, enhancedUrl, "detected-enhanced.png", "✅ Deteksi & Enhance selesai!", m);

  } catch (e) {
    console.error("Detect Error:", e);
    m.reply("❌ Terjadi kesalahan saat proses deteksi atau enhance.");
  }
};

handler.help = ["detect"];
handler.tags = ["ai"];
handler.command = /^detect$/i;

module.exports = handler;