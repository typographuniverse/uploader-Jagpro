/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

const axios = require('axios');
const cheerio = require('cheerio');

async function jadwal(tv) {
    try {
        let { data } = await axios.get(`https://www.jadwaltv.net/channel/${tv}`);
        let $ = cheerio.load(data);

        let hasil = [];

        $('table.table-bordered tbody tr').each((i, el) => {
            let jam = $(el).find('td').eq(0).text().trim();
            let acara = $(el).find('td').eq(1).text().trim();

            if (jam && acara) {
                hasil.push({ jam, acara });
            }
        });

        return hasil;
    } catch (error) {
        console.error('Error:', error.message);
        return null;
    }
}

async function handler(m, { args }) {
    if (!args[0]) return m.reply("❌ Masukkan nama channel TV! Contoh: .jadwaltv gtv");

    const tv = args[0].toLowerCase();
    const jadwalTv = await jadwal(tv);

    if (!jadwalTv || jadwalTv.length === 0) {
        return m.reply(`⚠️ Jadwal untuk channel *${tv.toUpperCase()}* tidak ditemukan atau sedang tidak tersedia.`);
    }

    const jadwalList = jadwalTv
        .map(item => `🕒 *${item.jam}*: ${item.acara}`)
        .join('\n');

    const response = `
📺 *Jadwal TV ${tv.toUpperCase()}*

${jadwalList}

🌐 Sumber: https://www.jadwaltv.net/channel/${tv}
    `.trim();

    m.reply(response);
}

handler.command = ['jadwaltv'];
handler.tags = ['internet'];
handler.help = ['jadwaltv <channel>'];
module.exports = handler;