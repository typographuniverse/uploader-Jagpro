const { GoogleGenerativeAI } = require("@google/generative-ai");
const fs = require("fs");
const path = require("path");

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";
    
    const defaultPrompt = "Ubahlah karakter dari gambar tersebut menjadi senyum lebar dengan kelihatan gigi hitam ompong";
    
    // Validasi input gambar
    if (!mime) {
        return m.reply(`Kirim/reply gambar dengan caption *${usedPrefix}${command}*`);
    }
    if (!/image\/(jpe?g|png)/.test(mime)) {
        return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`);
    }
    
    const promptText = text || defaultPrompt;
    
    try {
        m.reply("Sedang memproses...");
        
        // Download gambar
        const imgData = await q.download();
        if (!imgData) throw new Error("Gagal mendownload gambar");
        
        // Inisialisasi GoogleGenerativeAI
        const genAI = new GoogleGenerativeAI(geminiApi);
        const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash-exp-image-generation",
            generationConfig: {
                responseModalities: ["text", "image"]
            }
        });
        
        // Konversi ke base64
        const base64Image = imgData.toString("base64");
        
        const contents = [
            { text: promptText },
            {
                inlineData: {
                    mimeType: mime,
                    data: base64Image
                }
            }
        ];
        
        // Generate konten
        const response = await model.generateContent(contents);
        const candidate = response.response.candidates[0];
        
        if (!candidate || !candidate.content || !candidate.content.parts) {
            throw new Error("Response tidak valid dari API");
        }
        
        let resultImage;
        let resultText = "";
        
        // Proses response parts
        for (const part of candidate.content.parts) {
            if (part.text) {
                resultText += part.text;
            } else if (part.inlineData && part.inlineData.data) {
                resultImage = Buffer.from(part.inlineData.data, "base64");
            }
        }
        
        if (!resultImage) {
            throw new Error("Gambar hasil tidak ditemukan dalam response");
        }
        
        // Simpan dan kirim gambar
        const tempDir = path.join(process.cwd(), "tmp");
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir);
        }
        
        const tempPath = path.join(tempDir, `gemini_${Date.now()}.png`);
        fs.writeFileSync(tempPath, resultImage);
        
        await conn.sendMessage(m.chat, {
            image: { url: tempPath },
            caption: "*ANJAYY SENYUM AWKKW*"
        }, { quoted: m });
        
        // Cleanup dengan timeout
        setTimeout(() => {
            try {
                if (fs.existsSync(tempPath)) {
                    fs.unlinkSync(tempPath);
                }
            } catch (err) {
                console.error("Gagal menghapus file temporary:", err);
            }
        }, 30000);
        
    } catch (error) {
        console.error("Error dalam handler:", error);
        m.reply(`Terjadi kesalahan: ${error.message}`);
    }
};

handler.help = ["senyum"];
handler.tags = ["ai","maker"];
handler.command = /^(senyum|nyengir|ketawa|tawa)$/i

module.exports = handler;