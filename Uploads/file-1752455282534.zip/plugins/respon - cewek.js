let handler = async (m, { conn }) => {
	if (m.fromMe) return false
	conn.sendMessage(m.chat, {
		video: { url: "https://files.catbox.moe/alz8y4.mp4" },
		mimetype: 'video/mp4',
		ptv: true
	}, { quoted: m })
}
handler.customPrefix = /cewek/i
handler.command = new RegExp

module.exports = handler