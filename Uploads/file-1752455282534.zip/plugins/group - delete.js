const store = {}; // In-memory store untuk menyimpan metadata pesan

// Save message to store
async function saveMessageToStore(message) {
    const messageData = {
        id: message.key.id,
        chat: message.key.remoteJid,
        sender: message.key.participant || message.key.remoteJid,
        fromMe: message.key.fromMe,
        timestamp: message.messageTimestamp
    };
    store[message.key.id] = messageData; // Simpan ke store dengan ID pesan sebagai kunci
}

// Read message from store
async function readMessageFromStore(messageId) {
    return store[messageId] || null; // Ambil data dari store atau kembalikan null jika tidak ada
}

// Delete message from store after deletion
async function deleteMessageFromStore(messageId) {
    delete store[messageId]; // Hapus data dari store
}

let handler = async function (m, { conn, command, isReaction = false, reaction = null }) {
    // Save every incoming message to store (only for group chats)
    if (m.isGroup && !isReaction) {
        await saveMessageToStore(m);
    }

    let messageToDelete;

    // Handle reply-based deletion
    if (!isReaction) {
        if (!m.quoted) throw false;
        messageToDelete = m.quoted;
    } else {
        // Handle reaction-based deletion
        if (reaction?.emoji !== '❌') return; // Only proceed if reaction is ❌
        const storedMessage = await readMessageFromStore(m.id);
        if (!storedMessage) return conn.reply(m.chat, '🚩 Pesan tidak ditemukan di database!', m);
        messageToDelete = {
            chat: storedMessage.chat,
            id: storedMessage.id,
            sender: storedMessage.sender
        };
    }

    if (!m.isGroup) return conn.reply(m.chat, '🚩 Perintah ini hanya dapat digunakan di dalam grup!', m);

    // Get group metadata to check admin status
    let groupMetadata = await conn.groupMetadata(m.chat);
    let botNumber = conn.user.jid;
    let botParticipant = groupMetadata.participants.find(participant => participant.id === botNumber);
    let userParticipant = groupMetadata.participants.find(participant => participant.id === m.sender);

    let isAdmin = participant => participant?.admin === 'admin' || participant?.admin === 'superadmin';

    let isBotAdmin = isAdmin(botParticipant);
    let isUserAdmin = isAdmin(userParticipant);
    let isOwner = global.owner.some(([number]) => number === m.sender.split('@')[0]);

    // Check if bot is admin
    if (!isBotAdmin) return conn.reply(m.chat, '🚩 Bot bukan admin!', m);

    // Check if user is admin or owner
    if (!isUserAdmin && !isOwner) return conn.reply(m.chat, '🚩 Kamu bukan admin grup atau owner!', m);

    // Delete the message
    await conn.sendMessage(m.chat, {
        delete: {
            remoteJid: messageToDelete.chat,
            fromMe: false,
            id: messageToDelete.id,
            participant: messageToDelete.sender
        }
    });

    // Remove the message from store after deletion
    if (isReaction) {
        await deleteMessageFromStore(m.id);
    }
};

// Reaction handler
handler.onReaction = async (reaction, conn) => {
    if (!reaction.isGroup) return;
    await handler(reaction, { conn, isReaction: true, reaction });
};

handler.help = ['del *<reply>*', 'delete *<reply>*', 'React with 🗑️ to delete'];
handler.tags = ['tools'];
handler.command = /^del(ete)?$/i;
handler.limit = false;

module.exports = handler;