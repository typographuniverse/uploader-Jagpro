let { spawn } = require('child_process');

let handler = async (m, { conn }) => {
  if (!process.send) throw '❌ *Jangan gunakan:* node main.js\n✅ *Gunakan:* node index.js';

  if (global.conn.user.jid == conn.user.jid) {
    // Kirim React (Emoji) ke pesan pengguna
    await conn.sendMessage(m.chat, { react: { text: "🔄", key: m.key } });

    // Tunggu 1 detik sebelum mengirim pesan konfirmasi
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Kirim pesan konfirmasi ke pengguna
    await m.reply("♻️ *Sedang Mereset Bot...*\nMohon tunggu sekitar *1 menit* sebelum bot aktif kembali.");

    // Tunggu 3 detik sebelum memulai restart
    await new Promise(resolve => setTimeout(resolve, 3000));

    if (!global.db.data) await global.db.read();
    await global.db.write();

    setTimeout(() => {
      m.reply("✅ *Bot berhasil direstart!*\nBot sudah kembali online. 🚀");
    }, 60000); // Kirim pesan setelah 1 menit

    process.send("reset");
  } else throw "⚠️ _Akses Ditolak!_";
};

handler.help = ["restart"];
handler.tags = ["owner"];
handler.command = /^restart$/i;
handler.rowner = true;
handler.mods = true;
handler.premium = false;
handler.group = false;
handler.private = false;

handler.admin = false;
handler.botAdmin = false;

handler.fail = null;

module.exports = handler;
