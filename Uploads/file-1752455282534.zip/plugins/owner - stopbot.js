let { spawn } = require('child_process');

let handler = async (m, { conn }) => {
  if (!process.send) throw '❌ *Jangan gunakan:* node main.js\n✅ *Gunakan:* node index.js';

  if (global.conn.user.jid == conn.user.jid) {
    // Kirim React (Emoji) ke pesan pengguna
    await conn.sendMessage(m.chat, { react: { text: "⏹️", key: m.key } });

    // Tunggu 1 detik sebelum mengirim pesan konfirmasi
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Kirim pesan konfirmasi ke pengguna
    await m.reply("🛑 *Sedang Menghentikan Bot...*\nBot akan segera dimatikan. Jika ingin mengaktifkan, maka Aktifkan manual di console/panel tempat bot di jalankan.");

    // Tunggu 2 detik sebelum memulai proses stop
    await new Promise(resolve => setTimeout(resolve, 2000));

    if (!global.db.data) await global.db.read();
    await global.db.write();

    // Kirim pesan terakhir sebelum bot dimatikan
    await m.reply("✅ *Bot berhasil dihentikan!*\nTerima kasih telah menggunakan bot ini. Sampai jumpa! 👋");

    // Tunggu 1 detik sebelum mengakhiri proses
    await new Promise(resolve => setTimeout(resolve, 1000));

    process.exit(0); // Mengakhiri proses Node.js
  } else throw "⚠️ _Akses Ditolak!_";
};

handler.help = ["stopbot"];
handler.tags = ["owner"];
handler.command = /^stopbot$/i;
handler.rowner = true;
handler.mods = true;
handler.premium = false;
handler.group = false;
handler.private = false;

handler.admin = false;
handler.botAdmin = false;

handler.fail = null;

module.exports = handler;