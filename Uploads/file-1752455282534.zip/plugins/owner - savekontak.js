const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, usedPrefix, command, isOwner, groupMetadata }) => {
    // Debug log
    console.log('Chat ID:', m.chat, 'isGroup:', m.chat.endsWith('@g.us'));

    // Evaluasi isGroup langsung dari m.chat
    const isGroup = m.chat.endsWith('@g.us');

    if (!isOwner) return m.reply('🚫 *Perintah ini hanya untuk owner bot!*');
    if (!isGroup) return m.reply('🚫 *Perintah ini hanya bisa digunakan di grup! ID Chat: ' + m.chat);
    if (!groupMetadata) return m.reply('❌ *Gagal mendapatkan metadata grup. Pastikan bot memiliki akses ke grup!*');

    // Cek dan buat folder ../database jika belum ada
    const databaseDir = path.join(__dirname, '../database');
    if (!fs.existsSync(databaseDir)) {
        fs.mkdirSync(databaseDir, { recursive: true });
    }

    // Cek dan buat file contacts.json jika belum ada
    const contactsFile = path.join(databaseDir, 'contacts.json');
    if (!fs.existsSync(contactsFile)) {
        fs.writeFileSync(contactsFile, JSON.stringify([]));
    }

    try {
        // Ambil daftar peserta grup
        const participants = groupMetadata.participants.map(v => v.id);
        console.log('Total participants:', participants.length, 'Participants:', participants);

        if (participants.length === 0) return m.reply('❌ *Tidak ada peserta di grup ini!*');

        // Ambil nama grup asli dan bersihkan hanya karakter yang bermasalah untuk vCard
        let groupName = groupMetadata.subject || 'Group';
        groupName = groupName.replace(/[\n;]/g, ' ').trim(); // Ganti newline dan semicolon dengan spasi
        console.log('Group Name:', groupName);

        // Buat daftar kontak dengan nama berdasarkan pushname atau groupName
        const contacts = participants.map((id, index) => {
            const pushName = conn.getName(id); // Ambil pushname dari conn.getName
            const contactName = (pushName && pushName !== 'Unknown') 
                ? pushName.replace(/[\n;]/g, ' ').trim() // Gunakan pushname jika ada
                : `${groupName}_${String(index + 1).padStart(2, '0')}`; // Fallback ke groupName_XX
            return {
                id,
                name: contactName
            };
        });

        // Simpan daftar kontak ke contacts.json
        fs.writeFileSync(contactsFile, JSON.stringify(contacts));

        // Buat file vCard dari kontak
        const vcardContent = contacts.map(({ id, name }) => {
            const vcard = [
                "BEGIN:VCARD",
                "VERSION:3.0",
                `FN:${name}`,
                `TEL;type=CELL;type=VOICE;waid=${id.split("@")[0]}:+${id.split("@")[0]}`,
                "END:VCARD",
                ""
            ].join("\n");
            return vcard;
        }).join("");

        // Cek apakah ada kontak untuk disimpan
        if (contacts.length === 0) return m.reply('❌ *Tidak ada kontak untuk disimpan!*');

        // Bersihkan nama grup untuk nama file (ganti spasi dan karakter khusus dengan underscore)
        const safeFileName = groupName.replace(/[^a-zA-Z0-9]/g, '_');
        const vcardFile = path.join(databaseDir, 'contacts.vcf');
        fs.writeFileSync(vcardFile, vcardContent, "utf8");

        // Kirim file vCard langsung ke grup
        await conn.sendMessage(m.chat, {
            document: fs.readFileSync(vcardFile),
            fileName: `${safeFileName}_contacts.vcf`,
            caption: `✅ *File kontak berhasil dibuat! Total: ${contacts.length} kontak*`,
            mimetype: "text/vcard"
        }, { quoted: m });

        // Bersihkan data
        fs.writeFileSync(contactsFile, JSON.stringify([]));
        fs.writeFileSync(vcardFile, "");

    } catch (err) {
        console.error('Error in savekontak:', err);
        m.reply(`❌ *Error:* ${err.toString()}`);
    }
};

handler.command = ['savekontak'];
handler.tags = ['owner', 'group'];
handler.help = ['savekontak'];
handler.group = true;
handler.owner = true;

module.exports = handler;