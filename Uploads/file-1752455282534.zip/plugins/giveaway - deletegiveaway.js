const fs = require('fs');
const path = require('path');

// Helper function to ensure database directory exists
const ensureDatabaseDir = () => {
    const dir = path.join(__dirname, '../database');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
};

// Helper function to load giveaways from JSON file
const loadGiveaways = () => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return {};
    } catch (err) {
        console.error('Error loading giveaways:', err);
        return {};
    }
};

// Helper function to save giveaways to JSON file
const saveGiveaways = (giveaways) => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        ensureDatabaseDir();
        fs.writeFileSync(filePath, JSON.stringify(giveaways, null, 2), 'utf8');
    } catch (err) {
        console.error('Error saving giveaways:', err);
    }
};

let handler = async (m, { conn, participants, usedPrefix }) => {
    // Initialize conn.giveway from JSON file
    conn.giveway = loadGiveaways();

    let id = m.chat;
    if (!(id in conn.giveway)) throw `‼️ *UPSS!! TIDAK BISA*\n\n– tidak ada giveaway yang sedang berlangsung di group ini, untuk memulai giveaway ikuti contoh dibawah ini.\n📝 Contoh penggunaan :\n\n– ${usedPrefix}mulaigiveaway akun epep`;

    delete conn.giveway[id];
    saveGiveaways(conn.giveway); // Save updated data to JSON file

    conn.sendMessage(m.chat, { text: '*✅ GIVEAWAY TELAH SELESAI*', mentions: participants.map(a => a.id) });
};

handler.help = ['hapusgiveaway'];
handler.tags = ['giveaway'];
handler.command = /^(delete|hapus)giveaway$/i;
handler.group = true;
handler.admin = true;
module.exports = handler;