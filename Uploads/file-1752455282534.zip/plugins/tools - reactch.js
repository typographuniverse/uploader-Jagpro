// 📝 plugin tools - reactch

const font2 = {
  a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
  h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
  o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
  v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩'
}

const handler = async (m, { conn, text }) => {
  if (!text.includes('|')) {
    return m.reply(`‼️ *Format tidak valid*\n\n📝 Contoh penggunaan :\n\n– .reactch https://whatsapp.com/channel/abc/123|jawa diem aja`)
  }

  let [link, ...messageParts] = text.split('|')
  link = link.trim()
  const msg = messageParts.join('|').trim().toLowerCase()

  if (!link.startsWith("https://whatsapp.com/channel/")) {
    return m.reply("‼️ *Link tidak valid.*\n\n> harus diawali dengan https://whatsapp.com/channel/")
  }

  const emoji = msg.split('').map(c => c === ' ' ? '―' : (font2[c] || c)).join('')

  try {
    const [, , , , channelId, messageId] = link.split('/')
    const res = await conn.newsletterMetadata("invite", channelId)
    await conn.newsletterReactMessage(res.id, messageId, emoji)
    m.reply(`✅ *Berhasil mengirim reaksi*\n\n– channel : ${res.name}\n– reaksi : ${emoji}\n\nYoriichi-MD || BenZz`)
  } catch (e) {
    console.error(e)
    m.reply("❌ *Gagal memberi reaksi*\n\n> gagal mengirimkan reaksi ke channel, silahkan cek link atau koneksi!")
  }
}

handler.command = ['reactch', 'rch']
handler.tags = ['tools']
handler.help = ['reactch <link>|<teks>']
handler.owner = true

module.exports = handler;