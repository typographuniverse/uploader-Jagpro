const roles = {
    'Rookie': 0,
    'Beginner': 10,
    'Kyuu II': 15,
    'Kyuu I': 20,
    'Dan II': 25,
    'Dan I': 30,
    'Mentor II': 35,
    'Mentor I': 40,
    'Master': 45,
    'Rogue': 50,
    'Brawler': 55,
    'Marauder': 60,
    'Berzerker': 65,
    'Warrior': 70,
    'Avengers': 75,
    'Vindicator': 80,
    'Juggernaut': 85,
    'Vanquisher': 90,
    'Destroyer': 95,
    'Conqueror': 100,
    'Saviour': 105,
    'Champion': 110,
    'Overlord': 115,
    'Sage': 120,
    'Legends': 125,
    'Fujin': 130,
    'Raijin': 135,
    'Yaksa': 140,
    'Raksasa': 145,
    'Asura': 150,
    'Dragon Lord': 155,
    'Ruby Lord': 160,
    'Ruby Emperor': 165,
    'Ruby Owner': 9999,
}

module.exports = {
    before(m) {
        let user = global.db.data.users[m.sender]
        let level = user.level
        let role = (Object.entries(roles).sort((a, b) => b[1] - a[1]).find(([, minLevel]) => level >= minLevel) || Object.entries(roles)[0])[0]
        user.role = role
        return true
    }
}