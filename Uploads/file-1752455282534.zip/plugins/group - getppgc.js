// 📝 plugin group - getppgc

// ✨ Plugin group - getppgc ✨

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

let handler = async (m, { conn }) => {
   try {
      const group = m.chat;
      const profilePicUrl = await conn.profilePictureUrl(group, 'image');

      if (!profilePicUrl) throw '*[ERROR]* Tidak dapat menemukan foto profil grup. Mungkin belum disetel.';

      await conn.sendFile(m.chat, profilePicUrl, 'group-profile.jpg', 'Ini dia foto profil grup-nya~', m);
   } catch (e) {
      console.error(e);
      await m.reply('*[ERROR]* Gagal mengambil foto profil grup. Pastikan bot memiliki izin yang cukup.');
   }
};

handler.help = ['getppgc']
handler.tags = ['group']
handler.command = /^(getppgc|getppgrup|getppgroup)$/i

handler.group = true
module.exports = handler