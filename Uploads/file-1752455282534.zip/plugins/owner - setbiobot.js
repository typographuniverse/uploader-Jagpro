let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        return conn.reply(m.chat, `*📌 Cara penggunaan:*\n\n• ${usedPrefix + command} teksbio`, m);
    }

    const caption = text.trim();

    if (!caption) return conn.reply(m.chat, `⚠️ Caption tidak boleh kosong.`, m);

    try {
        await conn.updateProfileStatus(caption);
        conn.reply(m.chat, `✅ Bio bot berhasil diubah menjadi:\n\n"${caption}"`, m);
    } catch (e) {
        console.error('❌ Gagal update bio:', e);
        conn.reply(m.chat, `❌ Gagal mengganti bio bot.`, m);
    }
};

handler.help = ['setbio'].map(c => c + ' *[teks]*')
handler.tags = ['owner']
handler.command = /^setbio$/i
handler.owner = true

module.exports = handler;