const { createCanvas, loadImage } = require('canvas');
const moment = require('moment-timezone');
const fetch = require('node-fetch');
const { Buffer } = require('buffer');

let handler = async (m, { args, usedPrefix, command }) => {
  let text = args.join(' ');
  if (!text) {
    return m.reply(`❌ Format salah!\nGunakan: ${usedPrefix}${command} timezone|nama|norek|jenis|bank|norekTujuan|namaTujuan|nominal\n\nContoh: ${usedPrefix}${command} WITA|MOH SLAMET|12345678|Transfer Bank Lain|BCA|87654321|PT ABC|50000`);
  }

  let [timezone, namaPengirim, noRekPengirim, jenisTransaksi, bankTujuan, noRekTujuan, namaTujuan, nominalStr] = text.split('|');
  
  // Input Validation
  if (!timezone || !namaPengirim || !noRekPengirim || !jenisTransaksi || !bankTujuan || !noRekTujuan || !namaTujuan || !nominalStr) {
    return m.reply(`❌ Format tidak lengkap! Semua field harus diisi.`);
  }

  // Timezone Validation
  const validTimezones = {
    'WIB': 'Asia/Jakarta',
    'WITA': 'Asia/Makassar',
    'WIT': 'Asia/Jayapura'
  };
  
  if (!validTimezones[timezone.toUpperCase()]) {
    return m.reply(`❌ Timezone tidak valid! Gunakan WIB, WITA, atau WIT.`);
  }

  // Name Validation (only letters, spaces, and basic punctuation)
  const nameRegex = /^[a-zA-Z\s\.\,]+$/;
  if (!nameRegex.test(namaPengirim) || !nameRegex.test(namaTujuan)) {
    return m.reply(`❌ Nama pengirim atau tujuan tidak valid! Gunakan huruf, spasi, titik, atau koma saja.`);
  }

  // Account Number Validation (numbers only, 8-16 digits)
  const accountRegex = /^\d{8,16}$/;
  if (!accountRegex.test(noRekPengirim) || !accountRegex.test(noRekTujuan)) {
    return m.reply(`❌ Nomor rekening tidak valid! Harus berupa angka 8-16 digit.`);
  }

  // Transaction Type Validation
  const validJenis = ['Transfer Bank Lain', 'Transfer Antar Bank', 'Transfer Sesama Bank'];
  if (!validJenis.includes(jenisTransaksi)) {
    return m.reply(`❌ Jenis transaksi tidak valid! Pilih: ${validJenis.join(', ')}`);
  }

  // Bank Name Validation (letters, spaces, and basic punctuation)
  if (!nameRegex.test(bankTujuan)) {
    return m.reply(`❌ Nama bank tidak valid! Gunakan huruf, spasi, titik, atau koma saja.`);
  }

  // Nominal Validation
  const nominal = parseInt(nominalStr);
  if (isNaN(nominal) || nominal < 10000 || nominal > 1000000000) {
    return m.reply(`❌ Nominal tidak valid! Harus antara Rp10,000 dan Rp1,000,000,000.`);
  }

  try {
    const biayaAdmin = 6500;
    const total = nominal + biayaAdmin;
    const tanggal = moment().tz(validTimezones[timezone.toUpperCase()]).format('D MMM YYYY | HH:mm:ss') + ` ${timezone.toUpperCase()}`;
    const noRef = Math.floor(1000000000000 + Math.random() * 9000000000000).toString();

    const imageUrl = 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/src/mentahan.png';
    const response = await fetch(imageUrl);
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const bgImage = await loadImage(buffer);

    const canvas = createCanvas(bgImage.width, bgImage.height);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(bgImage, 0, 0, canvas.width, canvas.height);

    // === Setting font dan posisi ===
    const xValue = 900;
    const yBase = 652;
    const lineSpacing = 50;

    const fontNormal = '25px sans-serif';
    const fontBold = 'bold 25px sans-serif';
    const fontTotal = 'bold 40px sans-serif';
    const colorNormal = '#000';
    const colorBiru = '#007BCE';

    const draw = (text, x, y, font = fontNormal, color = colorNormal) => {
      ctx.font = font;
      ctx.fillStyle = color;
      ctx.textAlign = 'right';
      ctx.fillText(text, x, y);
    };

    // === Render semua elemen ===
    let currentY = yBase;
    draw(tanggal, xValue, currentY);
    currentY += lineSpacing;
    draw(noRef, xValue, currentY);

    currentY += lineSpacing * 3.3;
    draw(namaPengirim, xValue, currentY, fontBold);
    currentY += lineSpacing;
    draw(noRekPengirim, xValue, currentY);

    currentY += lineSpacing * 1;
    draw(jenisTransaksi, xValue, currentY);
    currentY += lineSpacing * 1.3;
    draw(bankTujuan, xValue, currentY, fontBold);
    currentY += lineSpacing * 1.4;
    draw(noRekTujuan, xValue, currentY, fontBold);
    currentY += lineSpacing * 1.5;
    draw(namaTujuan, xValue, currentY, fontBold);

    currentY += lineSpacing * 5;
    draw(`Rp${nominal.toLocaleString()}`, xValue, currentY, fontBold);
    currentY += lineSpacing * 1.4;
    draw(`Rp${biayaAdmin.toLocaleString()}`, xValue, currentY, fontBold);
    currentY += lineSpacing * 4;
    draw(`Rp${total.toLocaleString()}`, xValue, currentY, fontTotal, colorBiru);

    const resultBuffer = canvas.toBuffer('image/png');
    await conn.sendFile(m.chat, resultBuffer, 'faketf.png', '✅ Bukti transfer berhasil dibuat', m);

  } catch (e) {
    console.error(e);
    m.reply(`❌ Terjadi kesalahan:\n${e.message}`);
  }
};

handler.command = ['tfbank'];
handler.help = ['tfbank'];
handler.tags = ['maker'];
handler.limit = true

module.exports = handler;