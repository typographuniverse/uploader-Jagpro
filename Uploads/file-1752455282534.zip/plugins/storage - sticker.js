/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

const path = require('path');
const fs = require('fs');
const axios = require('axios');
const { fromBuffer } = require('file-type');
const uploadImage = require('../scrape/uploadImage');

const stickerDbPath = path.join(__dirname, '../media/stickerDB.json');
const mediaDir = path.join(__dirname, '../media');
if (!fs.existsSync(mediaDir)) fs.mkdirSync(mediaDir, { recursive: true });

// Inisialisasi database sticker
let stickerDatabase = {};
if (fs.existsSync(stickerDbPath)) {
    try {
        stickerDatabase = JSON.parse(fs.readFileSync(stickerDbPath, 'utf-8'));
    } catch (err) {
        console.error('Gagal membaca database sticker:', err);
        stickerDatabase = {};
    }
}

// Fungsi untuk menyimpan database sticker
const saveStickerDatabase = () => {
    try {
        fs.writeFileSync(stickerDbPath, JSON.stringify(stickerDatabase, null, 2));
        console.log('Database sticker disimpan:', stickerDbPath);
    } catch (err) {
        console.error('Gagal menyimpan database sticker:', err);
    }
};

// Fungsi untuk mengonversi Uint8Array ke Base64
const uint8ArrayToBase64 = (uint8Array) => {
    return Buffer.from(uint8Array).toString('base64');
};

// Fungsi untuk mengunduh sticker dari URL
const fetchSticker = async (url) => {
    try {
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data);
        const fileType = await fromBuffer(buffer);
        console.log('Fetched sticker:', { url, mime: fileType?.mime, size: buffer.length });

        if (!fileType || fileType.mime !== 'image/webp') {
            throw new Error('File bukan sticker WebP yang valid');
        }

        return buffer;
    } catch (err) {
        console.error('Gagal mengunduh sticker:', err.message);
        throw new Error(`Gagal mengunduh sticker dari ${url}: ${err.message}`);
    }
};

const handler = async (message, { usedPrefix, text, command, conn, isOwner }) => {
    try {
        console.log('Handler dipanggil:', { command, text, sender: message.sender });

        const computedIsOwner = isOwner || (global.rowner
            ? Array.isArray(global.rowner)
                ? global.rowner.includes(message.sender)
                : global.rowner === message.sender
            : false);

        // Perintah: addsticker (khusus owner)
        if (command === 'addsticker') {
            console.log('Perintah addsticker diterima:', { text, sender: message.sender });
            console.log('isOwner:', computedIsOwner);
            if (!computedIsOwner) {
                return message.reply(`Respon: 🚫 Maaf, hanya *owner* yang bisa menggunakan perintah *${command}*!`);
            }
            console.log('Memeriksa input text:', text);
            if (!text) {
                return message.reply(`Respon: ❌ Format tidak valid!\n\nGunakan: *${usedPrefix}${command} <nama>*\nContoh: *${usedPrefix}${command} pantek*`);
            }

            console.log('Memeriksa pesan yang direply...');
            if (!message.quoted) {
                return message.reply(`Respon: ‼️ Reply pesan sticker dengan caption *${usedPrefix}${command} <nama>*`);
            }
            const quoted = message.quoted;
            const mtype = quoted.mtype;
            const mime = (quoted.msg || quoted).mimetype || '';
            console.log('Message type:', mtype, 'Mime type:', mime);
            if (mtype !== 'stickerMessage' || mime !== 'image/webp') {
                return message.reply(`Respon: ‼️ Reply pesan sticker dengan caption *${usedPrefix}${command} <nama>*`);
            }
            if (!quoted.fileSha256) {
                return message.reply(`Respon: ❌ SHA256 Hash tidak tersedia! Pastikan Anda mereply sticker yang valid.`);
            }

            // Log metadata sticker
            console.log('Metadata sticker:', {
                fileSha256: quoted.fileSha256 ? uint8ArrayToBase64(quoted.fileSha256) : null,
                url: quoted.msg?.url || 'Tidak tersedia',
                fbid: quoted.msg?.fileId || 'Tidak tersedia',
                hasStickerBuffer: !!quoted.msg?.sticker
            });

            // Dapatkan fileSha256
            const hash = uint8ArrayToBase64(quoted.fileSha256);
            console.log('Hash sticker:', hash);

            // Cek apakah nama sticker sudah digunakan
            const existingKey = Object.values(stickerDatabase).find(item => item.key.toLowerCase() === text.toLowerCase());
            if (existingKey) {
                return message.reply(`Respon: ❌ Nama sticker *${text}* sudah digunakan! Gunakan nama lain.`);
            }

            // Cek apakah hash sudah ada
            if (stickerDatabase[hash]) {
                return message.reply(`Respon: ❌ Sticker ini sudah ada di database dengan nama *${stickerDatabase[hash].key}*! Gunakan nama lain atau sticker berbeda.`);
            }

            // Unduh sticker
            let stickerBuffer;
            try {
                stickerBuffer = await quoted.download();
            } catch (err) {
                console.error('Gagal mengunduh sticker:', err);
                return message.reply(`Respon: ❌ Gagal mengunduh sticker: ${err.message}`);
            }
            if (!stickerBuffer) {
                return message.reply(`Respon: ❌ Gagal mendapatkan data sticker! Pastikan Anda mereply pesan sticker.`);
            }

            // Validasi ukuran file (maksimal 5MB, seperti tourl.js)
            const fileSizeLimit = 5 * 1024 * 1024;
            if (stickerBuffer.length > fileSizeLimit) {
                return message.reply(`Respon: ❌ Ukuran sticker tidak boleh melebihi 5MB!`);
            }

            // Validasi tipe file
            const fileType = await fromBuffer(stickerBuffer);
            console.log('File type:', fileType);
            if (!fileType || fileType.mime !== 'image/webp') {
                return message.reply(`Respon: ❌ File bukan sticker WebP yang valid!`);
            }

            // Unggah sticker ke server eksternal
            let url;
            try {
                if (typeof uploadImage !== 'function') {
                    console.error('uploadImage bukan fungsi, nilai:', uploadImage);
                    throw new Error('Modul uploadImage tidak valid. Pastikan /scrape/uploadImage.js mengekspor fungsi yang benar.');
                }
                url = await uploadImage(stickerBuffer);
                console.log('Sticker diunggah:', url);
            } catch (err) {
                console.error('Gagal mengunggah sticker:', err);
                return message.reply(`Respon: ❌ Gagal mengunggah sticker: ${err.message}`);
            }

            // Simpan ke database
            stickerDatabase[hash] = {
                key: text,
                url,
                creator: message.sender,
                at: +new Date,
            };
            saveStickerDatabase();
            return message.reply(`Respon: ✅ Berhasil menambahkan sticker *${text}* ke daftar global!\n\n> Ketik *${usedPrefix}getsticker <nama|nomor>* untuk mengambil sticker.`);
        }

        // Perintah: liststicker (bisa diakses semua orang)
        if (command === 'liststicker') {
            console.log('Perintah liststicker diterima');
            const stickerList = Object.values(stickerDatabase);
            if (!stickerList.length) {
                return message.reply(`Respon: 😔 Belum ada sticker tersimpan. Owner bisa tambahkan dengan *${usedPrefix}addsticker*!`);
            }

            const userName = message.pushName || message.name || 'Teman';
            // Urutkan berdasarkan abjad (case-insensitive)
            const sortedList = stickerList
                .slice()
                .sort((a, b) => a.key.toLowerCase().localeCompare(b.key.toLowerCase()));
            const stickerListText = sortedList
                .map((item, index) => `${index + 1}. ${item.key}`)
                .join('\n');

            const replyMessage = `Respon: 👋 Halo, ${userName}!\n\n📋 *Daftar Sticker:*\n${stickerListText}\n\n✨ Ketik *${usedPrefix}getsticker <nama|nomor>* untuk mengambil sticker.\n✨ Owner bisa hapus dengan *${usedPrefix}delsticker <nomor>*`;
            return message.reply(replyMessage);
        }

        // Perintah: getsticker (bisa diakses semua orang)
        if (command === 'getsticker') {
            console.log('Perintah getsticker diterima:', { text });
            const stickerList = Object.values(stickerDatabase);
            if (!stickerList.length) {
                return message.reply(`Respon: 😔 Belum ada sticker tersimpan. Owner bisa tambahkan dengan *${usedPrefix}addsticker*!`);
            }

            if (!text) {
                const sortedList = stickerList
                    .slice()
                    .sort((a, b) => a.key.toLowerCase().localeCompare(b.key.toLowerCase()));
                const stickerListText = sortedList
                    .map((item, index) => `${index + 1}. ${item.key}`)
                    .join('\n');
                const instruction = `Respon: 📋 *Daftar Sticker:*\n${stickerListText}\n\n🎨 Ketik *${usedPrefix}getsticker <nama|nomor>* untuk mengambil sticker.\nContoh:\n- *${usedPrefix}getsticker pantek*\n- *${usedPrefix}getsticker 1*`;
                return message.reply(instruction);
            }

            let stickerItem;
            const index = parseInt(text) - 1;
            if (!isNaN(index)) {
                const sortedList = stickerList
                    .slice()
                    .sort((a, b) => a.key.toLowerCase().localeCompare(b.key.toLowerCase()));
                if (index < 0 || index >= sortedList.length) {
                    return message.reply(`Respon: 🔍 Nomor *${text}* tidak valid! Gunakan *${usedPrefix}liststicker* untuk melihat daftar.`);
                }
                stickerItem = sortedList[index];
            } else {
                stickerItem = stickerList.find(item => item.key.toLowerCase() === text.toLowerCase());
                if (!stickerItem) {
                    return message.reply(`Respon: 🔍 Sticker *${text}* tidak ditemukan! Gunakan *${usedPrefix}liststicker* untuk melihat daftar.`);
                }
            }

            try {
                const stickerBuffer = await fetchSticker(stickerItem.url);
                return await conn.sendMessage(message.chat, {
                    sticker: stickerBuffer
                }, { quoted: message }).then(() => {
                    return message.reply(`Respon: 🎨 Sticker *${stickerItem.key}* berhasil dikirim! \nType: sticker`);
                });
            } catch (err) {
                console.error('Gagal mengirim sticker:', err);
                return message.reply(`Respon: ❌ Gagal mengirim sticker: ${err.message}`);
            }
        }

        // Perintah: delsticker (khusus owner)
        if (command === 'delsticker') {
            console.log('Perintah delsticker diterima:', { text });
            if (!computedIsOwner) {
                return message.reply(`Respon: 🚫 Maaf, hanya *owner* yang bisa menggunakan perintah *${command}*`);
            }
            const stickerList = Object.values(stickerDatabase);
            if (!stickerList.length) {
                return message.reply(`Respon: 😔 Belum ada sticker tersimpan. Owner bisa tambahkan dengan *${usedPrefix}addsticker*!`);
            }

            if (!text) {
                const sortedList = stickerList
                    .slice()
                    .sort((a, b) => a.key.toLowerCase().localeCompare(b.key.toLowerCase()));
                const stickerListText = sortedList
                    .map((item, index) => `${index + 1}. ${item.key}`)
                    .join('\n');
                const instruction = `Respon: 📋 *Daftar Sticker:*\n${stickerListText}\n\n🗑️ Ketik *${usedPrefix}delsticker <nomor>* untuk menghapus sticker.\nContoh: *${usedPrefix}delsticker 1*`;
                return message.reply(instruction);
            }

            const index = parseInt(text) - 1;
            if (isNaN(index)) {
                return message.reply(`Respon: ❌ Format tidak valid! Gunakan nomor urut, misalnya *${usedPrefix}delsticker 1*`);
            }

            const sortedList = stickerList
                .slice()
                .sort((a, b) => a.key.toLowerCase().localeCompare(b.key.toLowerCase()));
            if (index < 0 || index >= sortedList.length) {
                return message.reply(`Respon: 🔍 Nomor *${text}* tidak valid! Gunakan *${usedPrefix}liststicker* untuk melihat daftar.`);
            }

            const stickerToDelete = sortedList[index];
            const hash = Object.keys(stickerDatabase).find(key => stickerDatabase[key].key === stickerToDelete.key);
            if (hash) {
                delete stickerDatabase[hash];
                saveStickerDatabase();
                return message.reply(`Respon: 🗑️ Berhasil menghapus sticker *${stickerToDelete.key}* (nomor ${text}) dari daftar global!`);
            } else {
                return message.reply(`Respon: ❌ Gagal menghapus sticker *${stickerToDelete.key}*! Data tidak ditemukan.`);
            }
        }

        // Pencarian sticker berdasarkan sticker yang dikirim
        if (message.mtype === 'stickerMessage' && message.fileSha256) {
            console.log('Sticker dikirim, memeriksa database...');
            const hash = uint8ArrayToBase64(message.fileSha256);
            const stickerItem = stickerDatabase[hash];
            if (stickerItem) {
                try {
                    const stickerBuffer = await fetchSticker(stickerItem.url);
                    return await conn.sendMessage(message.chat, {
                        sticker: stickerBuffer
                    
                    });
                } catch (err) {
                    console.error('Gagal mengirim sticker:', err);
                    return message.reply(`Respon: ❌ Gagal mengirim sticker: ${err.message} `);
                }
            }
        }
    } catch (err) {
        console.error('Error di handler:', err);
        return message.reply(`Respon: ❌ Terjadi kesalahan: ${err.message}`);
    }
};

// Handler untuk pencarian sticker secara langsung (berdasarkan nama)
handler.all = async (message) => {
    try {
        const stickerList = Object.values(stickerDatabase);
        const text = message.text?.toLowerCase();
        if (!text) return;

        const matchedItem = stickerList.find(item => item.key.toLowerCase() === text);
        if (matchedItem) {
            console.log('Sticker ditemukan:', matchedItem);
            try {
                const stickerBuffer = await fetchSticker(matchedItem.url);
                return await global.conn.sendMessage(message.chat, {
                    sticker: stickerBuffer
                }, {
                    quoted: message // ✅ balas pesan user yang ketik nama sticker
                });
            } catch (err) {
                console.error('Gagal mengirim sticker:', err);
                return message.reply(`Respon: ❌ Gagal mengirim sticker: ${err.message}`);
            }
        }
    } catch (err) {
        console.error('Error di handler.all:', err);
        return message.reply(`Respon: ❌ Gagal memeriksa sticker: ${err.message}`);
    }
};

// Konfigurasi handler
handler.help = [
    'addsticker <nama> (reply sticker baru)',
    'liststicker',
    'getsticker <nama|nomor>',
    'delsticker <nomor>'
];
handler.tags = ['storage'];
handler.command = /^addsticker|liststicker|getsticker|delsticker$/i;
handler.group = false;
handler.limit = false;

module.exports = handler;