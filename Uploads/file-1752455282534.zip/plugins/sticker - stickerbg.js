

const fs = require('fs');
const axios = require('axios');
const { sticker5 } = require('../lib/sticker'); // atau ganti sesuai lib stiker kamu
const uploadImage = require('../scrape/uploadImage'); // pastikan ini ada dan berfungsi

let handler = async (m, { conn, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || '';
  
  if (!mime.startsWith('image/')) return m.reply(`🖼️ Balas gambar dengan perintah:\n${usedPrefix + command}`);
  
  try {
    m.reply('♻️ Menghapus latar belakang, harap tunggu...');

    // Unduh media
    const media = await q.download();
    const url = await uploadImage(media);

    // API RemoveBG
    const res = await axios.get(`https://api.botcahx.eu.org/api/tools/removebg?url=${encodeURIComponent(url)}&apikey=${btc}`);
    const resultUrl = res.data?.url;

    if (!resultUrl) throw 'Gagal menghapus background.';

    // Ambil hasil gambar dan convert ke WebP (stiker)
    const img = await axios.get(resultUrl, { responseType: 'arraybuffer' });

    await conn.sendFile(
      m.chat,
      await sticker5(img.data, false, 'No Baground', 'By Jagpro'),
      'sticker.webp',
      '',
      m,
      { packname: 'Jagoan Project', author: 'StickerBG' }
    );
    
  } catch (e) {
    console.error(e);
    m.reply('🚫 Terjadi kesalahan saat membuat stiker tanpa background.');
  }
};

handler.command = ['stickerbg'];
handler.help = ['stickerbg'];
handler.tags = ['sticker'];
handler.limit = 10;
handler.premium = false;

module.exports = handler;