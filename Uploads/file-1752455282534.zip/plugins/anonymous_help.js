
/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/
let handler = async (m, { conn }) => {
let anu = `*[ C H A T  A N O N Y M O U S ]*
*• Panduan:*
Obrolan anonim adalah bentuk obrolan daring yang identitas penggunanya tetap rahasia. Dalam obrolan anonim, pengguna tidak perlu memberikan informasi pribadi seperti nama, alamat, atau nomor telepon. Obrolan ini memungkinkan pengguna untuk berkomunikasi secara anonim dengan orang yang tidak dikenal di lingkungan daring. Obrolan anonim sering digunakan untuk berbagi cerita, mendapatkan saran, atau sekadar mengobrol dengan orang-orang dari berbagai belahan dunia tanpa takut dihakimi atau identitasnya terungkap.

*[ PERINTAH ]*
. start *[mulai anonim]*
. leave *[Akhiri anonim]*
. next *[Dapatkan panther berikutnya]*`

m.reply(anu)
}
 handler.help = ['anonymous'].map(a => a + " *[guide of AM]*")
handler.tags = ['anonymous']
handler.command = ["anonymous"]
module.exports = handler