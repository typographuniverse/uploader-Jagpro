// ✨ Plugin rpg - motor - buy ✨

let motorList = [
    { jenis: 'Honda C-70', harga: 50000000 },
    { jenis: 'Honda Beat', harga: 70000000 },
    { jenis: 'Honda Vario 150', harga: 90000000 },
    { jenis: 'Honda Pcx', harga: 100000000 },
    { jenis: 'Honda CRF', harga: 133000000 },
    { jenis: 'Yamaha RX-King', harga: 136000000 },
    { jenis: 'Yamaha Pcx', harga: 137000000 },
    { jenis: 'Yamaha Aerox', harga: 1389000000 },
    { jenis: 'Supra - X', harga: 99999999999999999 }
];

let handler = async (m, { conn, args, usedPrefix }) => { 
    let user = global.db.data.users[m.sender];

    if (!user.motors) user.motors = [];
    if (!user.motorHealth) user.motorHealth = {};

    if (!args[0]) {
        return conn.reply(m.chat, `❌ Format salah!\n\nGunakan :\n> ${usedPrefix}motor list\n> ${usedPrefix}motor beli <jenis>\n> ${usedPrefix}motor jual <jenis>\n> ${usedPrefix}motor servis <jenis>`, m);
    }

    let action = args[0].toLowerCase();

    if (action === 'list') { 
        let daftarMotor = motorList.map(m => `🛵 Jenis : ${m.jenis}\n💰 Harga : Rp${m.harga}`).join('\n\n'); 
        return conn.reply(m.chat, `🛒 Daftar Motor yang Tersedia :\n\n${daftarMotor}`, m);
    }

    if (action === 'beli') { 
        let jenisMotor = args.slice(1).join(' ').toLowerCase(); 
        let motor = motorList.find(m => m.jenis.toLowerCase() === jenisMotor);

        if (!motor) {
            return conn.reply(m.chat, `❌ Jenis motor tidak ditemukan!\n\nGunakan :\n> ${usedPrefix}motor list untuk melihat daftar motor.`, m);
        }

        if (user.money < motor.harga) {
            return conn.reply(m.chat, `🥲 Uang Anda tidak cukup!\n\n💸 Saldo Anda: Rp${user.money}`, m);
        }

        user.money -= motor.harga;
        user.motors.push(motor.jenis);
        user.motorHealth[motor.jenis] = 100; // Kesehatan motor penuh saat pembelian

        return conn.reply(m.chat, `✅ Sukses membeli motor\n\n🛵 motor : ${motor.jenis}\n💰 Harga : Rp${motor.harga}`, m);
    }

    if (action === 'jual') { 
        let jenisMotor = args.slice(1).join(' ').toLowerCase(); 
        let motorIndex = user.motors.findIndex(m => m.toLowerCase() === jenisMotor);

        if (motorIndex === -1) {
            return conn.reply(m.chat, "😹 Anda tidak memiliki motor tersebut untuk dijual!", m);
        }

        let motor = motorList.find(m => m.jenis.toLowerCase() === jenisMotor);
        let hargaJual = Math.floor(motor.harga * 0.7);
        user.money += hargaJual;
        user.motors.splice(motorIndex, 1);
        delete user.motorHealth[motor.jenis];

        return conn.reply(m.chat, `✅ Sukses menjual motor\n\n🛵 motor : ${motor.jenis}\n💰 harga : Rp${hargaJual}`, m);
    }

    if (action === 'servis') { 
        let jenisMotor = args.slice(1).join(' ').toLowerCase(); 
        let motor = user.motors.find(m => m.toLowerCase() === jenisMotor);

        if (!motor) {
            return conn.reply(m.chat, "❌ Anda tidak memiliki motor tersebut untuk diservis!", m);
        }

        let motorData = motorList.find(m => m.jenis.toLowerCase() === jenisMotor);
        let biayaServis = Math.floor(motorData.harga * 0.1);

        if (user.money < biayaServis) {
            return conn.reply(m.chat, `💸 Uang Anda tidak cukup untuk servis!\n\n Biaya servis: Rp${biayaServis}`, m);
        }

        user.money -= biayaServis;
        user.motorHealth[motor] = 100;

        return conn.reply(m.chat, `🔧 Motor ${motor} telah diservis dan kembali ke kondisi maksimal!`, m);
    }
};

handler.help = ['motor list', 'motor beli <jenis>', 'motor jual <jenis>', 'motor servis <jenis>']; 
handler.tags = ['rpg']; 
handler.command = ['motor'];

module.exports = handler;