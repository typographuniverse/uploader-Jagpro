let handler = async (m, { conn, text, isOwner }) => {
   if (!text) return m.reply('• *Example:* .creategc *[Nama Grup]*')
   try {
       m.reply('Mohon tunggu, sedang membuat grup...')
       let group = await conn.groupCreate(text, [m.sender])
       let link = await conn.groupInviteCode(group.gid)
       let url = 'https://chat.whatsapp.com/' + link;
       
       // Mempromosikan pembuat grup menjadi admin
       await conn.groupParticipantsUpdate(group.gid, [m.sender], "promote")
       
       m.reply(`_Berhasil Membuat Grup *${text}*_

*Nama:* ${text}
*ID:* ${group.gid}
*Link:* ${url}`)
   } catch (e) {
       console.error(e)
       m.reply('Gagal membuat grup. Pastikan format benar dan coba lagi.')
   }
}

handler.help = ['creategroup'].map(a => a + " *[Nama Grup]*")
handler.tags = ['owner']
handler.command = /^((create|buat)(gc|grup|group))$/
handler.owner = true
handler.rowner = true
handler.group = true

module.exports = handler
