const fs = require('fs');
const path = require('path');
const axios = require('axios');
const cron = require('node-cron');

const FILE_PATH = path.join(__dirname, '../lib/autosholat.json');
if (!fs.existsSync(FILE_PATH)) {
    fs.writeFileSync(FILE_PATH, JSON.stringify({ aktif: true, grups: [], hidetag: false, close: false }, null, 2));
}

// SESUAIKAN 
const jadwalSholat = {
    Subuh: "04:25",
    Dzuhur: "12:05",
    Ashar: "15:05",
    Maghrib: "17:55",
    Isya: "18:54"
};

const sholatThumbnails = [
    "https://images.pexels.com/photos/460680/pexels-photo-460680.jpeg?auto=compress&cs=tinysrgb&w=600",
    "https://images.pexels.com/photos/161276/moscow-cathedral-mosque-prospekt-mira-ramadan-sky-161276.jpeg?auto=compress&cs=tinysrgb&w=600",
    "https://images.pexels.com/photos/2406731/pexels-photo-2406731.jpeg?auto=compress&cs=tinysrgb&w=600"
];

// JADWALKAN CRON SETELAH BOT NYALA
const schedulePrayerReminders = () => {

    cron.getTasks().forEach(task => task.stop());
    cron.getTasks().clear();

    for (const [sholat, waktu] of Object.entries(jadwalSholat)) {
        const [jam, menit] = waktu.split(':');

        cron.schedule(`${menit} ${jam} * * *`, async () => {
            const data = JSON.parse(fs.readFileSync(FILE_PATH));
            if (!data.aktif || !data.grups.length) return;

            for (let id of data.grups) {
                try {
                    const thumbnail = sholatThumbnails[Math.floor(Math.random() * sholatThumbnails.length)];
                    const caption = `Hallo semuanyaa..\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat.\n\n> Sholat adalah tiang agama, maka barangsiapa mendirikannya, sungguh ia telah menegakkan agama, dan barangsiapa meninggalkannya, sungguh ia telah merobohkan agama.. (HR. Baihaqi).`;

                    const messageOptions = {
                        text: caption,
                        contextInfo: {
                            externalAdReply: {
                                title: `Waktu Sholat ${sholat} Telah Tiba`,
                                thumbnailUrl: thumbnail,
                                mediaType: 1,
                                renderLargerThumbnail: true,
                                sourceUrl: "https://Marilah Kita Sholat~"
                            }
                        }
                    };

                    let participants = [];
                    if (data.hidetag) {
                        participants = await global.conn.groupMetadata(id).then(res => res.participants.map(p => p.id)) || [];
                        messageOptions.mentions = participants;
                    }
                    
                    const sentMessage = await global.conn.sendMessage(id, messageOptions);

                    const audioUrl = (sholat === 'Subuh')
                        ? "https://github.com/ChandraGO/Data-Jagoan-Project/raw/525643df448dada7f6edb076eb8b8665fa9db552/src/ayam.MP3"
                        : "https://github.com/ChandraGO/Data-Jagoan-Project/raw/525643df448dada7f6edb076eb8b8665fa9db552/src/azan.MP3";

                    const { data: audioData } = await axios.get(audioUrl, { responseType: 'arraybuffer' });
                    const audioMessage = await global.conn.sendMessage(id, {
                        audio: Buffer.from(audioData),
                        mimetype: 'audio/mpeg',
                        ptt: true,
                        contextInfo: {
                            mentionedJid: data.hidetag ? participants : []
                        }
                    }, { quoted: sentMessage });

                    if (data.hidetag) {
                        await global.conn.sendMessage(id, {
                            react: { text: "📢", key: audioMessage.key }
                        });
                    }

                    if (data.close) {
                        await global.conn.groupSettingUpdate(id, 'announcement');
                        setTimeout(() => {
                            global.conn.groupSettingUpdate(id, 'not_announcement');
                        }, 5 * 60 * 1000); // 5 menit
                    }
                } catch (e) {
                    console.warn(`Gagal kirim ke grup ${id} untuk sholat ${sholat}:`, e.message);
                }
            }
        }, {
            timezone: 'Asia/Jakarta'
        });
    }
};

setTimeout(schedulePrayerReminders, 3000);

// COMMAND HANDLER
let handler = async (m, { conn, command, args, isAdmin, participants }) => {
    const data = JSON.parse(fs.readFileSync(FILE_PATH));
    const grups = data.grups;
    const grupId = m.chat;

    if (!m.isGroup) return m.reply("*‼️ AKSES DITOLAK*\n> perintah ini hanya bisa digunakan didalam group.");

    switch (args[0]?.toLowerCase()) {
        case 'add':
            if (!isAdmin) return m.reply("*‼️ AKSES DITOLAK*\n> hanya admin yang dapat menambahkan group kedalam daftar jadwal autosholat.");
            if (grups.includes(grupId)) return m.reply("*✅ GROUP SUDAH TERDAFTAR*\n> group ini sudah terdaftar dalam jadwal autosholat.");
            grups.push(grupId);
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            m.reply("*✅ BERHASIL MENAMBAHKAN GROUP*\n> group ini telah ditambahkan ke daftar jadwal autosholat.");
            break;

        case 'del':
            if (!isAdmin) return m.reply("*‼️ AKSES DITOLAK*\n> hanya admin yang dapat menghapus group dari daftar jadwal autosholat.");
            const index = parseInt(args[1]) - 1;
            if (isNaN(index) || !grups[index]) return m.reply("*‼️ FORMAT TIDAK VALID*\n> masukan nomor yang benar dari daftar jadwal autosholat untuk dihapus.\n\n`.autosholat list`");
            const removed = grups.splice(index, 1);
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            m.reply(`*✅ GROUP TELAH DIHAPUS*\n> ${removed}`);
            break;

        case 'list':
            if (!grups.length) return m.reply("📭 *DAFTAR KOSONG*\n> belum ada group yang terdaftar kedalam autosholat.");
            let text = `*📝 DAFTAR GROUP AUTOSHOLAT*\n\n`;
            for (let i = 0; i < grups.length; i++) {
                const metadata = await conn.groupMetadata(grups[i]).catch(() => null);
                text += `${i + 1}. NAMA : ${metadata?.subject || 'tidak ditemukan'}\n    ID : @${grups[i].split('@')[0]}\n\n`;
            }
            conn.sendMessage(m.chat, { text, mentions: grups });
            break;

        case 'on':
            if (!isAdmin) return m.reply("*‼️ AKSES DITOLAK*\n> hanya admin yang dapat mengaktifkan autosholat.");
            if (data.aktif) return m.reply("*⚙️ AUTOSHOLAT : ON*\n> jadwal autosholat sudah aktif.");
            data.aktif = true;
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            schedulePrayerReminders();
            m.reply("*✅ AUTOSHOLAT DIAKTIFKAN*\n> notifikasi waktu sholat akan dikirim.");
            break;

        case 'off':
            if (!isAdmin) return m.reply("*‼️ AKSES DITOLAK*\n> hanya admin yang dapat menonaktifkan autosholat.");
            if (!data.aktif) return m.reply("*⚙️ AUTOSHOLAT : OFF*\n> jadwal autosholat sudah nonaktif.");
            data.aktif = false;
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            schedulePrayerReminders(); 
            m.reply("*⛔ AUTOSHOLAT DINONAKTIFKAN*\n> jadwal autosholat dihentikan.");
            break;

        case 'hidetag':
            if (!isAdmin) return m.reply("*‼️ AKSES DITOLAK*\n> hanya admin yang dapat mengubah mode hidetag.");
            if (!['on', 'off'].includes(args[1]?.toLowerCase())) return m.reply("*‼️ FORMAT TIDAK VALID*\n> gunakan `.autosholat hidetag on` atau `.autosholat hidetag off`");
            data.hidetag = args[1].toLowerCase() === 'on';
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            m.reply(`*✅ MODE HIDETAG ${args[1].toUpperCase()}*\n> pengingat autosholat akan ${args[1].toLowerCase() === 'on' ? 'menyebut semua member (hidetag)' : 'tidak menyebut member.'}`);
            break;

        case 'close':
            if (!isAdmin) return m.reply("*‼️ AKSES DITOLAK*\n> hanya admin yang dapat mengubah mode close.");
            if (!['on', 'off'].includes(args[1]?.toLowerCase())) return m.reply("*‼️ FORMAT TIDAK VALID*\n> gunakan `.autosholat close on` atau `.autosholat close off`");
            data.close = args[1].toLowerCase() === 'on';
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            m.reply(`*✅ MODE CLOSE ${args[1].toUpperCase()}*\n> group akan ${args[1].toLowerCase() === 'on' ? 'ditutup selama 5 menit setelah pemberitahuan sholat.' : 'tidak ditutup setelah azan.'}`);
            break;

        case 'onall':
            if (!isAdmin) return m.reply("*‼️ AKSES DITOLAK*\n> hanya admin yang dapat mengaktifkan mode onall.");
            if (data.aktif && data.hidetag && data.close) return m.reply("*⚙️ MODE ALL SUDAH AKTIF*\n> autosholat, hidetag, dan close group sudah diaktifkan.");
            data.aktif = true;
            data.hidetag = true;
            data.close = true;
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            schedulePrayerReminders();
            m.reply("*✅ MODE ALL DIAKTIFKAN*\n> autosholat diaktifkan, pesan dan voicenote akan menyebut semua member (hidetag), dan group akan ditutup selama 5 menit setelah pemberitahuan.");
            break;

        case 'offall':
            if (!isAdmin) return m.reply("*‼️ AKSES DITOLAK*\n> hanya admin yang dapat menonaktifkan mode offall.");
            if (!data.aktif && !data.hidetag && !data.close) return m.reply("*⚙️ MODE ALL SUDAH NONAKTIF*\n> autosholat, hidetag, dan close group sudah dinonaktifkan.");
            data.aktif = false;
            data.hidetag = false;
            data.close = false;
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            schedulePrayerReminders(); 
            m.reply("*⛔ MODE ALL DINONAKTIFKAN*\n> autosholat dinonaktifkan, bot tidak akan mengirimkan pengingat waktu sholat.");
            break;

        case 'info':
            m.reply(`
📚 *PENJELASAN AUTOSHOLAT*

> autosholat adalah fitur yang ketika diaktifkan akan mengirim pemberitahuan bahwa telah tiba saatnya waktu untuk sholat kepada group yang terdaftar.

⚙️ *CARA PENGGUNAAN*

– .autosholat add
> menambahkan group ke daftar
– .autosholat del <nomor>
> menghapus group dari daftar
– .autosholat list
> melihat group yang terdaftar
– .autosholat on / off
> aktifkan / nonaktifkan fitur autosholat
– .autosholat hidetag on / off
> aktifkan untuk mention semua member saat azan
– .autosholat close on / off
> aktifkan untuk tutup grup selama 5 menit saat azan
– .autosholat onall
> aktifkan autosholat, hidetag, dan close group sekaligus
– .autosholat offall
> nonaktifkan autosholat, hidetag, dan close group sekaligus
`.trim());
            break;

        default:
            m.reply("*‼️ PERINTAH TIDAK VALID*\n\n– ketik `.autosholat info` untuk melihat panduan.");
            break;
    }
};

handler.help = ['autosholat'];
handler.tags = ['group', 'main'];
handler.command = /^autosholat$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;