let handler = async (m, { conn, isAdmin, isOwner, args, usedPrefix, command }) => {
  if (!(isAdmin || isOwner)) {
    global.dfail('admin', m, conn)
    throw false
  }
  
  let isClose = {
    'open': 'not_announcement',
    'buka': 'not_announcement',
    'on': 'not_announcement',
    '1': 'not_announcement',
    'close': 'announcement',
    'tutup': 'announcement',
    'off': 'announcement',
    '0': 'announcement',
  }[(args[0] || '')]
  
  if (isClose === undefined || !args[1]) {
    let caption = `*🔹 Cara Menggunakan Perintah Grup Time 🔹*

Gunakan perintah berikut untuk mengatur status grup dengan durasi:

✅ *Membuka Grup setelah Durasi Tertentu*:
➜ \`${usedPrefix + command} open 10m\` *(grup akan terbuka dalam 10 menit)*
➜ \`${usedPrefix + command} buka 1h\` *(grup akan terbuka dalam 1 jam)*

❌ *Menutup Grup setelah Durasi Tertentu*:
➜ \`${usedPrefix + command} close 30s\` *(grup akan tertutup dalam 30 detik)*
➜ \`${usedPrefix + command} tutup 2h\` *(grup akan tertutup dalam 2 jam)*

⚠️ *Jika ingin langsung membuka atau menutup grup tanpa durasi, gunakan perintah:*
➜ \`${usedPrefix}gc\`
➜ \`${usedPrefix}grup\`

🕒 *Format Waktu yang Tersedia:*
- \`s\` = detik (contoh: 30s = 30 detik)
- \`m\` = menit (contoh: 10m = 10 menit)
- \`h\` = jam (contoh: 1h = 1 jam)`
    m.reply(caption)
    throw false
  }
  
  if (!/\d+[smh]$/.test(args[1])) {
    m.reply("❌ Format waktu tidak valid! Harap sertakan satuan waktunya (s, m, h). \nContoh: 10m, 30s, 2h\n\n🕒 *Format Waktu yang Tersedia:*\n- \`s\` = detik (contoh: 30s = 30 detik)\n- \`m\` = menit (contoh: 10m = 10 menit)\n- \`h\` = jam (contoh: 1h = 1 jam)")
    throw false
  }
  
  let time = parseTime(args[1]);
  
  m.reply(`⏳ Grup akan *${isClose == 'announcement' ? 'ditutup' : 'dibuka'}* dalam *${clockString(time)}*...`);
  
  setTimeout(async () => {
    await conn.groupSettingUpdate(m.chat, isClose).then(async _ => {
      let message = isClose == 'announcement' 
        ? `🔒 Grup telah *ditutup*! Sekarang hanya *sesepuh grup* yang bisa mengirim pesan. 🔕`
        : `🔓 Grup telah *dibuka*! Sekarang semua *anggota grup* dapat mengirim pesan kembali. 🎉`;
      m.reply(message);
    });
  }, time);
}

handler.help = ['gctime'].map(a => a + ' *[open/close time]*')
handler.tags = ['group']
handler.command = /^(gctime)$/i

handler.botAdmin = true
handler.group = true

module.exports = handler

function parseTime(input) {
  let match = input.match(/(\d+)(s|m|h)$/)
  if (!match) return 0
  let value = parseInt(match[1])
  let unit = match[2]
  
  switch (unit) {
    case 's': return value * 1000
    case 'm': return value * 60000
    case 'h': return value * 3600000
    default: return value * 3600000
  }
}

function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}