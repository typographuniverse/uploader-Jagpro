/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

let { generateWAMessageFromContent, proto, prepareWAMessageMedia, extractImageThumb } = require("@whiskeysockets/baileys")
let moment = require('moment-timezone')
moment.tz.setDefault('Asia/Makassar').locale('id')

let handler = async(m, { conn, usedPrefix, command }) => {

let groupList = async () => Object.entries(await conn.groupFetchAllParticipating()).slice(0).map(entry => entry[1])
  let groups = await groupList()
    let rows = []
      groups.map(x => {
        let v = global.db.data.chats[x.id]
          if (v) {
           rows.push({
            title: x.subject,
             id: `${usedPrefix}gc ${x.id}`,
              description: `[ ${v.stay ? 'FOREVER' : (v.expired == 0 ? 'NOT SET' : Func.timeReverse(v.expired - new Date() * 1))}  | ${x.participants.length} | ${(v.isBanned ? 'OFF' : 'ON')} | ${moment(v.activity).format('DD/MM/YY HH:mm:ss')} ]`
                 })
                   }
          })
           let sections = [{
             rows: rows
              }]
               let listMessage = {
                title: 'Click here!', 
                 sections
                  }
                  let msg = generateWAMessageFromContent(m.chat, {
                   viewOnceMessage: {
                    message: {
                     "messageContextInfo": {
                      "deviceListMetadata": {},
                       "deviceListMetadataVersion": 2
                         },
                          interactiveMessage: proto.Message.InteractiveMessage.create({
                           body: proto.Message.InteractiveMessage.Body.create({
                            text: `Bot telah tergabung di *${groups.length}* groups.`
                             }),
                              footer: proto.Message.InteractiveMessage.Footer.create({
                               text: '_Groups_'
                                }),
                                 header: proto.Message.InteractiveMessage.Header.create({
                                  title: '✨Jagoan Project✨',
                                   hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: global.thumlistgrup } }, { upload: conn.waUploadToServer }))
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                   buttons: [
                                  {
                                 "name": "single_select",
                                "buttonParamsJson": JSON.stringify(listMessage) 
                               }
                              ],
                             })
                            })
                           }
                          }
                         }, { userJid: m.chat, quoted: m })
                        await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
}

handler.help = ['grouplist']
handler.tags = ['group']
handler.command = /^(listgroups|listgrup|gruplist|listgroup|groupslist|grouplist)$/i
handler.owner = true
module.exports = handler