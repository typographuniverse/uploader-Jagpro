const { webp2mp4 } = require('../function/webp2mp4');
const ffmpeg = require('fluent-ffmpeg');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

let handler = async (m, { conn, usedPrefix, command }) => {
    if (!m.quoted) throw `Balas stiker atau video dengan caption *${usedPrefix + command}*`;
    let mime = m.quoted.mimetype || '';
    
    // Periksa apakah input adalah stiker WebP atau video
    if (!/webp|video/.test(mime)) throw `Balas stiker (WebP) atau video dengan caption *${usedPrefix + command}*`;
    
    let media = await m.quoted.download();
    let out = Buffer.alloc(0);
    
    try {
        if (/webp/.test(mime)) {
            // Konversi stiker WebP ke MP4 (GIF)
            out = await webp2mp4(media);
        } else if (/video/.test(mime)) {
            // Simpan video sementara
            const inputPath = `./tmp/input-${Date.now()}.mp4`;
            const outputPath = `./tmp/output-${Date.now()}.mp4`;
            require('fs').writeFileSync(inputPath, media);
            
            // Konversi video ke GIF menggunakan ffmpeg
            await new Promise((resolve, reject) => {
                ffmpeg(inputPath)
                    .outputOptions([
                        '-vf', 'fps=15,scale=320:-1:flags=lanczos', // Atur FPS dan skala
                        '-c:v', 'libx264', // Codec untuk kompatibilitas WhatsApp
                        '-pix_fmt', 'yuv420p', // Format pixel untuk kompatibilitas
                        '-an' // Hilangkan audio
                    ])
                    .toFormat('mp4')
                    .save(outputPath)
                    .on('end', () => resolve())
                    .on('error', (err) => reject(err));
            });
            
            // Baca hasil konversi
            out = require('fs').readFileSync(outputPath);
            
            // Hapus file sementara
            require('fs').unlinkSync(inputPath);
            require('fs').unlinkSync(outputPath);
        }
        
        // Kirim hasil sebagai GIF
        await conn.sendFile(m.chat, out, 'output.mp4', global.wm || 'Converted to GIF', m, true, {
            gifPlayback: true,
            gifAttribution: 2
        });
    } catch (err) {
        console.error('[ERROR] Gagal mengonversi ke GIF:', err);
        throw `Gagal mengonversi ke GIF: ${err.message}`;
    }
};

handler.help = ['togift'];
handler.tags = ['tools'];
handler.command = /^(togift)$/i;

module.exports = handler;