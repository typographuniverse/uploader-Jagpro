const axios = require('axios');
 
let handler = async (m, { conn, text, prefix, command }) => {
  if (!text) {
    return m.reply(`Masukkan username Instagram\n\nContoh:\n.${command} shelter_for_us`);
  }
 
  await conn.sendMessage(m.chat, {
    react: {
      text: "⏱️",
      key: m.key,
    },
  });
 
  try {
    const response = await axios.get(`https://api.vreden.web.id/api/igstalk?query=${text}`);
    const { result } = response.data;
 
    await conn.sendMessage(m.chat, {
      image: {
        url: result.image,
      },
      caption: `*INSTA STALKER*\n\n` +
        `*Nickname :* ${result.user.username}\n` +
        `*Fullname :* ${result.user.full_name}\n` +
        `*Postingan :* ${result.user.media_count}\n` +
        `*Followers :* ${result.user.follower_count}\n` +
        `*Following :* ${result.user.following_count}\n` +
        `*Jenis Akun:* ${result.user.is_business ? "Bisnis" : 'Pribadi'}\n` +
        `*Bio :*\n${result.user.biography || 'Tidak ada bio.'}`,
    }, { quoted: m });
 
  } catch (error) {
    console.error(error);
    m.reply("Tidak dapat menemukan username atau terjadi kesalahan pada API.");
  }
};
 
handler.help = ['igstalk <username>'];
handler.tags = ['stalk'];
handler.command = ['igstalk','premium'];
handler.limit = true;
handler.premium = true;
 
module.exports = handler;