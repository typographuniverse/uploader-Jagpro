const { proto } = require('@whiskeysockets/baileys');

let handler = async (m, { conn, text, participants }) => {
    // Pastikan koneksi tersedia
    if (!conn) {
        return m.reply("❌ Bot tidak terhubung, silakan hubungi admin.");
    }

    // Cek apakah di grup
    if (!m.isGroup) {
        return m.reply("❌ Fitur ini hanya bisa digunakan di dalam grup!");
    }
    
    // Cek apakah ada teks input
    if (!text) {
        return m.reply("❌ Format salah! Contoh: .fitnah @tag text1|text2");
    }
    
    // Ambil ID pengguna yang ditag utama
    let who = m.mentionedJid && m.mentionedJid[0];
    if (!who) {
        return m.reply("⚠️ Tag salah satu pengguna!");
    }
    
    // Pisahkan teks menjadi fake dan real
    let [fake, real] = text.split('|');
    if (!fake || !real) {
        return m.reply("⚠️ Format salah! Gunakan: .fitnah @tag text1|text2");
    }
    
    // Hapus mention pengguna utama dari teks fake saja
    fake = fake.replace(`@${who.split('@')[0]}`, '').trim();
    real = real.trim();

    // Fungsi untuk mendeteksi semua mention dalam teks
    const detectMentions = (text) => {
        const mentions = [];
        const regex = /@(\d+)/g; // Mencocokkan format @nomor (contoh: @6281234567890)
        let match;
        while ((match = regex.exec(text)) !== null) {
            const number = match[1];
            // Cari nomor dalam daftar peserta grup
            const jid = participants.find(p => p.id.includes(number))?.id;
            if (jid && !mentions.includes(jid)) {
                mentions.push(jid);
            }
        }
        return mentions;
    };

    // Deteksi mention dalam fake dan real text
    let fakeMentions = detectMentions(fake);
    let realMentions = detectMentions(real);

    // Tambahkan pengguna utama yang ditag ke mentions untuk fake dan real
    if (!fakeMentions.includes(who)) {
        fakeMentions.push(who); // Tag pengguna utama secara tersembunyi di fake
    }
    if (!realMentions.includes(who)) {
        realMentions.push(who); // Tag pengguna utama secara tersembunyi di real
    }

    // Buat struktur pesan fake
    let fakeMessage = {
        key: { 
            fromMe: false, 
            participant: who, 
            ...(m.isGroup ? { remoteJid: m.chat } : { remoteJid: who })
        },
        message: { 
            conversation: fake,
            extendedTextMessage: {
                text: fake,
                contextInfo: {
                    mentionedJid: fakeMentions // Mention di pesan fake, termasuk pengguna utama
                }
            }
        }
    };

    // Kirim pesan dengan try-catch untuk menangkap error
    try {
        // Kirim pesan fitnah dengan mention sesuai input dan quote
        await conn.sendMessage(m.chat, { 
            text: real, 
            mentions: realMentions // Mention semua pengguna yang terdeteksi, termasuk utama
        }, { quoted: fakeMessage });
        
        // Hapus pesan pengirim (command) setelah pesan fitnah dikirim
        await conn.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant || m.key.remoteJid
            }
        });
    } catch (error) {
        console.error("Gagal memproses perintah:", error);
        return m.reply("❌ Gagal memproses perintah, coba lagi nanti.");
    }
};

handler.help = ["fitnah"].map(a => a + ' *@tag text1|text2*');
handler.tags = ["game"];
handler.command = ["fitnah"];
handler.group = true;

module.exports = handler;