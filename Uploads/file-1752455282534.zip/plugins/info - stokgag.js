// 📝 plugin info - stokgag

// 🪴 Plugin info - stokgag.js

const fetch = require('node-fetch');

const handler = async (m) => {
  try {
    const res = await fetch('https://zenzxz.dpdns.org/info/growagardenstock');
    const json = await res.json();

    if (!json.status || !json.data?.data) {
      throw 'yah data nya gaada';
    }

    const data = json.data.data;

    const formatItems = (title, items, icon) => {
      if (!items?.length) return '';
      let text = `\n${icon} *${title.toUpperCase()} :*\n`;
      for (const item of items) {
        text += `• ${item.name} ➜ *${item.quantity}*\n`;
      }
      return text;
    };

    const formatWeather = (w) => {
      return `\n🌦️ *CUACA SAAT INI :*\n• 🌤️ Tipe : *${w.type}*\n• 🔄 Aktif : *${w.active ? 'Ya' : 'Tidak'}*\n`;
    };

    const formatWeatherHistory = (history) => {
      if (!history?.length) return '';
      let text = `\n🗒️ *RIWAYAT CUACA :*\n`;
      for (const w of history) {
        text += `• ${w.type} (${w.active ? '🌟 Aktif' : '❌ Tidak'})\n`;
      }
      return text;
    };

    let output = `🌱 *Stok Grow a Garden* 🏡\n`;
    output += formatItems('seeds', data.seeds, '🌾');
    output += formatItems('gear', data.gear, '⚙️');
    output += formatItems('eggs', data.eggs, '🥚');
    output += formatItems('cosmetics', data.cosmetics, '💄');
    output += formatItems('honey', data.honey, '🍯');
    output += formatWeather(data.weather);
    output += formatWeatherHistory(data.weatherHistory);

    output += `\n⏳ *Update Terakhir:* ${new Date(data.lastGlobalUpdate).toLocaleString('id-ID')}`;

    m.reply(output.trim());
  } catch (e) {
    m.reply('🥺 Waduh bree, gagal mengambil data Grow a Garden, coba cek API-nya yah~');
    console.error(e);
  }
};

handler.help = ['stokgag'];
handler.tags = ['info'];
handler.command = ['stokgag'];

module.exports = handler;