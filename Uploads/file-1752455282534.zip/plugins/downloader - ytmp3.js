let fetch = require('node-fetch');
let search = require('yt-search');

const api = {
  xterm: {
    url: global.apixtermurl,
    key: global.apixtermkey
  }
};

async function youtube(url, type) {
  let res = await fetch(`${api.xterm.url}/api/downloader/youtube?url=${url}&type=${type}&key=${api.xterm.key}`)
    .then(response => response.json());
  return res;
}

let handler = async (m, { conn, text }) => {
  if (!text) throw '❗ Masukkan judul atau link YouTube terlebih dahulu!';

  try {
    await m.reply("⏳ Sedang memproses audio...");

    let url = text.includes("youtube.com") || text.includes("youtu.be") ? text : null;

    if (!url) {
      let look = await search(text);
      if (!look.videos.length) throw '❌ Video tidak ditemukan!';
      url = look.videos[0].url;
    }

    let json;

    // Try Primary API (Botcahx)
    try {
      const res = await fetch(`https://api.botcahx.eu.org/api/dowloader/yt?url=${url}&apikey=${global.btc}`);
      json = await res.json();

      if (!json || !json.result || !json.result.mp3) throw new Error('Primary API gagal');
      json.result.api_source = 'Botcahx';
    } catch (err) {
      console.error('[Botcahx Error]', err);

      // Fallback to Xterm
      const fallback = await youtube(url, "mp3");
      if (!fallback || !fallback.status || !fallback.data || !fallback.data.dlink)
        return conn.reply(m.chat, "❌ Gagal mendapatkan audio dari kedua API!", m);

      json = {
        result: {
          title: fallback.data.title || "Tidak diketahui",
          source: url,
          thumb: fallback.data.thumb || "https://example.com/default-thumbnail.jpg",
          mp3: fallback.data.dlink,
          duration: 0,
          api_source: 'Xterm'
        }
      };
    }

    let { title, source, thumb, mp3, duration, api_source } = json.result;

    let caption = `🎵 *YouTube Audio Berhasil Dikonversi!*\n\n`;
    caption += `🎬 *Judul:* ${title}\n`;
    caption += `⏱️ *Durasi:* ${formatDuration(duration)}\n`;
    caption += `🔗 *URL:* ${source}\n`;
    caption += `📡 *Sumber API:* ${api_source}`;

    await conn.sendMessage(m.chat, {
      audio: { url: mp3 },
      mimetype: 'audio/mpeg',
      ptt: false,
      caption,
      contextInfo: {
        externalAdReply: {
          title,
          thumbnailUrl: thumb,
          sourceUrl: source,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    conn.reply(m.chat, "❌ Terjadi kesalahan saat memproses permintaanmu!", m);
  }
};

function formatDuration(seconds) {
  let h = Math.floor(seconds / 3600);
  let m = Math.floor((seconds % 3600) / 60);
  let s = seconds % 60;
  return [h, m, s].map(v => v < 10 ? "0" + v : v).join(":");
}

handler.help = ['ytmp3'];
handler.command = ['ytmp3', 'ytaudio', 'mp3', 'yta'];
handler.tags = ['downloader'];
handler.exp = 0;
handler.limit = true;
handler.premium = false;

module.exports = handler;
