const fs = require('fs');
const path = require('path');
const cron = require('node-cron');

const FILE_PATH = path.join(__dirname, '../lib/autoabsen.json');
if (!fs.existsSync(FILE_PATH)) {
    fs.writeFileSync(FILE_PATH, JSON.stringify({ aktif: true, grups: [], hidetag: false, schedule: '30 7' }, null, 2));
    console.log(`Created default autoabsen.json at ${FILE_PATH}`);
} else {
    try {
        const data = JSON.parse(fs.readFileSync(FILE_PATH));
        if (!data.schedule) {
            data.schedule = '30 7';
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            console.log(`Added default schedule '30 7' to autoabsen.json`);
        }
    } catch (e) {
        console.error(`Error reading autoabsen.json: ${e.message}`);
        fs.writeFileSync(FILE_PATH, JSON.stringify({ aktif: true, grups: [], hidetag: false, schedule: '30 7' }, null, 2));
        console.log(`Recreated autoabsen.json due to error`);
    }
}

// JADWALKAN CRON SETELAH BOT NYALA
const scheduleAbsenPolling = () => {
    cron.getTasks().forEach(task => task.stop());
    cron.getTasks().clear();

    const data = JSON.parse(fs.readFileSync(FILE_PATH));
    const schedule = data.schedule || '30 7'; // Fallback if schedule is undefined
    const [schedMinute, schedHour] = schedule.split(' ');

    // Jadwal absen setiap hari sesuai pengaturan (default jam 07:30)
    cron.schedule(`${schedMinute} ${schedHour} * * *`, async () => {
        if (!data.aktif || !data.grups.length) return;

        for (let id of data.grups) {
            try {
                // Ambil metadata grup untuk nama grup
                const metadata = await global.conn.groupMetadata(id).catch(() => null);
                const groupName = metadata?.subject || 'Tidak Diketahui';

                // Format tanggal, hari, dan jam
                const now = new Date();
                const day = now.toLocaleDateString('id-ID', { weekday: 'long' }); // e.g., "Senin"
                const date = now.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }); // e.g., "07 Juli 2025"
                const time = `${schedHour.padStart(2, '0')}:${schedMinute.padStart(2, '0')} WIB`; // Use scheduled time

                let participants = [];
                let sentMessage = null;
                if (data.hidetag) {
                    participants = await global.conn.groupMetadata(id).then(res => res.participants.map(p => p.id)) || [];
                    // Kirim pesan hidetag sebelum polling dengan info tambahan
                    sentMessage = await global.conn.sendMessage(id, {
                        text: `ABSEN HARIAN!! SILAHKAN ISI ABSEN DIBAWAH INI 📢\n\n🏠 GROUP: ${groupName}\n🌏 HARI: ${day}\n📆 TANGGAL: ${date}\n🕒 JAM: ${time}`,
                        contextInfo: { mentionedJid: participants }
                    });
                    // Tambahkan reaksi 📢 ke pesan hidetag
                    await global.conn.sendMessage(id, {
                        react: { text: '📢', key: sentMessage.key }
                    });
                }

                // Kirim polling
                const pollOptions = {
                    poll: {
                        name: 'ABSEN HARI INI',
                        values: ['Hadir bang ☝🏻😜', 'Malas menanggapi 🧢', 'Lagi sakit bang 🤒🤧', 'Pura pura gakliat 🙄🧐'],
                        selectableCount: 1 // Hanya 1 pilihan yang bisa dipilih
                    },
                    contextInfo: { mentionedJid: participants }
                };

                await global.conn.sendMessage(id, pollOptions, { quoted: sentMessage });
            } catch (e) {
                console.warn(`Gagal kirim polling absen ke grup ${id}:`, e.message);
            }
        }
    }, {
        timezone: 'Asia/Jakarta'
    });
};

setTimeout(scheduleAbsenPolling, 3000);

// COMMAND HANDLER
let handler = async (m, { conn, command, args, isAdmin, participants }) => {
    const data = JSON.parse(fs.readFileSync(FILE_PATH));
    const grups = data.grups;
    const grupId = m.chat;

    let ppUrl = global.thumb;
    try { ppUrl = await conn.profilePictureUrl(m.sender, 'image'); } catch (e) {}

    const contextInfoError = (title, msg) => ({
        text: msg,
        contextInfo: {
            externalAdReply: {
                title,
                body: '',
                thumbnailUrl: ppUrl,
                mediaType: 1,
                renderLargerThumbnail: false
            }
        }
    });

    if (!m.isGroup) {
        return conn.sendMessage(m.chat, contextInfoError(
            '‼️ Akses Ditolak',
            '*‼️ AKSES DITOLAK*\n> Perintah ini hanya bisa digunakan di dalam grup.'
        ), { quoted: m });
    }

    switch (args[0]?.toLowerCase()) {
        case 'add':
            if (!isAdmin) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '‼️ Akses Ditolak',
                    '*‼️ AKSES DITOLAK*\n> Hanya admin yang dapat menambahkan grup ke daftar autoabsen.'
                ), { quoted: m });
            }
            if (grups.includes(grupId)) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '✅ Grup Sudah Terdaftar',
                    '*✅ GRUP SUDAH TERDAFTAR*\n> Grup ini sudah terdaftar dalam jadwal autoabsen.'
                ), { quoted: m });
            }
            grups.push(grupId);
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            await conn.sendMessage(m.chat, {
                text: '*✅ BERHASIL MENAMBAHKAN GRUP*\n> Grup ini telah ditambahkan ke daftar jadwal autoabsen.',
                contextInfo: {
                    externalAdReply: {
                        title: '✅ Berhasil Menambahkan Grup',
                        body: '',
                        thumbnailUrl: ppUrl,
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            }, { quoted: m });
            break;

        case 'del':
            if (!isAdmin) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '‼️ Akses Ditolak',
                    '*‼️ AKSES DITOLAK*\n> Hanya admin yang dapat menghapus grup dari daftar autoabsen.'
                ), { quoted: m });
            }
            const index = parseInt(args[1]) - 1;
            if (isNaN(index) || !grups[index]) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '‼️ Format Tidak Valid',
                    '*‼️ FORMAT TIDAK VALID*\n> Masukkan nomor yang benar dari daftar autoabsen untuk dihapus.\n\n`.autoabsen list`'
                ), { quoted: m });
            }
            const removed = grups.splice(index, 1);
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            await conn.sendMessage(m.chat, {
                text: `*✅ GRUP TELAH DIHAPUS*\n> ${removed}`,
                contextInfo: {
                    externalAdReply: {
                        title: '✅ Grup Telah Dihapus',
                        body: '',
                        thumbnailUrl: ppUrl,
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            }, { quoted: m });
            break;

        case 'list':
            if (!grups.length) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '📭 Daftar Kosong',
                    '📭 *DAFTAR KOSONG*\n> Belum ada grup yang terdaftar ke dalam autoabsen.'
                ), { quoted: m });
            }
            let text = `*📝 DAFTAR GRUP AUTOABSEN*\n\n`;
            for (let i = 0; i < grpus.length; i++) {
                const metadata = await conn.groupMetadata(grups[i]).catch(() => null);
                text += `${i + 1}. NAMA: ${metadata?.subject || 'tidak ditemukan'}\n    ID: @${grups[i].split('@')[0]}\n\n`;
            }
            await conn.sendMessage(m.chat, {
                text,
                mentions: grups,
                contextInfo: {
                    externalAdReply: {
                        title: '📝 Daftar Grup Autoabsen',
                        body: '',
                        thumbnailUrl: ppUrl,
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            }, { quoted: m });
            break;

        case 'on':
            if (!isAdmin) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '‼️ Akses Ditolak',
                    '*‼️ AKSES DITOLAK*\n> Hanya admin yang dapat mengaktifkan autoabsen.'
                ), { quoted: m });
            }
            if (data.aktif && data.hidetag) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '⚙️ Autoabsen Sudah Aktif',
                    '*⚙️ AUTOABSEN: ON*\n> Autoabsen dengan hidetag sudah aktif.'
                ), { quoted: m });
            }
            data.aktif = true;
            data.hidetag = true;
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            scheduleAbsenPolling();
            const [minute, hour] = data.schedule.split(' ');
            await conn.sendMessage(m.chat, {
                text: `*✅ AUTOABSEN DIAKTIFKAN*\n> Polling absen akan dikirim setiap hari jam ${hour.padStart(2, '0')}:${minute.padStart(2, '0')} dengan hidetag.`,
                contextInfo: {
                    externalAdReply: {
                        title: '✅ Autoabsen Diaktifkan',
                        body: '',
                        thumbnailUrl: ppUrl,
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            }, { quoted: m });
            break;

        case 'off':
            if (!isAdmin) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '‼️ Akses Ditolak',
                    '*‼️ AKSES DITOLAK*\n> Hanya admin yang dapat menonaktifkan autoabsen.'
                ), { quoted: m });
            }
            if (!data.aktif) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '⚙️ Autoabsen Sudah Nonaktif',
                    '*⚙️ AUTOABSEN: OFF*\n> Autoabsen sudah nonaktif.'
                ), { quoted: m });
            }
            data.aktif = false;
            data.hidetag = false;
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            scheduleAbsenPolling();
            await conn.sendMessage(m.chat, {
                text: '*⛔ AUTOABSEN DINONAKTIFKAN*\n> Polling absen tidak akan dikirim.',
                contextInfo: {
                    externalAdReply: {
                        title: '⛔ Autoabsen Dinonaktifkan',
                        body: '',
                        thumbnailUrl: ppUrl,
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            }, { quoted: m });
            break;

        case 'set':
            if (!isAdmin) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '‼️ Akses Ditolak',
                    '*‼️ AKSES DITOLAK*\n> Hanya admin yang dapat mengatur jadwal autoabsen.'
                ), { quoted: m });
            }
            if (!args[1] || !args[1].match(/^\d{1,2}:\d{2}$/)) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '‼️ Format Tidak Valid',
                    '*‼️ FORMAT TIDAK VALID*\n> Gunakan format `.autoabsen set HH:MM`, contoh: `.autoabsen set 7:30`'
                ), { quoted: m });
            }
            const [setHour, setMinute] = args[1].split(':').map(Number);
            if (setHour < 0 || setHour > 23 || setMinute < 0 || setMinute > 59) {
                return conn.sendMessage(m.chat, contextInfoError(
                    '‼️ Waktu Tidak Valid',
                    '*‼️ WAKTU TIDAK VALID*\n> Masukkan waktu antara 00:00 dan 23:59.'
                ), { quoted: m });
            }
            data.schedule = `${setMinute} ${setHour}`;
            fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
            scheduleAbsenPolling();
            await conn.sendMessage(m.chat, {
                text: `*✅ JADWAL AUTOABSEN DIATUR*\n> Polling absen akan dikirim setiap hari jam ${args[1]}.`,
                contextInfo: {
                    externalAdReply: {
                        title: '✅ Jadwal Autoabsen Diatur',
                        body: '',
                        thumbnailUrl: ppUrl,
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            }, { quoted: m });
            break;

        case 'info':
            const [min, hr] = data.schedule.split(' ');
            await conn.sendMessage(m.chat, {
                text: `
📚 *PENJELASAN AUTOABSEN*

> Autoabsen adalah fitur yang mengirim polling absensi setiap hari dengan jam yang telah ditentukan ke grup yang terdaftar.

⚙️ *CARA PENGGUNAAN*

– .autoabsen add
> menambahkan grup ke daftar autoabsen.
– .autoabsen del <nomor>
> menghapus grup dari daftar autoabsen.
– .autoabsen list
> melihat grup yang terdaftar dalam autoabsen.
– .autoabsen on
> mengaktifkan autoabsen.
– .autoabsen off
> menonaktifkan autoabsen.
– .autoabsen set <HH:MM>
> mengatur jadwal autoabsen, contoh: \`.autoabsen set 7:30\`.
`.trim(),
                contextInfo: {
                    externalAdReply: {
                        title: '📚 Penjelasan Autoabsen',
                        body: '',
                        thumbnailUrl: ppUrl,
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            }, { quoted: m });
            break;

        default:
            await conn.sendMessage(m.chat, contextInfoError(
                '‼️ Perintah Tidak Valid',
                '*‼️ PERINTAH TIDAK VALID*\n\n– Ketik `.autoabsen info` untuk melihat panduan.'
            ), { quoted: m });
            break;
    }
};

handler.help = ['autoabsen'];
handler.tags = ['group', 'main'];
handler.command = /^autoabsen$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;