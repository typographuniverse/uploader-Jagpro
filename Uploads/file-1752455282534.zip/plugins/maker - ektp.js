const axios = require('axios');
const fs = require('fs');
const uploadImage = require('../scrape/uploadImage');

// 🌟 Plugin Fake eKTP: Bikin KTP Digital Super Kece! 😎🚀
const handler = async (m, { conn, text, command, usedPrefix }) => {
    // 🖼️ Cek apakah ada gambar yang di-reply
    const mime = (m.quoted?.mimetype || '');
    if (!/image\/(png|jpe?g|gif)/.test(mime)) {
        return m.reply('📸 Reply gambar (PNG/JPEG/GIF) yang jadi pas foto eKTP dengan caption perintah, bro! 😜');
    }

    // 📋 Contoh format yang harus diikuti
    const EXAMPLE = `${usedPrefix + command} provinsi | kota | nik | nama | ttl | jenis_kelamin | golongan_darah | alamat | rt/rw | kel/desa | kecamatan | agama | status | pekerjaan | kewarganegaraan | masa_berlaku | terbuat`;
    
    // 🕵️‍♂️ Cek kalau user lupa masukin data
    if (!text) {
        return m.reply(`*Contoh Dulu Bro:* ${EXAMPLE}\n\n*Misalnya:* ${usedPrefix + command} Jawa Barat | Cikarang | 1234567890123456 | Erickson | New York, 03-03-1990 | Laki-laki | O | Jl. Perjuangan No. 110 | 001/002 | Tangerang | Cikarang Barat | Islam | Belum Kawin | Konten Kreator | WNI | Seumur Hidup | 04-06-2006\n\n🔥 Yuk, lengkapi datanya biar KTP-nya jadi kece!`);
    }

    // ✂️ Pisah data pake tanda | dan bersihin spasi
    const parts = text.split('|').map(part => part.trim());

    // 🚨 Kalau data kurang dari 17, kasih peringatan!
    if (parts.length < 17) {
        return m.reply(`*Lengkapin Dulu Bro:* ${EXAMPLE}\n\n*Contoh:* ${usedPrefix + command} Jawa Barat | Cikarang | 1234567890123456 | Erickson | New York, 03-03-1990 | Laki-laki | O | Jl. Perjuangan No. 110 | 001/002 | Tangerang | Cikarang Barat | Islam | Belum Kawin | Konten Kreator | WNI | Seumur Hidup | 04-06-2006\n\n⚡ Jangan sampai kurang, biar KTP-nya mantap!`);
    }

    // 📦 Unpack semua data ke variabel biar rapi
    const [provinsi, kota, nik, nama, ttl, jenis_kelamin, golongan_darah, alamat, rtrw, keldesa, kecamatan, agama, status, pekerjaan, kewarganegaraan, masa_berlaku, terbuat] = parts;

    try {
        // 🔎 Kasih tanda bot lagi kerja
        await conn.sendMessage(m.chat, { react: { text: "⚙️", key: m.key } });
        m.reply('🔥 Sedang bikin KTP kece, tunggu bentar ya bro... 😎');

        // 📤 Download dan upload gambar menggunakan uploadImage
        const media = await m.quoted.download();
        const fileSizeLimit = 5 * 1024 * 1024; // 5MB
        if (media.length > fileSizeLimit) {
            throw new Error('Ukuran gambar tidak boleh melebihi 5MB');
        }
        const directLink = await uploadImage(media);

        // 🔗 Buat parameter URL untuk API
        const PARAMS = new URLSearchParams({
            provinsi,
            kota,
            nik,
            nama,
            ttl,
            jenis_kelamin,
            golongan_darah,
            alamat,
            'rt/rw': rtrw,
            'kel/desa': keldesa,
            kecamatan,
            agama,
            status,
            pekerjaan,
            kewarganegaraan,
            masa_berlaku,
            terbuat,
            pas_photo: directLink
        });

        let response;
        // 🌐 Coba API pertama (siputzx)
        try {
            const siputUrl = `https://api.siputzx.my.id/api/m/ektp?${PARAMS.toString()}`;
            response = await axios.get(siputUrl, { responseType: 'arraybuffer' });
        } catch (siputError) {
            console.warn('⚠️ API Siputz gagal, coba fallback ke FastRest...', siputError);
            // 🌐 Fallback ke API kedua (fastrestapis)
            const fastUrl = `https://fastrestapis.fasturl.cloud/maker/ktp?provinsi=${encodeURIComponent(provinsi)}&kota=${encodeURIComponent(kota)}&nik=${encodeURIComponent(nik)}&nama=${encodeURIComponent(nama)}&ttl=${encodeURIComponent(ttl)}&jenisKelamin=${encodeURIComponent(jenis_kelamin)}&golonganDarah=${encodeURIComponent(golongan_darah)}&alamat=${encodeURIComponent(alamat)}&rtRw=${encodeURIComponent(rtrw)}&kelDesa=${encodeURIComponent(keldesa)}&kecamatan=${encodeURIComponent(kecamatan)}&agama=${encodeURIComponent(agama)}&status=${encodeURIComponent(status)}&pekerjaan=${encodeURIComponent(pekerjaan)}&kewarganegaraan=${encodeURIComponent(kewarganegaraan)}&masaBerlaku=${encodeURIComponent(masa_berlaku)}&terbuat=${encodeURIComponent(terbuat)}&pasPhoto=${encodeURIComponent(directLink)}`;
            response = await axios.get(fastUrl, { responseType: 'arraybuffer' });
        }

        // 🎉 Kirim gambar eKTP ke chat
        await conn.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: '🎉 KTP kece jadi bro! Jangan dipake buat pinjol ya, hahaha! 😎🔥'
        }, { quoted: m });

        // ✨ Efek sukses
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        // 😵 Tangani error biar ga bikin panik
        console.error('💥 Oops, Ada Masalah:', e);
        await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        m.reply('😓 Yah, gagal bikin KTP nih. Cek lagi datanya, bro! 🙏 Pastiin formatnya bener dan gambarnya sesuai ya! 😅');
    }
};

handler.help = ['ktp atau fakektp'];
handler.tags = ['maker'];
handler.command = /^ktp|ektp|fakektp$/i;
handler.limit = true;

module.exports = handler;