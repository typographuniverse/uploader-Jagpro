const fetch = require("node-fetch")

let handler = async (m, { conn, usedPrefix, command, text }) => {    
let prompt = 'hallo perkenalkan nama saya Baby Logic AI';
if (!text) return m.reply(`teks nya mana?`)
   let response = await fetch(`https://restapii.rioooxdzz.web.id/api/gptlogic?message=${text}&prompt=${prompt}`);
    let gpt = await response.json();
    await m.reply(gpt.data.response);
}
handler.command = handler.help = ["babylogic"]
handler.tags = ["ai"]

module.exports = handler;