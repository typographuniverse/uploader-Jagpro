const fetch = require('node-fetch');

const ERROR_MESSAGE = 'Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti.';
const NOT_FOUND_MESSAGE = 'Grup tidak ditemukan.';
const EXAMPLE_USAGE = (command) => `Contoh: .${command} Jagpro`;

let handler = async (m, { text, conn, command }) => {
  if (!text) return conn.reply(m.chat, EXAMPLE_USAGE(command), m);

  try {
    // Menggunakan global.ptereodactyl dari settings.js
    const API_URL = `${global.ptereodactyl}api/wasearch`;
    const res = await fetch(`${API_URL}?query=${encodeURIComponent(text)}`);

    if (!res.ok) {
      throw new Error(`Gagal mengambil data: ${res.status} ${res.statusText}`);
    }

    const json = await res.json();

    if (!json.data?.result || json.data.result.length === 0) {
      return conn.reply(m.chat, NOT_FOUND_MESSAGE, m);
    }

    const hasil = json.data.result
      .map((grup, index) => `${index + 1}. *${grup.title}*\nLink: ${grup.link}`)
      .join('\n\n');

    conn.reply(m.chat, `Hasil Pencarian:\n\n${hasil}`, m);
  } catch (e) {
    console.error('Error in wasearch handler:', e);
    conn.reply(m.chat, ERROR_MESSAGE, m);
  }
};

handler.help = ['wasearch <kata kunci>'];
handler.tags = ['tools'];
handler.command = /^wasearch$/i;
handler.limit = true;

module.exports = handler;