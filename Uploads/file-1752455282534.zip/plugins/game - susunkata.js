let fetch = require('node-fetch')

let timeout = 100000
let poin = 10000

let handler = async (m, { conn, usedPrefix }) => {
    conn.susun = conn.susun ? conn.susun : {}
    let id = m.chat

    if (id in conn.susun) {
        conn.reply(m.chat, '⛔ Masih ada soal yang belum terjawab di chat ini', conn.susun[id].message)
        return
    }

    // Ambil data dari API
    let src = await (await fetch(`https://api.botcahx.eu.org/api/game/susunkata?apikey=${btc}`)).json()
    let json = src[Math.floor(Math.random() * src.length)]

    // Buat caption untuk ditampilkan di WhatsApp
    let caption = `  
🎮 *Tantangan Susun Kata!* 🎮  

❓ *Soal:*  
👉 ${json.soal}  

🔠 *Tipe:* ${json.tipe}  
⏳ *Timeout:* ${(timeout / 1000).toFixed(2)} detik  
💡 *Bantuan:* Ketik *${usedPrefix}susn* untuk petunjuk  
🎁 *Bonus:* +${poin} money 🤑  

*Kirim jawaban langsung tanpa perlu reply pesan ini!*\n
🔥 Ayo buktikan seberapa cepat kamu bisa menjawab!  
`
.trim()

    conn.susun[id] = {
        message: await conn.reply(m.chat, caption, m),
        jawaban: json.jawaban.toLowerCase(),
        poin,
        timeout: setTimeout(() => {
            if (conn.susun[id]) {
                conn.reply(m.chat, `⏱️ Waktu habis!\nJawabannya adalah *${json.jawaban}*`, conn.susun[id].message)
                delete conn.susun[id]
            }
        }, timeout)
    }
}

// Event sebelum pesan diproses (untuk menangkap jawaban user tanpa reply)
handler.before = async (m, { conn }) => {
    conn.susun = conn.susun ? conn.susun : {}
    let id = m.chat

    if (!m.text || m.fromMe || !(id in conn.susun)) return // Hindari balasan bot sendiri

    let jawabanBenar = conn.susun[id].jawaban
    let jawabanUser = m.text.trim().toLowerCase()

    if (jawabanUser === jawabanBenar) {
        conn.reply(m.chat, `🎉 Selamat! Jawaban *${jawabanUser}* benar! Kamu mendapatkan *${conn.susun[id].poin} money*`, m)
        clearTimeout(conn.susun[id].timeout) // Hentikan timer
        delete conn.susun[id] // Hapus sesi game
    } else {
        conn.reply(m.chat, `❌ Jawaban salah! Coba lagi!`, m)
    }
}

handler.help = ['susunkata']
handler.tags = ['game']
handler.command = /^susunkata/i
handler.register = false
handler.group = false

module.exports = handler
