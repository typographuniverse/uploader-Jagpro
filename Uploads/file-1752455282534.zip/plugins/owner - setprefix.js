let handler = async (m, { conn, text, command, usedPrefix }) => {
    const setting = global.db.data.settings[conn.user.jid];

    if (command === 'setprefix') {
        if (!text) {
            return m.reply(`📌 Masukkan prefix baru!\nContoh: *${usedPrefix}setprefix !* atau *${usedPrefix}setprefix ""* untuk tanpa prefix`);
        }

        let newPrefix = text.trim();
        if (["''", '""', "``"].includes(newPrefix)) {
            newPrefix = '';
        }

        setting.prefix = newPrefix;
        setting.noprefix = newPrefix === '';

        await global.db.write();
        return m.reply(`✅ *Sukses!* Prefix bot telah diganti menjadi *${newPrefix || 'TANPA PREFIX'}* 🎉`);
    }

    if (command === 'noprefix') {
        if (!text || !['on', 'off'].includes(text.toLowerCase())) {
            return m.reply(`📌 Gunakan dengan benar:\n> *${usedPrefix}noprefix on* untuk mengaktifkan\n> *${usedPrefix}noprefix off* untuk menonaktifkan`);
        }

        const enable = text.toLowerCase() === 'on';
        setting.noprefix = enable;
        if (enable) setting.prefix = ''; // kosongkan prefix agar cocok

        await global.db.write();
        return m.reply(`✅ *Mode No-Prefix* telah *${enable ? 'AKTIF' : 'NONAKTIF'}*.\nKamu ${enable ? 'bisa langsung ketik perintah tanpa prefix!' : 'harus gunakan prefix seperti .menu'}`);
    }
};

handler.help = ['setprefix <prefix>', 'noprefix <on/off>'];
handler.tags = ['owner'];
handler.command = /^setprefix$|^noprefix$/i;
handler.owner = true;

module.exports = handler;
