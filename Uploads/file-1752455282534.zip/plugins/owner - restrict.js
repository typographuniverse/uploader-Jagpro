const handler = async (context, { conn, text, usedPrefix, command }) => {
  const featureNames = Object.keys(features);
  const featureList = featureNames.map((feature, index) => `│  ◦ *${index + 1}* ${feature}`).join("\n");

  const exampleUsage = `*• Example:* ${usedPrefix}${command} 1 *[on/off]*\n\n┌  ◦ *LIST FEATURES JAGPRO*\n${featureList}\n└——`;

  const [featureIndex, toggleState] = (text || "").split(" ");
  if (!featureIndex || !toggleState) throw exampleUsage;

  const index = parseInt(featureIndex);
  if (isNaN(index) || index < 1 || index > featureNames.length) throw exampleUsage;

  const stateMap = { on: true, off: false };
  const newState = stateMap[toggleState];
  if (newState === undefined) throw exampleUsage;

  context.reply("Processing, please wait...");
  features[featureNames[index - 1]].restrict = newState;
  context.reply(`[ ✓ ] Successfully set *${toggleState}* for feature *${featureNames[index - 1]}*`);
};

handler.help = ["restrict"].map(cmd => `${cmd} *[feature index on/off]*`);
handler.tags = ["owner"];
handler.command = ["restrict"];
handler.rowner = true;

module.exports = handler;