const handler = async (m, { conn }) => {
    // Access the stats from global.db.data.stats
    const stats = global.db.data.stats || {};
    
    // Filter out commands with zero or undefined total usage
    const commandStats = Object.entries(stats)
        .filter(([_, stat]) => stat.total && stat.total > 0)
        .map(([command, stat]) => ({
            command: command.replace('.js', ''), // Remove .js extension
            total: stat.total || 0,
            success: stat.success || 0
        }))
        .sort((a, b) => b.total - a.total) // Sort by total usage in descending order
        .slice(0, 10); // Get top 10 commands

    // If no commands are found
    if (commandStats.length === 0) {
        return m.reply('Belum ada perintah yang digunakan.');
    }

    // Format the response
    let response = '📊 *Top 10 Command / Perintah Paling Sering Digunakan*\n\n';
    commandStats.forEach((cmd, index) => {
        response += `${index + 1}. *${cmd.command}*\n`;
        response += `   Total : ${cmd.total} kali\n\n`;
    });

    // Send the response
    await conn.reply(m.chat, response, m);
};

handler.help = ['topcmd'];
handler.tags = ['main'];
handler.command = /^topcmd$/i;


module.exports = handler;