let handler = async (m, { conn }) => {
  const groupJid = '120363410642348063@g.us' // Ganti dengan JID grup tujuan
  const displayName = '@GrupRahasia' // Teks yang bisa diklik

  await conn.sendMessage(m.chat, {
    text: displayName,
    contextInfo: {
      mentionedJid: [groupJid]
    }
  }, { quoted: m })
}

handler.help = ['grupmention']
handler.tags = ['tools']
handler.command = /^grupmention$/i
handler.owner = true

module.exports = handler
