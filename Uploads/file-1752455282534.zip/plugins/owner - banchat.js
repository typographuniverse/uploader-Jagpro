let ms = require('ms');

let handler = async (m, { conn, text, args, isOwner, isROwner, usedPrefix, command }) => {
    if (!m.isGroup) throw '❌ Perintah ini hanya bisa digunakan di grup!';
    if (!(isOwner || isROwner)) throw '😡 Hanya owner yang bisa membanned chat!';

    let duration = args[0] ? ms(args[0]) : -1;
    if (args[0] && isNaN(duration)) throw `❌ Format durasi tidak valid!\n\n📝 Contoh penggunaan :\n\n— ${usedPrefix + command} 10d\n— ${usedPrefix + command} 5h\n\n> tanpa durasi = permanent`;

    let chat = global.db.data.chats[m.chat];
    chat.isBanned = true;

    if (duration > 0) {
        chat.bannedUntil = Date.now() + duration;
        m.reply(`✅ Berhasil banchat!!\n\n⏳ durasi : *${ms(duration, { long: true })}*\n\n> selama masa ban, hanya owner yang bisa menggunakan bot.`);
    } else {
        chat.bannedUntil = null;
        m.reply(`✅ Berhasil banchat!!\n\n⏳ durasi : *permanent*\n\n> hanya owner yang bisa menggunakan bot.`);
    }
};

handler.help = ['banchat'];
handler.tags = ['owner'];
handler.command = /^banchat$/i;
handler.group = true;
handler.rowner = true;

module.exports = handler;