// 📝 plugin owner - setsewa

const fs = require('fs');
const path = require('path');
const sewaPath = path.join(__dirname, '../lib/sewa.json');
let sewa = fs.existsSync(sewaPath) ? JSON.parse(fs.readFileSync(sewaPath)) : {};

function saveSewa() {
  fs.writeFileSync(sewaPath, JSON.stringify(sewa, null, 2));
}

const linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;

// Auto remove grup expired
setInterval(async () => {
  const now = Date.now();
  for (let id in sewa) {
    if (sewa[id].expired && now >= sewa[id].expired) {
      try {
        await conn.sendMessage(id, { text: '⏰ Waktu sewa bot telah habis!\nBot otomatis keluar dari grup.' });
        await conn.groupLeave(id);
      } catch (e) {
        console.log(`[AUTO-LEAVE] Error keluar grup ${id}:`, e);
      }
      delete sewa[id];
      saveSewa();
    }
  }
}, 10000);

let handler = async (m, { conn, command, args, groupMetadata }) => {
  const id = m.chat;
  const now = Date.now();

  switch (command) {
    case 'setsewa': {
  if (!args[0]) return m.reply('❌ Format salah!\nContoh:\n.setsewa 30d\n.setsewa <linkgrup> 30d');

  let targetID = m.chat;
  let durasiArg = args[0];
  let namaGrup = groupMetadata?.subject || 'Unknown';

  if (linkRegex.test(args[0])) {
    const code = args[0].match(linkRegex)[1];
    if (!args[1]) return m.reply('❌ Format durasi tidak ditemukan!\nContoh: .setsewa <linkgrup> 30d');
    durasiArg = args[1];

    try {
      const info = await conn.groupGetInviteInfo(code);
      targetID = info.id;

      // Cek apakah bot sudah di grup
      try {
        const meta = await conn.groupMetadata(targetID);
        namaGrup = meta.subject;
      } catch {
        // Jika gagal akses metadata, bot belum join
        try {
          const res = await conn.groupAcceptInvite(code);
          const meta = await conn.groupMetadata(res);
          targetID = res;
          namaGrup = meta.subject;
        } catch {
          return m.reply('❌ Gagal join ke grup dari link yang diberikan.');
        }
      }
    } catch {
      return m.reply('❌ Link grup tidak valid atau sudah kadaluarsa.');
    }
  }

  const ms = parseDuration(durasiArg);
  if (!ms) return m.reply('❌ Format durasi salah!\nGunakan: 30d, 12h, 45m, 30s');

  const expired = now + ms;
  sewa[targetID] = {
    name: namaGrup,
    expired
  };
  saveSewa();

  m.reply(`✅ Sewa berhasil diatur\n> 👥 Grup: *${namaGrup}*\n> ⏰ Durasi: *${durasiArg}*`);
  break;
}


    case 'sewacek': {
      let targetID = id;
      if (args[0] && linkRegex.test(args[0])) {
        const code = args[0].match(linkRegex)[1];
        try {
          const gid = await conn.groupGetInviteInfo(code);
          targetID = gid.id;
        } catch {
          return m.reply('❌ Link group tidak valid atau bot belum join.');
        }
      }
      if (!sewa[targetID]) return m.reply('❌ Group ini tidak terdaftar dalam sewa bot!');
      const sisa = sewa[targetID].expired - now;
      if (sisa <= 0) return m.reply('⏰ Masa sewa sudah habis!');
      m.reply(`⏱️ Sisa waktu sewa bot:\n*${formatDuration(sisa)}*`);
      break;
    }

    case 'sewalist': {
      if (Object.keys(sewa).length === 0) return m.reply('❌ Tidak ada group dalam list sewa.');
      let teks = `📋 *LIST SEWA BOT*\n\n`;
      let i = 1;
      for (let gid of Object.keys(sewa)) {
        const sisa = sewa[gid].expired - now;
        if (sisa <= 0) continue;
        teks += `${i++}. ${sewa[gid].name}\n   (${gid})\n   ⏱️ ${formatDuration(sisa)}\n\n`;
      }
      m.reply(teks.trim());
      break;
    }

    case 'delsewa': {
      let targetID;
      if (args[0] && linkRegex.test(args[0])) {
        const code = args[0].match(linkRegex)[1];
        try {
          const info = await conn.groupGetInviteInfo(code);
          targetID = info.id;
        } catch {
          return m.reply('❌ Link group tidak valid atau bot belum join.');
        }
      } else if (!isNaN(args[0])) {
        const list = Object.keys(sewa);
        const index = parseInt(args[0]) - 1;
        if (!list[index]) return m.reply('❌ Nomor tidak ditemukan.\nGunakan .sewalist dulu');
        targetID = list[index];
      } else {
        return m.reply('❌ Format salah!\nGunakan: .delsewa <nomor> atau .delsewa <link>');
      }

      const removed = sewa[targetID];
      if (!removed) return m.reply('❌ Group tidak ditemukan dalam list sewa.');

      try {
        await conn.sendMessage(targetID, { text: '❌ Masa sewa telah dihapus oleh owner.\nBot akan keluar dari grup.' });
        await conn.groupLeave(targetID);
      } catch (e) {
        console.log(`[DELSEWA] Gagal keluar dari grup ${targetID}:`, e);
      }

      delete sewa[targetID];
      saveSewa();
      m.reply(`✅ Group *${removed.name}* berhasil dihapus dari daftar sewa dan bot telah keluar.`);
      break;
    }

    case 'join': {
      let [link, durasi] = args;
      if (!link || !durasi) return m.reply('❌ Format salah!\nContoh: .join <link> <durasi>\n\n.join https://chat.whatsapp.com/abc123 30d');
      let [_, code] = link.match(linkRegex) || [];
      if (!code) return m.reply('❌ Link tidak valid!');
      try {
        let res = await conn.groupAcceptInvite(code);
        let metadata = await conn.groupMetadata(res);
        const ms = parseDuration(durasi);
        if (!ms) return m.reply('❌ Format durasi salah!');
        const expired = now + ms;
        sewa[metadata.id] = {
          name: metadata.subject,
          expired
        };
        saveSewa();
        m.reply(`✅ Bot berhasil masuk ke grup *${metadata.subject}*\n⏰ Waktu sewa: *${durasi}*\n🕐 Sisa: *${formatDuration(ms)}*`);
      } catch (e) {
        m.reply('❌ Gagal join grup. Pastikan link valid dan bot belum masuk.');
      }
      break;
    }
  }
};

handler.help = ['setsewa <durasi>', 'sewacek [link]', 'sewalist', 'delsewa <no/link>', 'join <link> <durasi>'];
handler.tags = ['sewa'];
handler.command = /^(setsewa|sewacek|sewalist|delsewa|join)$/i;
handler.group = true;
handler.owner = true;

module.exports = handler;

// Helpers
function parseDuration(str) {
  let total = 0;
  const pattern = /(\d+)([dhms])/g;
  let match;
  while ((match = pattern.exec(str)) !== null) {
    const [_, num, unit] = match;
    switch (unit) {
      case 'd': total += parseInt(num) * 86400000; break;
      case 'h': total += parseInt(num) * 3600000; break;
      case 'm': total += parseInt(num) * 60000; break;
      case 's': total += parseInt(num) * 1000; break;
    }
  }
  return total || null;
}

function formatDuration(ms) {
  const d = Math.floor(ms / 86400000);
  const h = Math.floor((ms % 86400000) / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  return [
    d ? `${d} hari` : '',
    h ? `${h} jam` : '',
    m ? `${m} menit` : '',
    s ? `${s} detik` : ''
  ].filter(Boolean).join(', ');
}