const { setTimeout } = require('timers');

// Objek cache untuk menyimpan pesan sementara
const store = {};

// Interval reset cache (3 jam dalam milidetik)
const INTERVAL_RESET = 3 * 60 * 60 * 1000;

// Simpan pesan ke cache
function simpanPesanKeCache(pesan) {
    const dataPesan = {
        id: pesan.key.id,
        chat: pesan.key.remoteJid,
        pengirim: pesan.key.participant || pesan.key.remoteJid,
        dariSaya: pesan.key.fromMe,
        waktu: pesan.messageTimestamp
    };
    store[pesan.key.id] = dataPesan;
}

// Baca pesan dari cache
function bacaPesanDariCache(idPesan) {
    return store[idPesan] || null;
}

// Hapus pesan dari cache
function hapusPesanDariCache(idPesan) {
    delete store[idPesan];
}

// Bersihkan cache dan perbarui waktu reset
function bersihkanCache() {
    Object.keys(store).forEach(key => delete store[key]);
    store.waktuResetTerakhir = Date.now();
}

// Hitung waktu hingga reset berikutnya
function hitungWaktuHinggaResetBerikutnya() {
    const waktuResetTerakhir = store.waktuResetTerakhir || Date.now();
    const waktuSejakResetTerakhir = Date.now() - waktuResetTerakhir;
    return Math.max(0, INTERVAL_RESET - waktuSejakResetTerakhir);
}

// Jadwalkan pembersihan cache
function jadwalkanPembersihanCache() {
    const waktuHinggaResetBerikutnya = hitungWaktuHinggaResetBerikutnya();
    
    setTimeout(() => {
        bersihkanCache();
        jadwalkanPembersihanCache();
    }, waktuHinggaResetBerikutnya);
}

// Inisialisasi jadwal pembersihan saat bot mulai
jadwalkanPembersihanCache();

async function before(m, { conn, isAdmin, isBotAdmin }) {
    // Lewati hanya pesan Baileys yang bukan dari bot
    if (m.isBaileys && !m.fromMe) return;

    // Simpan semua pesan grup ke cache, termasuk dari bot
    if (m.isGroup) {
        simpanPesanKeCache(m);
    }

    // Tangani penghapusan berbasis reaksi
    if (m.mtype === 'reactionMessage' && m.isGroup) {
        const reaksi = m.msg;
        const emojiReaksi = reaksi.text; // Emoji yang digunakan dalam reaksi
        const idPesanTarget = reaksi.key.id; // ID pesan yang direaksikan

        // Lanjutkan hanya jika reaksi adalah ❌ atau 🗑️
        if (!['❌', '🗑️'].includes(emojiReaksi)) return;

        // Ambil pesan target dari cache
        const pesanTarget = bacaPesanDariCache(idPesanTarget);
        if (!pesanTarget) {
            await m.reply('🚩 Pesan tidak ditemukan di cache!');
            return;
        }

        // Ambil metadata grup untuk memeriksa status admin
        let metadataGrup = await conn.groupMetadata(m.chat);
        let nomorBot = conn.user.jid;
        let pesertaBot = metadataGrup.participants.find(peserta => peserta.id === nomorBot);
        let pesertaPengguna = metadataGrup.participants.find(peserta => peserta.id === m.sender);

        let cekAdmin = peserta => peserta?.admin === 'admin' || peserta?.admin === 'superadmin';

        let botAdalahAdmin = cekAdmin(pesertaBot);
        let penggunaAdalahAdmin = cekAdmin(pesertaPengguna);
        let adalahPemilik = global.owner?.some(([nomor]) => nomor === m.sender.split('@')[0]) || false;

        // Periksa apakah bot adalah admin
        if (!botAdalahAdmin) {
            await m.reply('🚩 Bot bukan admin!');
            return;
        }

        // Periksa apakah pengguna adalah admin atau pemilik
        if (!penggunaAdalahAdmin && !adalahPemilik) {
            await m.reply('🚩 Kamu bukan admin grup atau pemilik!');
            return;
        }

        // Hapus pesan target
        await conn.sendMessage(m.chat, {
            delete: {
                remoteJid: pesanTarget.chat,
                fromMe: pesanTarget.dariSaya,
                id: pesanTarget.id,
                participant: pesanTarget.pengirim
            }
        });

        // Hapus pesan dari cache
        hapusPesanDariCache(idPesanTarget);
    }

    return;
}

module.exports = { before };