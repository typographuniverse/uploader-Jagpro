// 📝 plugin group - afk

// 📝 plugin group - afk

let handler = async (m, { text, conn }) => {
  let chat = global.db.data.chats[m.chat] || {};
  chat.afk = chat.afk || {};
  chat.afk[m.sender] = {
    time: +new Date(),
    reason: text || '',
  };
  global.db.data.chats[m.chat] = chat;

  let ppUrl = global.thumb;
  try {
    ppUrl = await conn.profilePictureUrl(m.sender, 'image');
  } catch (e) {}

  let userName = conn.getName(m.sender) || 'Pengguna';
  await conn.sendMessage(m.chat, {
    text: `*‼️ Mohon jangan berisik karena ada seorang pengguna yang sedang AFK*.\n\n– Nama: ${userName}\n– Alasan: ${text || 'tidak ada'}`,
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: '⛔ PENGGUNA SEDANG AFK',
        body: '',
        thumbnailUrl: ppUrl,
        mediaType: 1,
        renderLargerThumbnail: false,
      },
    },
  }, { quoted: m });
};

handler.help = ['afk <alasan>'];
handler.tags = ['main'];
handler.command = /^afk$/i;
handler.group = true;

module.exports = handler;