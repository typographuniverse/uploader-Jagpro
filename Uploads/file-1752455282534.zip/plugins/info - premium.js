let handler = async (m, { conn }) => {
let capt = `
══════════════════════════❑
 • Premium 1 Hari : *Rp.2.000*
 • Premium 7 Hari : *Rp.5.000*
 • Premium 15 Hari : *Rp.8.000*
 • Premium 30 Hari : *Rp.12.000*
 
 [Benefit Premium]
- Unlimited Limit
- Akses Fitur Premium
- Menjadi Prioritas Owner
- Dapat Menggunakan Bot Di Pribadi

Silahkan Chat Owner Untuk Transaksi, Ketik .owner
══════════════════════════❏
`;

conn.sendMessage(m.chat, {
      text: capt,
      contextInfo: {
      externalAdReply: {
      showAdAttribution: true,
      title: `Premium ${namebot}`,
      body: author,
      thumbnailUrl: thumb,
      sourceUrl: sgc,
      mediaType: 1,
      renderLargerThumbnail: true
      }}}, { quoted: m })
}
handler.help = ['premium']
handler.tags = ['info']
handler.command = /^(prem|premium|buyprem|jadipremium)$/i

module.exports = handler