// 📝 plugin game - catur - move

// 📝 plugin game - caturmove (no prefix, hanya balasan gambar papan dari bot)

const { Chess } = require('chess.js');
const Jimp = require('jimp');

let handler = async (m, { conn }) => {
    conn.catur = conn.catur || {};
    const ct = conn.catur;

    if (!ct[m.chat]) return;

    const moveRegex = /^([a-h][1-8])\s+([a-h][1-8])$/i;
    const match = m.text.match(moveRegex);
    if (!match) return;

    const [_, from, to] = match;

    // Hanya lanjut jika pesan adalah reply ke gambar papan dari bot
    if (
        m.quoted?.mtype !== 'imageMessage' ||
        m.quoted?.sender !== conn.user.jid
    ) return;

    const game = ct[m.chat].chess;
    const player = ct[m.chat].players[m.sender];

    if (!player || game.turn() !== player.color[0]) {
        return m.reply(`⏳ Bukan giliranmu! Sekarang: ${game.turn() === 'w' ? 'Putih' : 'Hitam'}`);
    }

    try {
        const move = game.move({ from, to, promotion: 'q' });
        if (!move) return m.reply("❌ Langkah tidak valid!");

        let moveText = `📢 *Langkah Dilakukan!*\n${player.color === 'white' ? '⚪' : '⚫'} @${m.sender.split('@')[0]}: ${from} → ${to}`;

        if (move.captured) {
            moveText += `\n⚔️ Menangkap ${move.captured.toUpperCase()}!`;
            ct[m.chat].captures[player.color].push(move.captured);
        }

        if (game.isCheck()) moveText += `\n⚡ SKAK!`;

        await sendBoard(m, ct, conn);
        conn.sendMessage(m.chat, { text: moveText, mentions: [m.sender] });

        if (game.isGameOver()) {
            let endText = `🎯 *Permainan Selesai!*\n\n`;
            if (game.isCheckmate()) endText += `⭐ Skakmat! @${m.sender.split('@')[0]} Menang!\n`;
            if (game.isDraw()) endText += `🤝 Seri!\n`;

            delete ct[m.chat];
            return conn.sendMessage(m.chat, { text: endText, mentions: [m.sender] });
        }

        const nextPlayer = Object.keys(ct[m.chat].players).find(p => ct[m.chat].players[p].color[0] === game.turn());
        conn.sendMessage(m.chat, { text: `⏳ Giliran: @${nextPlayer.split('@')[0]}`, mentions: [nextPlayer] });

    } catch (e) {
        console.error("❌ ERROR move:", e);
        m.reply("❌ Gerakan tidak valid!");
    }
};

handler.customPrefix = /^[a-h][1-8]\s+[a-h][1-8]$/i; // contoh: e2 e4
handler.command = new RegExp(); // disable prefix .command biasa
handler.tags = ['game'];
handler.register = true;

module.exports = handler;

// 📤 Fungsi kirim ulang papan catur
async function sendBoard(m, ct, conn) {
    try {
        const fen = ct[m.chat].chess.fen().split(' ')[0];
        const boardUrl = `https://chessboardimage.com/${fen}.png?size=600&coordinates=true`;

        const img = await Jimp.read(boardUrl);
        const buffer = await img.getBufferAsync(Jimp.MIME_PNG);

        await conn.sendMessage(m.chat, {
            image: buffer,
            caption: `♟️ *Posisi Saat Ini*\n🔁 Balas gambar ini dengan langkahmu, contoh: e2 e4`,
            mentions: [conn.user.jid]
        });
    } catch (e) {
        console.error("Gagal ambil papan:", e);
        m.reply("❌ Gagal menampilkan papan!");
    }
}