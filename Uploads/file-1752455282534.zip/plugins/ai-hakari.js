const axios = require('axios');

let previousMessages = [];

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) 
    return conn.reply(m.chat, `• *Example :* .hakari Siapa presiden Indonesia?`, m);

  let name = conn.getName(m.sender);

  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  let prompt = "You are a friendly AI.";

  let messages = [
    ...previousMessages,
    {
      role: 'system',
      content: `Ubah gaya bicaramu agar lebih seperti seorang teman yang ramah. Gunakan bahasa yang sopan dan mudah dipahami. Kamu adalah asisten pintar yang bernama "Hakari". Jawab semua pertanyaan dengan lengkap dan jelas.`,
    },
    { role: 'user', content: text }
  ];

  try {
    let response = await axios.get(`https://api.siputzx.my.id/api/ai/llama33`, {
      params: {
        prompt: prompt,
        text: text
      }
    });

    let reply = response.data.data || "Maaf, saya tidak bisa menjawab itu sekarang.";

    let hasil = `*Hakari Desu!*\n\n${reply}`;
    await conn.sendMessage(m.chat, { text: hasil });

    previousMessages = messages;

    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
  } catch (error) {
    console.error("Error saat memanggil API Llama:", error);
    await conn.reply(m.chat, "Terjadi kesalahan saat memproses permintaanmu. Coba lagi nanti!", m);
  }
};

handler.help = ['hakari *<text>*'];
handler.command = /^hakari$/i;
handler.tags = ['ai'];
handler.premium = false;

module.exports = handler;