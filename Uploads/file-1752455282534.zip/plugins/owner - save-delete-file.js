// ✨ Plugin owner - save-delete-file ✨

let fs = require('fs');
let pathPlugins = './plugins/';

let sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

let handler = async (m, { text, usedPrefix, command, conn }) => {
  // Validasi input untuk kedua perintah
  if (!m.quoted && !text && command === 'sf') {
    throw `*Fitur Save Plugin*\n\n📌 Keterangan:\n- Balas file .js untuk menyimpan langsung\n- Balas teks dengan nama plugin untuk menyimpan teks\n\n📌 Penggunaan:\n- ${usedPrefix + command} (balas file .js)\n- ${usedPrefix + command} <nama_plugin> (balas teks)\n\n📝 Contoh:\n- ${usedPrefix + command} (balas file menu.js)\n- ${usedPrefix + command} menu (balas teks)`;
  }
  if (!text && command === 'df') {
    throw `*Fitur Delete Plugin*\n\n📌 Penggunaan:\n${usedPrefix + command} <nama_plugin>\n\n📝 Contoh:\n${usedPrefix + command} menu`;
  }

  if (command === 'sf') {
    // Kasus 1: Reply file .js
    if (m.quoted && m.quoted.mtype === 'documentMessage' && m.quoted.fileName.endsWith('.js')) {
      let fileName = m.quoted.fileName;
      let path = `${pathPlugins}${fileName}`;
      
      let loadingMsg = await conn.sendMessage(m.chat, { text: `⏳ Sedang menyimpan file...` });
      let msgKey = loadingMsg?.key;

      // Animasi loading
      for (let i = 0; i < 3; i++) {
        await sleep(1000);
        let loadingText = `⏳ Loading${'.'.repeat(i + 1)}`;
        await conn.relayMessage(m.chat, {
          protocolMessage: {
            key: msgKey,
            type: 14,
            editedMessage: { conversation: loadingText }
          }
        }, {});
      }

      try {
        // Download dan simpan file
        let buffer = await m.quoted.download();
        fs.writeFileSync(path, buffer);
        await conn.relayMessage(m.chat, {
          protocolMessage: {
            key: msgKey,
            type: 14,
            editedMessage: { conversation: `✅ Berhasil disimpan di 📂 *${path}*` }
          }
        }, {});
      } catch (error) {
        await conn.relayMessage(m.chat, {
          protocolMessage: {
            key: msgKey,
            type: 14,
            editedMessage: { conversation: `❌ Gagal menyimpan file! Error: ${error.message}` }
          }
        }, {});
      }
    }
    // Kasus 2: Reply teks
    else if (m.quoted?.text) {
      if (!text) throw `❗ Masukkan nama plugin untuk menyimpan teks!`;
      let path = `${pathPlugins}${text}.js`;
      
      let loadingMsg = await conn.sendMessage(m.chat, { text: `⏳ Sedang menyimpan file...` });
      let msgKey = loadingMsg?.key;

      // Animasi loading
      for (let i = 0; i < 3; i++) {
        await sleep(1000);
        let loadingText = `⏳ Loading${'.'.repeat(i + 1)}`;
        await conn.relayMessage(m.chat, {
          protocolMessage: {
            key: msgKey,
            type: 14,
            editedMessage: { conversation: loadingText }
          }
        }, {});
      }

      try {
        fs.writeFileSync(path, `// ✨ Plugin ${text} ✨\n\n` + m.quoted.text);
        await conn.relayMessage(m.chat, {
          protocolMessage: {
            key: msgKey,
            type: 14,
            editedMessage: { conversation: `✅ Berhasil disimpan di 📂 *${path}*` }
          }
        }, {});
      } catch (error) {
        await conn.relayMessage(m.chat, {
          protocolMessage: {
            key: msgKey,
            type: 14,
            editedMessage: { conversation: `❌ Gagal menyimpan file! Error: ${error.message}` }
          }
        }, {});
      }
    }
    else {
      throw `❗ Balas file .js atau teks yang ingin disimpan!`;
    }

  } else if (command === 'df') {
    let path = `${pathPlugins}${text}.js`;
    
    // Cek apakah file ada
    if (!fs.existsSync(path)) {
      let files = fs.readdirSync(pathPlugins).filter(file => file.endsWith('.js'));
      
      if (files.length === 0) {
        throw `⚠️ Tidak ada plugin yang tersedia di folder *plugins*!`;
      }

      throw `⚠️ File plugin *${text}.js* tidak ditemukan!\n\n📂 *Daftar plugin yang tersedia:*\n${files.map(f => `- ${f}`).join('\n')}`;
    }

    let loadingMsg = await conn.sendMessage(m.chat, { text: `⏳ Sedang menghapus file...` });
    let msgKey = loadingMsg?.key;

    // Animasi loading
    for (let i = 0; i < 3; i++) {
      await sleep(1000);
      let loadingText = `⏳ Loading${'.'.repeat(i + 1)}`;
      await conn.relayMessage(m.chat, {
        protocolMessage: {
          key: msgKey,
          type: 14,
          editedMessage: { conversation: loadingText }
        }
      }, {});
    }

    try {
      fs.unlinkSync(path);
      await conn.relayMessage(m.chat, {
        protocolMessage: {
          key: msgKey,
          type: 14,
          editedMessage: { conversation: `🗑️ File plugin *${text}.js* berhasil dihapus!` }
        }
      }, {});
    } catch (error) {
      await conn.relayMessage(m.chat, {
        protocolMessage: {
          key: msgKey,
          type: 14,
          editedMessage: { conversation: `❌ Gagal menghapus file! Error: ${error.message}` }
        }
      }, {});
    }
  }
};

handler.help = ['sf', 'df'].map(v => v + ' *[nama_plugin]*');
handler.tags = ['owner'];
handler.command = /^(sf|df)$/i;
handler.rowner = true;

module.exports = handler;