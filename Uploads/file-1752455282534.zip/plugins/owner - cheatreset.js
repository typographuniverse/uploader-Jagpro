/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]
        //global.db.data.users[m.sender].koin = 0
        global.db.data.users[m.sender].limit = 0
        global.db.data.users[m.sender].exp = 0
        global.db.data.users[m.sender].level = 0
        global.db.data.users[m.sender].money = 0
        m.reply(`Reset berhasil. Semua *EXP*, *LIMIT*, dan *MONEY* menjadi Nol`)
}
handler.command = /^(cheatreset)$/i
handler.owner = true
handler.premium = false
module.exports = handler