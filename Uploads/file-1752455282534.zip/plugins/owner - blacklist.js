// ✨ Plugin owner - blacklist ✨

// ✨ Plugin owner - blacklist ✨

const fs = require('fs')
const path = require('path')
const dirDB = path.join(__dirname, '../database')
const filePath = path.join(dirDB, 'blacklist.json')
const configPath = path.join(dirDB, 'blacklist-config.json')

if (!fs.existsSync(dirDB)) fs.mkdirSync(dirDB)
if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, '[]')
if (!fs.existsSync(configPath)) fs.writeFileSync(configPath, JSON.stringify({ denganKick: false }, null, 2))

function loadConfig() {
  return JSON.parse(fs.readFileSync(configPath))
}
function saveConfig(data) {
  fs.writeFileSync(configPath, JSON.stringify(data, null, 2))
}
function loadBlacklist() {
  return JSON.parse(fs.readFileSync(filePath))
}
function saveBlacklist(data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2))
}

let handler = async (m, { conn, args, usedPrefix, command, mentionedJid }) => {
  const sender = m.sender.replace(/\D/g, '')
  const ownerList = global.owner.map(o => Array.isArray(o) ? o[0] : o).map(x => x + '')

  if (!ownerList.includes(sender)) {
    return m.reply('❌ *Akses ditolak!*\nFitur ini hanya untuk *owner* saja.')
  }

  const act = (args[0] || '').toLowerCase()
  const input = args[1]

  // 🧾 Tampilkan daftar blacklist
  if (act === 'list') {
    const data = loadBlacklist()
    if (!data.length) return m.reply('📃 *Blacklist kosong.*')
    let list = data.map((n, i) => `*${i + 1}.* wa.me/${n}`).join('\n')
    return m.reply(`📛 *DAFTAR BLACKLIST*\n\n${list}`)
  }

  // 🔧 Konfigurasi auto-kick
  if (act === 'kick') {
    if (!['true', 'false'].includes(input?.toLowerCase())) {
      return m.reply(`⚠️ *Format salah!*\n\n*Contoh:*\n${usedPrefix + command} kick true\n${usedPrefix + command} kick false`)
    }
    const config = loadConfig()
    config.denganKick = input.toLowerCase() === 'true'
    saveConfig(config)
    return m.reply(`✅ Fitur Blacklist versi kick user telah diatur ke *${config.denganKick ? 'ON' : 'OFF'}*!`)
  }

  const isReply = m.quoted && m.quoted.sender
  const isMention = mentionedJid && mentionedJid.length > 0

  let targetNumber = null
  if (isReply) targetNumber = m.quoted.sender
  else if (isMention) targetNumber = mentionedJid[0]
  else if (input) targetNumber = input

  const nomor = targetNumber?.replace(/\D/g, '')

  if (!['add', 'und', 'remove'].includes(act) || !nomor) {
    return m.reply(`⚠️ *Format salah!*\n\n*Contoh:*\n${usedPrefix + command} add 628xxxx\n${usedPrefix + command} und 628xxxx\n${usedPrefix + command} kick true\n${usedPrefix + command} kick false\n${usedPrefix + command} list\n(bisa juga dengan tag atau reply untuk add/remove)`)
  }

  let data = loadBlacklist()
  if (act === 'add') {
    if (data.includes(nomor)) return m.reply(`⚠️ Nomor *${nomor}* sudah dalam blacklist.`)
    data.push(nomor)
    saveBlacklist(data)
    m.reply(`✅ Nomor *${nomor}* berhasil ditambahkan ke *blacklist*!`)
  } else {
    if (!data.includes(nomor)) return m.reply(`⚠️ Nomor *${nomor}* tidak ada dalam blacklist.`)
    data = data.filter(n => n !== nomor)
    saveBlacklist(data)
    m.reply(`✅ Nomor *${nomor}* berhasil dihapus dari *blacklist*!`)
  }
}

handler.command = /^blacklist|bl$/i
handler.help = ['blacklist'].map(v => `${v} [add|und|remove|list] <nomor/@user/reply>`).concat(['blacklist kick [true|false]'])
handler.tags = ['owner']
handler.owner = true

// ✂️ Auto delete + kick sebelum handler
handler.before = async function (m, { conn }) {
  if (!m.isGroup || m.fromMe || !m.message || !m.sender) return
  const bl = loadBlacklist()
  const config = loadConfig()
  const nomor = m.sender.replace(/\D/g, '')

  if (bl.includes(nomor)) {
    try {
      await conn.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.sender
        }
      })
      console.log(`🛑 Pesan dari ${nomor} dihapus (blacklist).`)

      if (config.denganKick) {
        const groupMetadata = await conn.groupMetadata(m.chat)
        const botId = conn.user.jid
        const isAdmin = groupMetadata.participants.find(p => p.id === botId)?.admin
        if (isAdmin) {
          try {
            await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            console.log(`🚪 User ${nomor} telah dikick dari grup (blacklist).`)
          } catch (e) {
            console.error('❌ Gagal kick user:', e)
          }
        } else {
          console.log('⚠️ Bot bukan admin, tidak bisa kick user.')
        }
      }
    } catch (e) {
      console.error('❌ Gagal hapus pesan:', e)
    }
  }
}

module.exports = handler