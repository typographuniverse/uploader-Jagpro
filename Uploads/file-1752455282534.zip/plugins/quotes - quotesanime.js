const fetch = require('node-fetch');

const handler = async (m, { conn, command, text }) => {
    if (!text) {
        return m.reply('*Masukkan kata kunci pencarian kutipan!* Contoh: .quotes <keyword>');
    }

    try {
        const response = await fetch(`https://api.siputzx.my.id/api/s/animequotes?query=${encodeURIComponent(text)}`);
        const json = await response.json();

        if (!json || !json.data || json.data.length === 0) {
            return m.reply('Tidak ditemukan kutipan.');
        }

        let result = `📖 *Hasil Pencarian Kutipan Anime*\n\n`;
        json.data.forEach((item, index) => {
            const anime = item.anime || 'Anime tidak diketahui';
            const quote = item.quotes || 'Tidak ada kutipan yang tersedia.';
            const character = item.karakter || 'Karakter tidak diketahui';
            const episode = item.episode || 'Episode tidak diketahui';
            const link = item.link || 'Link tidak tersedia';
            const gambar = item.gambar || '';

            result += `${index + 1}. *${anime}* (${episode})\n`;
            result += `   💬 ${quote}\n`;
            result += `   👤 Karakter: ${character}\n`;
            result += `   📎 [Lihat kutipan lengkap](${link})\n`;
            if (gambar) {
                result += `   🖼️ Gambar: ${gambar}\n`;
            }
            result += `\n`;
        });

        m.reply(result.trim());
    } catch (error) {
        console.error("Error Anime Quotes Search:", error);
        m.reply("Terjadi kesalahan saat mencari kutipan.");
    }
};

handler.help = ['quotesanime'];
handler.command = /^quotesanime$/i;
handler.tags = ['quotes','premium'];
handler.limit = true;
handler.premium = true;

module.exports = handler;