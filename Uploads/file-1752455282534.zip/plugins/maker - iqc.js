const { createCanvas, loadImage } = require('canvas');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let ppUrl = global.thumb;
  try { ppUrl = await conn.profilePictureUrl(m.sender, 'image'); } catch (e) {}

  // Fungsi untuk membuat contextInfo error
  const contextInfoError = (title, msg) => ({
    text: msg,
    contextInfo: {
      externalAdReply: {
        title,
        body: '',
        thumbnailUrl: ppUrl,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  });

  // ContextInfo untuk loading
  const contextInfoLoading = {
    contextInfo: {
      externalAdReply: {
        title: '⏳ MEMBUAT GAMBAR IQC',
        body: '',
        thumbnailUrl: ppUrl,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  };

  // Validasi input
  if (!text || !text.includes('|') || text.split('|').length !== 3) {
    return conn.sendMessage(m.chat, contextInfoError(
      '‼️ FORMAT INVALID',
      `*📝 CARA PENGGUNAAN :*\n– .iqc <text>|<posisi>|<jam>\n\n*📝 CONTOH PENGGUNAAN :*\n– .iqc aku punya anjing kecil kuberi nama darma|kanan|10.37`
    ), { quoted: m });
  }

  let [msg, posisi, jam] = text.split('|').map(v => v.trim().toLowerCase());
  if (!msg || !posisi || !jam) {
    return conn.sendMessage(m.chat, contextInfoError(
      '‼️ INPUT TIDAK LENGKAP',
      'Semua bagian (teks, posisi, jam) harus diisi dengan benar.'
    ), { quoted: m });
  }

  // Memecah teks menjadi dua baris jika panjang
  let kata = msg.split(' ');
  if (kata.length >= 6) {
    let splitIndex = Math.ceil(kata.length / 2);
    let baris1 = kata.slice(0, splitIndex).join(' ');
    let baris2 = kata.slice(splitIndex).join(' ');
    msg = baris1 + '\n' + baris2;
  }

  // Kirim pesan loading
  await conn.sendMessage(m.chat, {
    text: '⏳ *SEDANG DIPROSES*\n> sedang membuat gambar IQC tunggu sebentar...',
    ...contextInfoLoading
  }, { quoted: m });

  await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });

  try {
    const canvas = createCanvas(864, 1536);
    const ctx = canvas.getContext('2d');

    if (posisi === 'kanan') {
      // === BLOK PENGATURAN KANAN ===
      const bg = await loadImage('https://raw.githubusercontent.com/Zephyr-crack/scrapes/main/iqckanan.png');
      ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

      // 💬 Teks chat sisi kanan
      ctx.font = '28px sans-serif';
      ctx.fillStyle = '#fff';
      ctx.textBaseline = 'top';
      ctx.fillText(msg, 280, 535);

      // 🕒 Jam putih atas (jam sistem di atas layar chat kanan)
      ctx.font = 'bold 26px sans-serif';
      ctx.fillStyle = '#fff';
      ctx.fillText(jam, 380, 12);

      // ⏱️ Jam abu-abu dalam bubble chat (pojok kanan dalam chat bubble)
      ctx.font = '20px sans-serif';
      ctx.fillStyle = '#aaa';
      ctx.fillText(jam, 700, 593);

    } else if (posisi === 'kiri') {
      // Tentukan background berdasarkan panjang pesan
      let kiriBg = kata.length < 5
        ? 'https://raw.githubusercontent.com/Zephyr-crack/scrapes/main/iqckiri1.png'
        : 'https://raw.githubusercontent.com/Zephyr-crack/scrapes/main/iqckiri2.png';

      const bg = await loadImage(kiriBg);
      ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

      if (kata.length < 5) {
        // === BLOK PENGATURAN KIRI - Pendek (iqckiri1) ===
        // 💬 Teks chat sisi kiri
        ctx.font = '28px sans-serif';
        ctx.fillStyle = '#fff';
        ctx.textBaseline = 'top';
        ctx.fillText(msg, 62, 768);

        // 🕒 Jam putih atas (jam sistem di kanan atas layar)
        ctx.font = 'bold 26px sans-serif';
        ctx.fillStyle = '#fff';
        ctx.fillText(jam, 380, 10);

        // ⏱️ Jam abu-abu dalam bubble chat (pojok kiri bubble)
        ctx.font = '20px sans-serif';
        ctx.fillStyle = '#aaa';
        ctx.fillText(jam, 390, 787);

      } else {
        // === BLOK PENGATURAN KIRI - Panjang (iqckiri2) ===
        // 💬 Teks chat sisi kiri
        ctx.font = '28px sans-serif';
        ctx.fillStyle = '#fff';
        ctx.textBaseline = 'top';
        ctx.fillText(msg, 67, 470);

        // 🕒 Jam putih atas (jam sistem di kanan atas layar)
        ctx.font = 'bold 26px sans-serif';
        ctx.fillStyle = '#fff';
        ctx.fillText(jam, 385, 11);

        // ⏱️ Jam abu-abu dalam bubble chat (pojok kiri bawah dalam bubble)
        ctx.font = '20px sans-serif';
        ctx.fillStyle = '#aaa';
        ctx.fillText(jam, 587, 517);
      }

    } else {
      return conn.sendMessage(m.chat, contextInfoError(
        '‼️ POSISI TIDAK VALID',
        'Posisi harus "kanan" atau "kiri" ya sayang~'
      ), { quoted: m });
    }

    const buffer = canvas.toBuffer();
    await conn.sendFile(m.chat, buffer, 'iqc.jpg', '', m, false, {
      contextInfo: {
        externalAdReply: {
          title: '✅ Gambar IQC Berhasil Dibuat',
          body: '',
          thumbnailUrl: ppUrl,
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    });

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (err) {
    console.error(err);
    return conn.sendMessage(m.chat, contextInfoError(
      '❌ Gagal Membuat Gambar',
      'Terjadi kesalahan saat membuat gambar 😔'
    ), { quoted: m });
  }
};

handler.help = ['iqc <teks>|<posisi>|<jam>'];
handler.tags = ['tools', 'maker'];
handler.command = /^iqc$/i;
handler.limit = true;

module.exports = handler;