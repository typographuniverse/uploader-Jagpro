const axios = require("axios");

let handler = async (m, { text }) => {
  const pilihan = text.trim().toLowerCase();

  const convertMs = (ms) => {
    let seconds = Math.floor(ms / 1000);
    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    const minutes = Math.floor(seconds / 60);
    seconds %= 60;
    return `${hours} jam ${minutes} menit ${seconds} detik`;
  };

 const cekBotcah = async (lengkap = false) => {
  try {
    const api = global.apibtc || "https://api.botcahx.eu.org";
    const apikey = global.btc || "";

    if (!apikey) {
      return "❌ API key untuk BOTCAHX tidak ditemukan.";
    }

    const res = await axios.get(`${api}/api/checkkey?apikey=${apikey}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; BotcahxClient/1.0)',
        'Accept': 'application/json'
      }
    }).catch((error) => {
      // Capture detailed error information
      if (error.response) {
        console.error("BOTCAHX API Error:", {
          status: error.response.status,
          statusText: error.response.statusText,
          data: error.response.data
        });
        return {
          error: true,
          message: `❌ Error dari API BOTCAHX: ${error.response.status} ${error.response.statusText}`,
          details: error.response.data || "No additional details provided"
        };
      }
      throw error; // Rethrow if no response object
    });

    if (res.error) {
      return `${res.message}\nDetails: ${JSON.stringify(res.details)}`;
    }

    // Check if response data exists and has the expected structure
    if (!res.data || typeof res.data !== 'object') {
      return "❌ Respons API BOTCAHX tidak valid.";
    }

    // Handle case where API returns an error
    if (res.data.status !== 200) {
      return `❌ Error dari API BOTCAHX: ${res.data.message || 'Tidak ada pesan error'}`;
    }

    const r = res.data.result;

    // Validate required fields
    if (!r || !r.apikey || !r.username) {
      return "❌ Data BOTCAHX tidak lengkap atau tidak valid.";
    }

    let teks = `🧩 *BOTCAHX APIKEY*\n` +
               `🔑 Key: ${r.apikey}\n` +
               `🔑 Default Key: ${r.defaultapikey || 'Tidak tersedia'}\n` +
               `📧 Email: ${r.email || 'Tidak tersedia'}\n` +
               `👤 Username: ${r.username}\n` +
               `📊 Limit: ${r.limit}\n` +
               `💎 Premium: ${r.premium ? "Ya" : "Tidak"}\n` +
               `⏳ Expired: ${r.expired}\n` +
               `📅 Today Hit: ${r.todayHit}\n` +
               `📈 Total Hit: ${r.totalHit}`;

    if (lengkap && Array.isArray(r.dataIP)) {
      const ipData = r.dataIP.map((v, i) => 
        `${i + 1}. IP: ${v.ip}\n   - Count: ${v.count}\n   - Blacklist: ${v.blacklist ? "Ya" : "Tidak"}`
      ).join("\n\n");
      teks += `\n\n📌 *Data IP:*\n${ipData}`;
    }

    return teks;
  } catch (e) {
    console.error("Error in cekBotcah:", e.message);
    return `❌ Gagal ambil data BOTCAHX: ${e.message}`;
  }
};

  const cekXterm = async (lengkap = false) => {
    try {
      const key = global.apixtermkey || "";
      const url = `https://aihub.xtermai.xyz/api/tools/key-checker?key=${key}`;

      const res = await axios.get(url);
      const d = res.data?.data;

      let teks = `🧩 *XTERM APIKEY*\n` +
                 `📦 Plan: ${d.plan}\n` +
                 `🔑 Key: ${global.apixtermkey}\n` +
                 `📊 Limit: ${d.limit}\n` +
                 `📈 Total Hit: ${d.totalHit}\n` +
                 `🧠 Usage: ${d.usage}\n` +
                 `📉 Remaining: ${d.remaining}\n` +
                 `♻️ Reset: ${d.reset}\n` +
                 `⏳ Expired: ${d.expired}\n` +
                 `⏱️ Reset Every: ${convertMs(d.resetEvery.ms)}`;

      if (lengkap && d.features) {
        let fitur = Object.entries(d.features).map(([fitur, val], i) => {
          return `${i + 1}. Endpoint: ${fitur}\n   - Hit: ${val.hit}\n   - Use: ${val.use}\n   - Max: ${val.max}`;
        }).join("\n\n");
        teks += `\n\n⚙️ *Fitur Penggunaan:*\n${fitur}`;
      }

      return teks;
    } catch (e) {
      return "❌ Gagal ambil data XTERM.";
    }
  };

  if (!pilihan) {
    return m.reply(`*Cek API Key*\n\nKetik:\n1. *.cekapikey 1* - BOTCAHX (Lengkap)\n2. *.cekapikey 2* - XTERM (Lengkap)\n3. *.cekapikey all* - Ringkasan`);
  }

  let resultMsg = "";
  if (pilihan === "1") {
    resultMsg = await cekBotcah(true);
  } else if (pilihan === "2") {
    resultMsg = await cekXterm(true);
  } else if (pilihan === "all") {
    const [btc, xterm] = await Promise.all([cekBotcah(false), cekXterm(false)]);
    resultMsg = `${btc}\n\n${xterm}`;
  } else {
    return m.reply("❌ Pilihan tidak valid. Ketik *.cekapikey 1*, *.cekapikey 2*, atau *.cekapikey all*.");
  }

  m.reply(resultMsg);
};

handler.help = ['cekapikey'];
handler.tags = ['owner'];
handler.command = /^(cekapikey)$/i;
handler.rowner = true;

module.exports = handler;