const handler = async (m, { conn, command, text }) => {
    if (!text) {
        return m.reply('*Masukkan kata kunci pencarian resep!* Contoh: *.reseps search <keyword>*');
    }

    try {
        const response = await fetch(`https://api.siputzx.my.id/api/s/resep?query=${encodeURIComponent(text)}`);
        const json = await response.json();

        if (!json || !json.data || json.data.length === 0) {
            return m.reply('Tidak ditemukan resep.');
        }

        let result = `🍽️ *Hasil Pencarian Resep*\n\n`;
        json.data.forEach((item, index) => {
            result += `${index + 1}. *${item.title || 'Tidak ada judul'}*\n`;
            result += `   🥄 *Bahan:* ${item.bahan || 'Tidak ada bahan'}\n`;
            result += `   📝 *Langkah:* ${item.langkah_langkah || 'Tidak ada langkah'}\n`;
            result += `\n`;
        });

        m.reply(result.trim());
    } catch (error) {
        console.error("Error Recipe Search:", error);
        m.reply("Terjadi kesalahan saat mencari resep.");
    }
};

handler.command = /^resep$/i;
handler.tags = ['info'];
handler.limit = true;
module.exports = handler;