const { createHash } = require('crypto');

let handler = async function (m, { conn }) {
  let user = global.db.data.users[m.sender];
  let ownerNumber = global.nomorown.replace(/[^0-9]/g, '') + "@s.whatsapp.net"; // Format nomor owner

  if (!user) {
    return m.reply("❌ Kamu belum terdaftar! Gunakan perintah *register* untuk mendaftar.");
  }

  // Jika pengirim adalah owner, mereka bisa cek SN kapan saja tanpa batasan waktu
  let sn = createHash('md5').update(m.sender).digest('hex');

  if (m.sender === ownerNumber) {
    let buttonMessage = {
      text: `👑 *OWNER MODE* 👑\n\n🔍 *Serial Number kamu:* \n\n📌 *${sn}*`,
      footer: "Klik tombol di bawah untuk menyalin SN.",
      interactiveButtons: [
        {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "📋 Salin SN",
            id: sn,
            copy_code: sn
          })
        }
      ]
    };

    return await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
  }

  // Jika bukan owner, gunakan cooldown 24 jam
  let __waktutionskh = new Date() - user.snlast;
  let _waktutionskh = 86400000 - __waktutionskh;
  let waktutionskh = clockString(_waktutionskh);

  if (__waktutionskh > 86400000) {
    user.snlast = new Date() * 1;
    user.limit -= 5;

    let buttonMessage = {
      text: `🔍 *Serial Number kamu:* \n\n📌 *${sn}*`,
      footer: "Klik tombol di bawah untuk menyalin SN.",
      interactiveButtons: [
        {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "📋 Salin SN",
            id: sn,
            copy_code: sn
          })
        }
      ]
    };

    await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
  } else {
    m.reply(`⏳ Kamu harus menunggu *${waktutionskh}* sebelum bisa cek SN lagi.`);
  }
};

handler.help = ['ceksn'];
handler.tags = ['main'];
handler.command = /^ceksn$/i;
handler.register = true;

module.exports = handler;

function clockString(ms) {
  let h = Math.floor(ms / 3600000);
  let m = Math.floor(ms / 60000) % 60;
  let s = Math.floor(ms / 1000) % 60;
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}
