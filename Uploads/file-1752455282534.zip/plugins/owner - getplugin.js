// 📝 plugin owner - getplugin

// INI WM BANG :V

const fs = require('fs')
const path = require('path')

const tempStorage = {}

let handler = async (m, { conn, usedPrefix, command, text }) => {
  
    if (!text) return m.reply(`*‼️ Format tidak valid.*\n\n📝 Contoh penggunaan :\n\n– ${usedPrefix + command} <namaplugin>`)

    // Cek apakah input mengandung format pengiriman (text|file)
    const [option, filename] = text.split('|').map(str => str.trim())

    // Jika input tidak mengandung tanda '|', anggap hanya nama file (untuk menampilkan tombol)
    if (!filename) {
        const inputFilename = text.trim()
        if (!inputFilename) return m.reply(`*📝 Contoh penggunaan :*\n\n– ${usedPrefix + command} <nama>`)

        const filepath = path.join(__dirname, `./${inputFilename}${!/\.js$/i.test(inputFilename) ? '.js' : ''}`)
        const listPlugins = fs.readdirSync(__dirname).map(v => v.replace(/\.js/, ''))

        if (!fs.existsSync(filepath)) return m.reply(`_'${inputFilename}.js' tidak ditemukan!_\n\n📂 Berikut adalah plugin yang tersedia :\n\n${listPlugins.join('\n').trim()}`)

        // Simpan filename sementara berdasarkan chat ID
        tempStorage[m.chat] = inputFilename

        // Kirim pesan dengan dua tombol: Text dan File
        await conn.sendMessage(m.chat, {
            text: `‼️ *PILIH FORMAT PENGIRIMAN*\n\n> silahkan pilih format pengiriman untuk plugin berikut :\n\n📁 *${inputFilename}.js*\n`,
            footer: global.namebot || 'Bot',
            buttons: [
                {
                    buttonId: `${usedPrefix}${command} text|${inputFilename}`,
                    buttonText: { displayText: 'TEXT' },
                    type: 1
                },
                {
                    buttonId: `${usedPrefix}${command} file|${inputFilename}`,
                    buttonText: { displayText: 'FILE' },
                    type: 1
                }
            ],
            headerType: 1,
            viewOnce: true
        }, { quoted: m })
        return
    }

    // Jika input mengandung format pengiriman (text|file)
    if (!['text', 'file'].includes(option.toLowerCase())) {
        return m.reply(`*‼️ Format pengiriman tidak valid.*\n\nPilih salah satu: 'text' atau 'file'\n\n📝 Contoh: ${usedPrefix + command} text|${filename}`)
    }

    const filepath = path.join(__dirname, `./${filename}${!/\.js$/i.test(filename) ? '.js' : ''}`)
    const listPlugins = fs.readdirSync(__dirname).map(v => v.replace(/\.js/, ''))

    if (!fs.existsSync(filepath)) {
        delete tempStorage[m.chat] // Hapus dari penyimpanan sementara
        return m.reply(`_'${filename}.js' tidak ditemukan!_\n\n📂 Berikut adalah plugin yang tersedia :\n\n${listPlugins.join('\n').trim()}`)
    }

    // Jika pengguna memilih 'text', kirim isi file sebagai teks
    if (/^text$/i.test(option)) {
        const fileContent = fs.readFileSync(filepath, 'utf8')
        delete tempStorage[m.chat] // Hapus dari penyimpanan sementara setelah digunakan
        return m.reply(fileContent)
    }

    // Jika pengguna memilih 'file', kirim file sebagai dokumen
    if (/^file$/i.test(option)) {
        const fileContent = fs.readFileSync(filepath)
        delete tempStorage[m.chat] // Hapus dari penyimpanan sementara setelah digunakan
        return await conn.sendMessage(m.chat, {
            document: fileContent,
            mimetype: 'text/javascript',
            fileName: path.basename(filepath)
        }, { quoted: m })
    }
}

handler.help = ['getplugin'].map(v => v + ' <filename> atau <format>|<filename>')
handler.tags = ['owner']
handler.command = /^(getplugin|get ?plugin|gp)$/i
handler.rowner = true

module.exports = handler