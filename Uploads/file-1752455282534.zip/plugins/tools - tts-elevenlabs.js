const fetch = require('node-fetch'); // Pastikan node-fetch terinstal

// Konfigurasi API
const api = {
  xterm: {
    url: global.apixtermurl || "https://aihub.xtermai.xyz",
    key: global.apixtermkey || "YOUR_APIKEY" // Fallback jika global.apixtermkey tidak didefinisikan
  }
};

// Daftar suara statis
const voices = [
  { name: "bella", voice_id: "bella" },
  { name: "echilling", voice_id: "echilling" },
  { name: "adam", voice_id: "adam" },
  { name: "prabowo", voice_id: "prabowo" },
  { name: "thomasshelby", voice_id: "thomas_shelby" },
  { name: "michi", voice_id: "michi_jkt48" },
  { name: "jokowi", voice_id: "jokowi" },
  { name: "megawati", voice_id: "megawati" },
  { name: "nokotan", voice_id: "nokotan" },
  { name: "boboiboy", voice_id: "boboiboy" },
  { name: "yanzgpt", voice_id: "yanzgpt" },
  { name: "keqing", voice_id: "keqing" },
  { name: "yanami", voice_id: "yanami_anna" },
  { name: "celzoid", voice_id: "CelzoID" }
];

let handler = async (m, { conn, text }) => {
  try {
    // Ekstrak nama suara dari perintah
    const voiceMatch = m.text.match(/^\.(\w+)/i);
    if (!voiceMatch || !voiceMatch[1]) {
      return m.reply(`Format perintah salah. Contoh: .prabowo Halo dunia`);
    }
    const voiceIdentifier = voiceMatch[1].toLowerCase();

    // Cari suara
    const selectedVoice = voices.find(v => v.name.toLowerCase() === voiceIdentifier);
    if (!selectedVoice) {
      const availableVoiceNames = voices.map(v => v.name).join(", ");
      return m.reply(`Suara "${voiceIdentifier}" tidak ditemukan. Suara yang tersedia: ${availableVoiceNames}`);
    }
    const voiceId = selectedVoice.voice_id;

    // Validasi teks
    const inputText = text.trim();
    if (!inputText) {
      const voiceList = voices.map(v => v.name).join(", ");
      return m.reply(`❌ *Teks diperlukan*\n\n📝 Contoh: .${voiceIdentifier} Halo apa kabar?\n🔊 Suara yang tersedia:\n
1. bella
2. echilling
3. adam
4. prabowo
5. thomasshelby
6. michi
7. jokowi
8. megawati
9. nokotan
10. boboiboy
11. yanzgpt
12. keqing
13. yanami
14. celzoid 
        `);
    }

    // Periksa kunci API
    if (!api.xterm.key || api.xterm.key === "YOUR_APIKEY") {
      return m.reply("Kunci API belum dikonfigurasi. Hubungi admin untuk mengatur global.apixtermkey.");
    }

    // Periksa limit
    if (handler.limit && !m.sender.limit) {
      return m.reply("Maaf, kamu telah mencapai batas penggunaan. Coba lagi nanti!");
    }

    // React dengan emoji jam saat memulai proses
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    // Proses pembuatan suara
    const response = await fetch(`${api.xterm.url}/api/text2speech/elevenlabs?text=${encodeURIComponent(inputText)}&voice=${voiceId}&key=${api.xterm.key}`);
    
    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`Kesalahan API (${response.status}): ${response.statusText}. ${errorBody}`);
    }
    
    const audioBuffer = Buffer.from(await response.arrayBuffer());
    
    // Kirim audio
    await conn.sendMessage(m.chat, { audio: audioBuffer, mimetype: "audio/mpeg", ptt: true }, { quoted: m });
    
    // React dengan emoji centang saat selesai
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    
    // Kurangi limit jika sistem mendukung
    if (handler.limit) m.sender.limit = (m.sender.limit || 0) - 1;
  } catch (error) {
    // React dengan emoji silang saat gagal
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await m.reply(`Gagal menghasilkan suara: ${error.message}. Coba lagi atau hubungi admin.`);
  }
};

// Konfigurasi Handler
handler.help = voices.map(v => `${v.name} <teks>`);
handler.tags = ["sound"];
handler.command = /^(bella|echilling|adam|prabowo|thomasshelby|michi|jokowi|megawati|nokotan|boboiboy|yanzgpt|keqing|yanami|celzoid)$/i;
handler.limit = false;

module.exports = handler;