const fs = require('fs');
const path = require('path');
const schedule = require('node-schedule');
const { exec } = require('child_process');
const { promisify } = require('util');
const moment = require('moment-timezone');
const settings = require('../settings'); // Pastikan settings.js tersedia dan memiliki global.nomorown

const exec_ = promisify(exec);

// Konfigurasi waktu backup
const backupConfig = {
    WAKTU: {
        WIB: false,
        WITA: true, // Default waktu
        WIT: false
    },
    time: ['23:00', '09:45', '17:00'] // Format HH:MM
};

// Fungsi untuk mendapatkan zona waktu aktif
const getActiveTimezone = () => {
    if (backupConfig.WAKTU.WIB) return 'Asia/Jakarta';
    if (backupConfig.WAKTU.WIT) return 'Asia/Jayapura';
    return 'Asia/Makassar'; // Default WITA
};

// Fungsi untuk mendapatkan hari dan tanggal dengan zona waktu aktif
const getFormattedDate = () => {
    const timezone = getActiveTimezone();
    const now = moment().tz(timezone).locale('id');
    const dayName = now.format('dddd');
    const date = now.format('DD MMMM YYYY');
    return `${dayName}, ${date}`;
};

// Fungsi untuk mengonversi seluruh array waktu ke array cron format
const getCronSchedules = () => {
    return backupConfig.time.map((timeStr) => {
        const [hour, minute] = timeStr.split(':');
        return `${minute} ${hour} * * *`;
    });
};

// Fungsi untuk membuat dan mengirim backup
const createAndSendBackup = async (conn, recipient) => {
    try {
        const timezone = getActiveTimezone();
        const zipFileName = 'JagoanProject.zip';
        const tempZipPath = path.resolve(`./${zipFileName}`);

        // Membuat file zip, kecualikan folder tertentu
        let zipCommand = `zip -r ${zipFileName} * -x "node_modules/*" "session/*" "temp/*"`;
        await exec_(zipCommand);

        if (!fs.existsSync(tempZipPath)) {
            console.error('❌ Gagal membuat file backup!');
            return;
        }

        const fileBuffer = fs.readFileSync(tempZipPath);
        const currentTime = getFormattedDate();

        await conn.sendMessage(
            recipient,
            {
                document: fileBuffer,
                mimetype: 'application/zip',
                fileName: zipFileName,
                caption: `✅ Backup otomatis selesai! 🎉\n📅 Dibuat pada: ${currentTime}`,
            }
        );

        console.log(`✅ Backup berhasil dikirim ke: ${recipient}`);

        if (fs.existsSync(tempZipPath)) {
            fs.unlinkSync(tempZipPath);
            console.log(`🗑️ File ${zipFileName} berhasil dihapus`);
        } else {
            console.error(`❌ File ${zipFileName} tidak ditemukan untuk dihapus`);
        }
    } catch (err) {
        console.error('❌ Error saat membuat atau mengirim backup:', err);
    }
};

// Menjadwalkan pengiriman backup sesuai waktu
const scheduleSendBackup = (conn, groupJid, ownerJid) => {
    const cronTimes = getCronSchedules();
    const timezone = getActiveTimezone();

    cronTimes.forEach((cronTime) => {
        schedule.scheduleJob({ rule: cronTime, tz: timezone }, async () => {
            try {
                await createAndSendBackup(conn, groupJid);
                await createAndSendBackup(conn, ownerJid);
            } catch (err) {
                console.error('❌ Terjadi kesalahan saat mengirim backup:', err);
            }
        });
    });
};

// JID tujuan backup
const groupJid = '120363399419348848@g.us'; // Ganti sesuai grup kamu
const ownerJid = global.nomorown + '@s.whatsapp.net';

// Inisialisasi jadwal setelah koneksi siap
if (global.conn) {
    setTimeout(() => {
        scheduleSendBackup(global.conn, groupJid, ownerJid);
    }, 10000); // Tunggu 10 detik agar koneksi stabil
} else {
    console.error('❌ Koneksi ke WhatsApp belum ada!');
}

module.exports = {};
