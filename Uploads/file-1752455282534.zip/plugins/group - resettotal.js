let resetHandler = async (m, { conn, isAdmin, isBotAdmin, args }) => {
    if (!m.isGroup) throw '*Perintah ini hanya bisa digunakan di grup.*';
    if (!isAdmin) throw '*Hanya admin grup yang bisa mereset data total pesan.*';

    if (!db.data.chats[m.chat]?.total) {
        db.data.chats[m.chat].total = {};
    }

    if (args[0] === 'all') {
        // Reset semua pengguna
        db.data.chats[m.chat].total = {};
        await m.reply('*✅ Data total pesan untuk semua pengguna telah direset.*');
    } else if (args[0]) {
        // Reset data pesan untuk pengguna tertentu
        const target = args[0].replace(/@|[^\d]/g, '') + '@s.whatsapp.net';
        if (db.data.chats[m.chat].total[target]) {
            delete db.data.chats[m.chat].total[target];
            await m.reply(`*✅ Data total pesan untuk pengguna @${args[0]} telah direset.*`, null, {
                contextInfo: {
                    mentionedJid: [target]
                }
            });
        } else {
            await m.reply(`*❌ Tidak ada data pesan untuk pengguna @${args[0]}.*`, null, {
                contextInfo: {
                    mentionedJid: [target]
                }
            });
        }
    } else {
        throw '*Gunakan format:* `.resettotal @tag` atau `.resettotal all`';
    }
};

resetHandler.help = ['resettotal @tag', 'resettotal all'];
resetHandler.tags = ['group'];
resetHandler.command = /^(resettotal)$/i;
resetHandler.admin = true;
resetHandler.group = true;

module.exports = resetHandler;