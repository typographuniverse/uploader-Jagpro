const axios = require('axios');
const moment = require('moment-timezone');
const { otakudesu } = require('../lib/scraper.js');

let handler = async (m, { conn, usedPrefix, command, text }) => {
    try {
        if (!text) return m.reply(`Masukan Query Atau Link!\n\nContoh :\n${usedPrefix + command} Tonikaku Kawai\n${usedPrefix + command} https://otakudesu.lol/anime/tonikaku-ni-kawaii-sub-indo/`);

        conn.data = conn.data ? conn.data : {};
        let id = m.sender;

        let url = text.startsWith('http') ? text.replace(/http(s)?:\/\//i, '').split('/')[1] : text;

        if (/^anime/i.test(url)) {
            let result = await otakudesu.detail(text);
            let teks = `
Title : ${result.title.indonesia}
Produser : ${result.producer}
Status : ${result.status}
Total Eps : ${result.total_eps}
Durasi : ${result.duration}
Release : ${result.release}
Studio : ${result.studio}
Genre : ${result.genre}
${result.synopsis ? `Synopsis : \n${result.synopsis}` : ""}
`.trim();

            let responseText = `*${result.title.indonesia}* - Terdapat *${result.link_eps.length} Episode*\n\n${teks}\n\nSilakan pilih episode:\n`;

            result.link_eps.forEach((v, i) => {
                responseText += `${i + 1}. ${v.episode} \nUpload At ${v.upload_at}\n`;
            });

            // Simpan sesi pengguna
            conn.data[id] = { title: result.title.indonesia, episodes: result.link_eps };

            await conn.sendMessage(m.chat, { text: responseText }, { quoted: m });

        } else if (/^episode/i.test(url)) {
            let result = await otakudesu.download(text);

            let res720p = await originalUrl(result.link_mp4.find(v => v.type.trim() === "Mega" && /Mp4 720p/i.test(v.resolusi)).link);
            let res480p = await originalUrl(result.link_mp4.find(v => v.type.trim() === "Mega" && /Mp4 480p/i.test(v.resolusi)).link);
            let res360p = await originalUrl(result.link_mp4.find(v => v.type.trim() === "Mega" && /Mp4 360p/i.test(v.resolusi)).link);

            let responseText = `Terdapat *3 Resolusi*\n\nSilakan pilih resolusi:\n1. Download Resolusi 360p: ${res360p}\n2. Download Resolusi 480p: ${res480p}\n3. Download Resolusi 720p: ${res720p}`;
            await conn.sendMessage(m.chat, { text: responseText }, { quoted: m });

        } else {
            let result = await otakudesu.search(text);
            let responseText = `Terdapat *${result.length} Result*\n\nSilakan pilih:\n`;

            result.forEach((v, i) => {
                responseText += `${i + 1}. ${v.title.length > 50 ? `${v.title.slice(0, 50)}..` : v.title} \nGenre : ${v.genres} \nStatus : ${v.status}\n`;
            });

            await conn.sendMessage(m.chat, { text: responseText }, { quoted: m });
        }

        // Mengatur timeout untuk menghapus sesi pengguna setelah 30 detik
        setTimeout(() => {
            conn.sendMessage(m.chat, { react: { text: '⚙️', key: m.key } });
            delete conn.data[id];
        }, 30000);

    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan, silakan coba lagi.');
    }
};

handler.help = ['otakudesu *[name anime]*'];
handler.tags = ['internet'];
handler.command = /^(otakudesu|otaku)$/i;
handler.limit = true;

module.exports = handler;

async function originalUrl(url) {
    return (await axios(url)).request.res.responseUrl;
}
