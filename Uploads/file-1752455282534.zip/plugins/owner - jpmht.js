// 📝 plugin owner - jpmht

// ✨ Plugin owner - jmpht ✨

let handler = async (m, { conn, text, participants }) => {
    // Konfigurasi delay dalam detik (1, 2, atau 3 dst - hitungan detik)
    const delayjpm = 10; // Artinya 10 detik delay antar pengiriman

    // Filter grup yang valid
    let groups = Object.entries(conn.chats)
        .filter(([jid, chat]) => 
            jid.endsWith('@g.us') && 
            chat.isChats && 
            !chat.metadata?.read_only && 
            !chat.metadata?.announce)
        .map(v => v[0]);

    // Validasi jika bot tidak ada di grup
    if (groups.length === 0) {
        return conn.reply(m.chat, '🚫 *Oops!* Bot belum bergabung di grup mana pun nih! 😅', m);
    }

    // Split input untuk jumlah grup dan teks
    let [jumlah, teks] = text.split('|').map(item => item.trim());

    // Validasi input wajib jumlah dan teks
    if (!text || !jumlah || !teks) {
        return conn.reply(m.chat, 
            `✨ *Halo bro!* ✨\n` +
            `Formatnya salah nih, wajib masukin jumlah grup dan teks ya! 📩\n` +
            `📝 *Cara pakai:* .jmpht <jumlah>|<teks>\n` +
            `🌟 *Contoh:* .jmpht 3|Halo bro, apa kabar?\n` +
            `📊 *Maksimal grup:* ${groups.length}`, m);
    }

    // Konversi jumlah ke integer
    jumlah = parseInt(jumlah);

    // Validasi jumlah grup
    if (isNaN(jumlah) || jumlah <= 0) {
        return conn.reply(m.chat, 
            `⚠️ *Eits!* Jumlah grup harus angka positif dong! 😜\n` +
            `📊 *Maksimal grup:* ${groups.length}\n` +
            `📝 *Contoh:* .jmpht 3|Halo bro`, m);
    }

    if (jumlah > groups.length) {
        return conn.reply(m.chat, 
            `🚨 *Waduh!* Jumlah yang kamu minta (${jumlah}) kebanyakan bro! 😅\n` +
            `📊 *Maksimal grup:* ${groups.length}\n` +
            `📝 *Contoh:* .jmpht ${groups.length}|Halo bro`, m);
    }

    // Quote khusus untuk JPM
    const qlocJpm = {
        key: {
            participant: '0@s.whatsapp.net',
            ...(m.chat ? { remoteJid: `status@broadcast` } : {})
        },
        message: {
            locationMessage: {
                name: `📣 Broadcast`,
                jpegThumbnail: ""
            }
        }
    };

    try {
        // Acak grup dan ambil sesuai jumlah yang diminta
        let selectedGroups = groups.sort(() => 0.5 - Math.random()).slice(0, jumlah);
        
        // Kirim notifikasi proses
        await conn.reply(m.chat, 
            `🚀 *Siap bro!* Mengirim pesan JMPHT ke ${selectedGroups.length} grup acak... ⏳`, m);

        let successCount = 0;

        // Kirim pesan ke setiap grup yang dipilih
        for (let id of selectedGroups) {
            try {
                // Ambil daftar peserta grup untuk hidetag (menggunakan participants dari parameter)
                let member = participants.map(v => v.id) || [];
                
                await conn.sendMessage(id, {
                    text: `${teks}`,
                    mentions: member // Menambahkan hidetag untuk semua member
                }, {
                    quoted: qlocJpm
                });
                successCount++;
                await new Promise(resolve => setTimeout(resolve, delayjpm * 1000)); // Delay sesuai delayjpm (dalam detik)
            } catch (error) {
                console.log(`Gagal mengirim ke ${id}: ${error}`);
            }
        }

        // Kirim laporan selesai
        await conn.reply(m.chat, 
            `🎉 *Selesai bro!* 🎉\n` +
            `✅ Terkirim ke: ${successCount} dari ${selectedGroups.length} grup\n\n` +
            `> Jika ada yang tidak terkirim, pastikan bot memiliki akses mengirim pesan ke grup tersebut`, m);

    } catch (error) {
        console.error(error);
        await conn.reply(m.chat, 
            `😱 *Aduh!* Ada error nih bro saat kirim JMPHT! Coba lagi ya! 🙏`, m);
    }
};

handler.help = ['jmpht <jumlah>|<teks>'];
handler.tags = ['owner'];
handler.command = /^jmpht$/i;
handler.owner = true; // Hanya owner yang bisa akses
handler.rowner = false;

module.exports = handler;