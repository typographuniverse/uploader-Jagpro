let timeout = 60000
let poin = 1500

let handler = async (m, { conn, command }) => {
  conn.tebakkata = conn.tebakkata || {}

  if (command === 'tebakkata') {
    if (m.chat in conn.tebakkata) return m.reply('Masih ada soal belum terjawab di chat ini.')

    let res = soalTebakKata[Math.floor(Math.random() * soalTebakKata.length)]
    conn.reply(m.chat, `*TEBAK KATA*\n\n${res.soal}\n\n⏱️ Waktu: *${timeout / 1000} detik*\n\n> jawab tanpa perlu reply!\n*.clue* untuk petunjuk\n*.malas* untuk menyerah.`)

    conn.tebakkata[m.chat] = [
      null, res, poin,
      setTimeout(() => {
        if (conn.tebakkata[m.chat]) {
          conn.reply(m.chat, `⏰ Waktu habis!\nJawabannya: *${res.jawab}*`)
          delete conn.tebakkata[m.chat]
        }
      }, timeout),
      false, true
    ]
  }

  if (command === 'malas') {
    if (!(m.chat in conn.tebakkata)) return m.reply('❌ Tidak ada soal yang sedang berlangsung.')
    let [, res] = conn.tebakkata[m.chat]
    clearTimeout(conn.tebakkata[m.chat][3])
    conn.reply(m.chat, `Jawaban: *${res.jawab}*`)
    delete conn.tebakkata[m.chat]
  }

  if (command === 'clue') {
    if (!(m.chat in conn.tebakkata)) return m.reply('❌ Belum ada soal yang dimulai.')
    let [, res] = conn.tebakkata[m.chat]
    let clue = res.jawab.replace(/[^\s]/g, '_').split('').map((c, i) => (i % 2 === 0 ? res.jawab[i] : c)).join('')
    conn.reply(m.chat, `✨ *Clue*: ${clue}`)
  }
}

handler.before = async function (m, { conn }) {
  if (!m.text || m.sender === conn.user.jid) return

  conn.tebakkata = conn.tebakkata || {}
  let id = m.chat
  if (!(id in conn.tebakkata)) return

  let [, soal, poin, timeoutId, , soalDikirim] = conn.tebakkata[id]
  if (!soalDikirim) return

  let jawabanUser = m.text.toLowerCase().trim()
  let jawabanBenar = soal.jawab.toLowerCase().trim()
  if (jawabanUser.length < 3) return

  if (jawabanUser === jawabanBenar) {
    global.db.data.users[m.sender].money += poin
    conn.reply(m.chat, `✅ *${m.name} benar!*\n🎉 +${poin} Money`)
    clearTimeout(timeoutId)
    delete conn.tebakkata[id]
  } else {
    conn.reply(m.chat, `❌ Salah, coba lagi.`)
  }
}

handler.help = ['tebakkata']
handler.tags = ['game']
handler.command = /^tebakkata|clue|malas$/i

module.exports = handler

const soalTebakKata = [
  { soal: 'kaki empat, belajar, kayu', jawab: 'meja' },
  { soal: 'detak, cinta, darah', jawab: 'jantung' },
  { soal: 'langit, panas, siang', jawab: 'matahari' },
  { soal: 'tidur, mimpi, malam', jawab: 'bantal' },
  { soal: 'tidur, mimpi, malam', jawab: 'bantal' },
  { soal: 'roda empat, stir, jalanan', jawab: 'mobil' },
  { soal: 'layar, keyboard, teknologi', jawab: 'komputer' },
  { soal: 'alas, kaki, jalan', jawab: 'sepatu' },
  { soal: 'pakai, dingin, baju', jawab: 'jaket' },
  { soal: 'susu, nangis, lucu, popok', jawab: 'bayi' },
  { soal: 'air, sirip, berenang', jawab: 'ikan' },
  { soal: 'aspal, kendaraan, lampu merah', jawab: 'jalan' },
  { soal: 'keyboard, layar, teknologi', jawab: 'komputer' },
  { soal: 'bersih, sabun, air', jawab: 'mandi' },
  { soal: 'bersih, sikat, gigi', jawab: 'sikat gigi' },
  { soal: 'hijau, pahit, sayur', jawab: 'pare' },
  { soal: 'kendaraan, aspal, lampu merah', jawab: 'jalan' },
  { soal: 'tidur, malam, mimpi', jawab: 'bantal' },
  { soal: 'helm, roda, knalpot', jawab: 'motor' },
  { soal: 'kertas, baca, ilmu', jawab: 'buku' },
  { soal: 'bulat, merah, buah', jawab: 'apel' },
  { soal: 'dingin, angin, putar', jawab: 'kipas' },
  { soal: 'air, bersih, sabun', jawab: 'mandi' },
  { soal: 'terbang, sayap, kicau', jawab: 'burung' },
  { soal: 'belajar, kaki empat, kayu', jawab: 'meja' },
  { soal: 'dada, nafas, paru', jawab: 'paru-paru' },
  { soal: 'jalan, alas, kaki', jawab: 'sepatu' },
  { soal: 'bersih, gigi, sikat', jawab: 'sikat gigi' },
  { soal: 'basah, tutup, hujan', jawab: 'payung' },
  { soal: 'pahit, sayur, hijau', jawab: 'pare' },
  { soal: 'layar, teknologi, keyboard', jawab: 'komputer' },
  { soal: 'siang, panas, langit', jawab: 'matahari' },
  { soal: 'meja, belajar, kursi', jawab: 'sekolah' },
  { soal: 'kicau, terbang, sayap', jawab: 'burung' },
  { soal: 'tangan, tinta, tulis', jawab: 'pena' },
  { soal: 'jalanan, roda empat, stir', jawab: 'mobil' },
  { soal: 'baju, dingin, pakai', jawab: 'jaket' },
  { soal: 'teknologi, keyboard, layar', jawab: 'komputer' },
  { soal: 'sikat, gigi, bersih', jawab: 'sikat gigi' },
  { soal: 'kendaraan, aspal, lampu merah', jawab: 'jalan' },
  { soal: 'mimpi, malam, tidur', jawab: 'bantal' },
  { soal: 'pakai, baju, dingin', jawab: 'jaket' },
  { soal: 'lapangan, hijau, makanan kambing', jawab: 'rumput' },
  { soal: 'meja, kursi, belajar', jawab: 'sekolah' },
  { soal: 'layar, teknologi, keyboard', jawab: 'komputer' },
  { soal: 'tinta, tangan, tulis', jawab: 'pena' },
  { soal: 'hijau, lapangan, makanan kambing', jawab: 'rumput' },
  { soal: 'cinta, darah, detak', jawab: 'jantung' },
  { soal: 'lampu merah, aspal, kendaraan', jawab: 'jalan' },
  { soal: 'lampu merah, aspal, kendaraan', jawab: 'jalan' },
  { soal: 'roda empat, jalanan, stir', jawab: 'mobil' },
  { soal: 'kendaraan, lampu merah, aspal', jawab: 'jalan' },
  { soal: 'pintu, tembok, atap', jawab: 'rumah' },
  { soal: 'panas, langit, siang', jawab: 'matahari' },
  { soal: 'meja, belajar, kursi', jawab: 'sekolah' },
  { soal: 'helm, roda, knalpot', jawab: 'motor' },
  { soal: 'malam, jalanan, terang', jawab: 'lampu' },
  { soal: 'baca, kertas, ilmu', jawab: 'buku' },
  { soal: 'lapangan, makanan kambing, hijau', jawab: 'rumput' },
  { soal: 'tangan, tinta, tulis', jawab: 'pena' },
  { soal: 'alas, jalan, kaki', jawab: 'sepatu' },
  { soal: 'bersih, sabun, air', jawab: 'mandi' },
  { soal: 'buah, merah, bulat', jawab: 'apel' },
  { soal: 'belajar, meja, kursi', jawab: 'sekolah' },
  { soal: 'putar, angin, dingin', jawab: 'kipas' },
  { soal: 'pintu, atap, tembok', jawab: 'rumah' },
  { soal: 'merah, bulat, buah', jawab: 'apel' },
  { soal: 'tidur, malam, mimpi', jawab: 'bantal' },
  { soal: 'pakai, baju, dingin', jawab: 'jaket' },
  { soal: 'kicau, terbang, sayap', jawab: 'burung' },
  { soal: 'pahit, sayur, hijau', jawab: 'pare' },
  { soal: 'mimpi, tidur, malam', jawab: 'bantal' },
  { soal: 'tidur, malam, mimpi', jawab: 'bantal' },
  { soal: 'sirip, berenang, air', jawab: 'ikan' },
  { soal: 'belajar, kursi, meja', jawab: 'sekolah' },
  { soal: 'air, sabun, bersih', jawab: 'mandi' },
  { soal: 'roda dua, gowes, sadel', jawab: 'sepeda' },
  { soal: 'foto, gambar, jepret', jawab: 'kamera' },
  { soal: 'belajar, meja, kursi', jawab: 'sekolah' },
  { soal: 'atap, tembok, pintu', jawab: 'rumah' },
  { soal: 'atap, pintu, tembok', jawab: 'rumah' },
  { soal: 'jalanan, terang, malam', jawab: 'lampu' },
  { soal: 'peliharaan, meong, bulu', jawab: 'kucing' },
  { soal: 'buah, merah, bulat', jawab: 'apel' },
  { soal: 'gambar, foto, jepret', jawab: 'kamera' },
  { soal: 'darah, cinta, detak', jawab: 'jantung' },
  { soal: 'telinga, suara, musik', jawab: 'headset' },
  { soal: 'sabun, air, bersih', jawab: 'mandi' },
  { soal: 'panas, siang, langit', jawab: 'matahari' },
  { soal: 'terbang, kicau, sayap', jawab: 'burung' },
  { soal: 'sayur, hijau, pahit', jawab: 'pare' },
  { soal: 'musik, telinga, suara', jawab: 'headset' },
  { soal: 'kursi, belajar, meja', jawab: 'sekolah' },
  { soal: 'tidur, mimpi, malam', jawab: 'bantal' },
  { soal: 'jepret, gambar, foto', jawab: 'kamera' },
  { soal: 'baca, ilmu, kertas', jawab: 'buku' },
  { soal: 'helm, roda, knalpot', jawab: 'motor' },
  { soal: 'gambar, jepret, foto', jawab: 'kamera' },
  { soal: 'sikat, bersih, gigi', jawab: 'sikat gigi' },
  { soal: 'hijau, sayur, pahit', jawab: 'pare' },
  { soal: 'paru, dada, nafas', jawab: 'paru-paru' },
  { soal: 'roda empat, stir, jalanan', jawab: 'mobil' },
  { soal: 'popok, susu, nangis, lucu', jawab: 'bayi' },
  { soal: 'pintu, tembok, atap', jawab: 'rumah' },
  { soal: 'aspal, lampu merah, kendaraan', jawab: 'jalan' },
  { soal: 'roda dua, sadel, gowes', jawab: 'sepeda' },
  { soal: 'bersih, sabun, air', jawab: 'mandi' },
  { soal: 'berenang, sirip, air', jawab: 'ikan' },
  { soal: 'malam, mimpi, tidur', jawab: 'bantal' },
  { soal: 'pintu, atap, tembok', jawab: 'rumah' },
  { soal: 'dada, paru, nafas', jawab: 'paru-paru' },
  { soal: 'hijau, pahit, sayur', jawab: 'pare' },
  { soal: 'hujan, tutup, basah', jawab: 'payung' },
  { soal: 'lucu, nangis, susu, popok', jawab: 'bayi' },
  { soal: 'tulis, tangan, tinta', jawab: 'pena' },
  { soal: 'jepret, foto, gambar', jawab: 'kamera' },
  { soal: 'jepret, gambar, foto', jawab: 'kamera' },
  { soal: 'dada, nafas, paru', jawab: 'paru-paru' },
  { soal: 'tutup, basah, hujan', jawab: 'payung' },
  { soal: 'belajar, kaki empat, kayu', jawab: 'meja' },
  { soal: 'langit, siang, panas', jawab: 'matahari' },
  { soal: 'roda empat, jalanan, stir', jawab: 'mobil' },
  { soal: 'kaki, alas, jalan', jawab: 'sepatu' },
  { soal: 'hijau, makanan kambing, lapangan', jawab: 'rumput' },
  { soal: 'lampu merah, kendaraan, aspal', jawab: 'jalan' },
  { soal: 'mimpi, malam, tidur', jawab: 'bantal' },
  { soal: 'makanan kambing, lapangan, hijau', jawab: 'rumput' },
  { soal: 'dingin, angin, putar', jawab: 'kipas' },
  { soal: 'tidur, malam, mimpi', jawab: 'bantal' },
  { soal: 'sirip, berenang, air', jawab: 'ikan' },
  { soal: 'gambar, foto, jepret', jawab: 'kamera' },
  { soal: 'air, bersih, sabun', jawab: 'mandi' },
  { soal: 'stir, jalanan, roda empat', jawab: 'mobil' },
  { soal: 'kicau, sayap, terbang', jawab: 'burung' },
  { soal: 'putar, dingin, angin', jawab: 'kipas' },
  { soal: 'lampu merah, aspal, kendaraan', jawab: 'jalan' },
  { soal: 'air, bersih, sabun', jawab: 'mandi' },
  { soal: 'tidur, mimpi, malam', jawab: 'bantal' },
  { soal: 'kayu, belajar, kaki empat', jawab: 'meja' },
  { soal: 'sayur, pahit, hijau', jawab: 'pare' },
  { soal: 'teknologi, keyboard, layar', jawab: 'komputer' },
  { soal: 'teknologi, keyboard, layar', jawab: 'komputer' },
  { soal: 'baju, dingin, pakai', jawab: 'jaket' },
  { soal: 'lapangan, hijau, makanan kambing', jawab: 'rumput' },
  { soal: 'kicau, terbang, sayap', jawab: 'burung' },
  { soal: 'makanan kambing, lapangan, hijau', jawab: 'rumput' },
  { soal: 'peliharaan, meong, bulu', jawab: 'kucing' },
  { soal: 'bulat, buah, merah', jawab: 'apel' },
  { soal: 'sabun, air, bersih', jawab: 'mandi' },
  { soal: 'angin, dingin, putar', jawab: 'kipas' },
  { soal: 'popok, lucu, susu, nangis', jawab: 'bayi' },
  { soal: 'malam, tidur, mimpi', jawab: 'bantal' },
  { soal: 'jalanan, stir, roda empat', jawab: 'mobil' },
  { soal: 'kaki empat, belajar, kayu', jawab: 'meja' },
  { soal: 'bulu, meong, peliharaan', jawab: 'kucing' },
  { soal: 'jalan, kaki, alas', jawab: 'sepatu' },
  { soal: 'detak, cinta, darah', jawab: 'jantung' },
  { soal: 'helm, knalpot, roda', jawab: 'motor' },
  { soal: 'panas, langit, siang', jawab: 'matahari' },
  { soal: 'bulat, buah, merah', jawab: 'apel' },
  { soal: 'ilmu, kertas, baca', jawab: 'buku' },
  { soal: 'teknologi, layar, keyboard', jawab: 'komputer' },
  { soal: 'stir, roda empat, jalanan', jawab: 'mobil' },
  { soal: 'gigi, sikat, bersih', jawab: 'sikat gigi' },
  { soal: 'buah, bulat, merah', jawab: 'apel' },
  { soal: 'peliharaan, bulu, meong', jawab: 'kucing' },
  { soal: 'roda, helm, knalpot', jawab: 'motor' },
  { soal: 'knalpot, helm, roda', jawab: 'motor' },
  { soal: 'atap, pintu, tembok', jawab: 'rumah' },
  { soal: 'telinga, suara, musik', jawab: 'headset' },
  { soal: 'musik, telinga, suara', jawab: 'headset' },
  { soal: 'roda dua, gowes, sadel', jawab: 'sepeda' },
  { soal: 'meong, bulu, peliharaan', jawab: 'kucing' },
  { soal: 'dingin, putar, angin', jawab: 'kipas' },
  { soal: 'knalpot, roda, helm', jawab: 'motor' },
  { soal: 'sayur, pahit, hijau', jawab: 'pare' },
  { soal: 'malam, terang, jalanan', jawab: 'lampu' },
  { soal: 'tembok, atap, pintu', jawab: 'rumah' },
  { soal: 'foto, gambar, jepret', jawab: 'kamera' },
  { soal: 'detak, cinta, darah', jawab: 'jantung' },
  { soal: 'terbang, sayap, kicau', jawab: 'burung' },
  { soal: 'sayap, terbang, kicau', jawab: 'burung' },
  { soal: 'tangan, tulis, tinta', jawab: 'pena' },
  { soal: 'langit, siang, panas', jawab: 'matahari' },
  { soal: 'malam, jalanan, terang', jawab: 'lampu' },
  { soal: 'teknologi, layar, keyboard', jawab: 'komputer' },
  { soal: 'berenang, air, sirip', jawab: 'ikan' },
  { soal: 'air, sirip, berenang', jawab: 'ikan' },
  { soal: 'gowes, sadel, roda dua', jawab: 'sepeda' },
  { soal: 'jalanan, roda empat, stir', jawab: 'mobil' },
  { soal: 'stir, jalanan, roda empat', jawab: 'mobil' },
  { soal: 'malam, mimpi, tidur', jawab: 'bantal' },
  { soal: 'lapangan, makanan kambing, hijau', jawab: 'rumput' },
  { soal: 'pakai, dingin, baju', jawab: 'jaket' },
  { soal: 'air, berenang, sirip', jawab: 'ikan' },
  { soal: 'mimpi, malam, tidur', jawab: 'bantal' },
  { soal: 'pahit, hijau, sayur', jawab: 'pare' },
  { soal: 'tutup, basah, hujan', jawab: 'payung' },
  { soal: 'kursi, meja, belajar', jawab: 'sekolah' },
  { soal: 'dada, nafas, paru', jawab: 'paru-paru' },
  { soal: 'jepret, gambar, foto', jawab: 'kamera' },
  { soal: 'lucu, nangis, susu, popok', jawab: 'bayi' },
  { soal: 'keyboard, teknologi, layar', jawab: 'komputer' },
  { soal: 'kertas, baca, ilmu', jawab: 'buku' },
  { soal: 'baca, ilmu, kertas', jawab: 'buku' },
  { soal: 'foto, gambar, jepret', jawab: 'kamera' },
  { soal: 'dingin, angin, putar', jawab: 'kipas' },
  { soal: 'jepret, foto, gambar', jawab: 'kamera' },
  { soal: 'teknologi, keyboard, layar', jawab: 'komputer' },
  { soal: 'tinta, tangan, tulis', jawab: 'pena' },
  { soal: 'jalanan, roda empat, stir', jawab: 'mobil' },
  { soal: 'foto, gambar, jepret', jawab: 'kamera' },
  { soal: 'telinga, musik, suara', jawab: 'headset' },
  { soal: 'bulat, merah, buah', jawab: 'apel' },
  { soal: 'sadel, roda dua, gowes', jawab: 'sepeda' },
  { soal: 'kendaraan, aspal, lampu merah', jawab: 'jalan' },
  { soal: 'putar, dingin, angin', jawab: 'kipas' },
  { soal: 'peliharaan, bulu, meong', jawab: 'kucing' },
  { soal: 'terang, malam, jalanan', jawab: 'lampu' },
  { soal: 'roda empat, jalanan, stir', jawab: 'mobil' },
  { soal: 'jepret, gambar, foto', jawab: 'kamera' },
  { soal: 'sabun, bersih, air', jawab: 'mandi' },
  { soal: 'baju, pakai, dingin', jawab: 'jaket' },
  { soal: 'hijau, lapangan, makanan kambing', jawab: 'rumput' },
  { soal: 'kertas, ilmu, baca', jawab: 'buku' },
  { soal: 'hijau, lapangan, makanan kambing', jawab: 'rumput' },
  { soal: 'darah, detak, cinta', jawab: 'jantung' },
  { soal: 'tembok, pintu, atap', jawab: 'rumah' },
  { soal: 'layar, keyboard, teknologi', jawab: 'komputer' },
  { soal: 'susu, popok, nangis, lucu', jawab: 'bayi' },
  { soal: 'kaki empat, belajar, kayu', jawab: 'meja' },
  { soal: 'malam, tidur, mimpi', jawab: 'bantal' },
  { soal: 'jalanan, stir, roda empat', jawab: 'mobil' },
  { soal: 'alas, jalan, kaki', jawab: 'sepatu' },
  { soal: 'hijau, makanan kambing, lapangan', jawab: 'rumput' },
  { soal: 'terbang, kicau, sayap', jawab: 'burung' },
  { soal: 'langit, panas, siang', jawab: 'matahari' },
  { soal: 'makanan kambing, lapangan, hijau', jawab: 'rumput' },
  { soal: 'suara, musik, telinga', jawab: 'headset' },
  { soal: 'musik, telinga, suara', jawab: 'headset' },
  { soal: 'dingin, pakai, baju', jawab: 'jaket' },
  { soal: 'pahit, hijau, sayur', jawab: 'pare' },
  { soal: 'bersih, gigi, sikat', jawab: 'sikat gigi' },
  { soal: 'gambar, jepret, foto', jawab: 'kamera' },
  { soal: 'berenang, air, sirip', jawab: 'ikan' },
  { soal: 'terbang, sayap, kicau', jawab: 'burung' },
  { soal: 'paru, dada, nafas', jawab: 'paru-paru' },
  { soal: 'malam, terang, jalanan', jawab: 'lampu' },
  { soal: 'tidur, malam, mimpi', jawab: 'bantal' },
  { soal: 'peliharaan, meong, bulu', jawab: 'kucing' },
];