let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.tinggi)}”`, m)
}
handler.help = ['cektinggi']
handler.tags = ['cek']
handler.command = /^(cektinggi)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.tinggi = [
'144CM (itu tinggi apa resolusi video😂)', '120CM (botol yakult botol yakult)', '150CM (pendek banget lu njir)', '170CM (idaman banget mas/mbak 🥰)', '100CM (anjir cok ketemu orang 150 keatas kalo mau nyepong gausah berlutut itu 😂)', '180CM (diatas rata rata)', '190CM (kalo lu jadi kiper gaakan bisa di tembus kyknya)', '1000CM (LU MANUSIA APA TITAN KONTOL 😂)', '130CM (ihhh kemasan sasettt 😍)', '145CM (standar tinggi cewek loh ya, kalo lu cowok terus tinggi lu 145CM jadi femboy aja sono 😂)', '155CM (udah standar tinggi cewek, tapi kalo lu cowok sih jadi femboy aja kata gw)', '160CM (biasa aja, standar tinggi warga Indonesia)', '165CM (ideal gak sih?)', '200CM (gile lu, bisa di pake sodok mangga nih 😂)', '240CM (Anjir raksasa, udah kyk resolusi video aja lu 😂)',
]