const { GoogleGenerativeAI } = require("@google/generative-ai");
const fs = require("fs");
const path = require("path");  // Pastikan path diimpor
const { Sticker } = require('wa-sticker-formatter');
const fetch = require('node-fetch');

// Fungsi utama untuk menangani gambar dan stiker
let handler = async (m, { conn, args, text, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";

    // Validasi input gambar atau stiker
    if (!mime) {
        return m.reply(`📸 Kirim atau reply gambar/stiker dengan caption *${usedPrefix}${command} [prompt]*!`);
    }

    let originalPackName = packname;  // Menyimpan nama pack default
    let originalAuthorName = author;  // Menyimpan nama author default

    if (/webp/g.test(mime)) {
        // Jika media berupa stiker
        try {
            let img = await q.download();
            if (!img) throw new Error('Gagal mendownload media.');

            // Konversi stiker menjadi gambar
            const tempImgPath = path.join(process.cwd(), 'tmp', `temp_sticker_${Date.now()}.jpg`);
            fs.writeFileSync(tempImgPath, img);

            m.reply("⏳ Sabar ya, aku lagi proses nih...");

            const imgData = fs.readFileSync(tempImgPath);
            const base64Image = imgData.toString("base64");
            if (!text) {
                return m.reply(`✍️ Promptnya mana? Kasih instruksi setelah perintah!`);
            }
            const promptText = text;

            const genAI = new GoogleGenerativeAI(geminiApi);
            const model = genAI.getGenerativeModel({
                model: "gemini-2.0-flash-exp-image-generation",
                generationConfig: {
                    responseModalities: ["text", "image"]
                }
            });

            const contents = [
                { text: promptText },
                {
                    inlineData: {
                        mimeType: "image/jpeg",
                        data: base64Image
                    }
                }
            ];

            const response = await model.generateContent(contents);
            const candidate = response.response.candidates[0];
            let resultImage;

            // Proses response AI dan simpan gambar hasil
            for (const part of candidate.content.parts) {
                if (part.inlineData && part.inlineData.data) {
                    resultImage = Buffer.from(part.inlineData.data, "base64");
                }
            }

            if (!resultImage) {
                throw new Error("Gambar hasil tidak ditemukan dalam response");
            }

            const tempPath = path.join(process.cwd(), "tmp", `aiimage_${Date.now()}.png`);
            fs.writeFileSync(tempPath, resultImage);

            // Ubah hasil gambar menjadi stiker dengan nama pack dan author yang asli
            let stikerResult = await createSticker(resultImage, false, originalPackName, originalAuthorName);

            // Kirim stiker hasil AI menggunakan sendMessage
            await conn.sendMessage(m.chat, {
                sticker: stikerResult
            }, { quoted: m });

            // Cleanup dengan timeout
            setTimeout(() => {
                try {
                    if (fs.existsSync(tempImgPath)) fs.unlinkSync(tempImgPath);
                    if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
                } catch (err) {
                    console.error("Gagal menghapus file temporary:", err);
                }
            }, 30000);

        } catch (e) {
            console.log(e);
            m.reply(`Error saat mengolah stiker: ${e.message}`);
        }

    } else if (/image\/.*/g.test(mime)) {
        // Jika media berupa gambar
        try {
            let img = await q.download();
            if (!img) throw new Error('Gagal mendownload media.');

            // Konversi gambar menjadi base64
            const tempImgPath = path.join(process.cwd(), 'tmp', `temp_image_${Date.now()}.jpg`);
            fs.writeFileSync(tempImgPath, img);

            m.reply("⏳ Sabar ya, aku lagi proses nih...");

            const imgData = fs.readFileSync(tempImgPath);
            const base64Image = imgData.toString("base64");
            if (!text) {
                return m.reply(`✍️ Promptnya mana? Kasih instruksi setelah perintah!`);
            }
            const promptText = text;

            const genAI = new GoogleGenerativeAI("AIzaSyDRwFV192QpTievc23HO8u8fQYP3oBfwr4");
            const model = genAI.getGenerativeModel({
                model: "gemini-2.0-flash-exp-image-generation",
                generationConfig: {
                    responseModalities: ["text", "image"]
                }
            });

            const contents = [
                { text: promptText },
                {
                    inlineData: {
                        mimeType: "image/jpeg",
                        data: base64Image
                    }
                }
            ];

            const response = await model.generateContent(contents);
            const candidate = response.response.candidates[0];
            let resultImage;

            // Proses response AI dan simpan gambar hasil
            for (const part of candidate.content.parts) {
                if (part.inlineData && part.inlineData.data) {
                    resultImage = Buffer.from(part.inlineData.data, "base64");
                }
            }

            if (!resultImage) {
                throw new Error("Gambar hasil tidak ditemukan dalam response");
            }

            const tempPath = path.join(process.cwd(), "tmp", `aiimage_${Date.now()}.png`);
            fs.writeFileSync(tempPath, resultImage);

            // Kirim hasil gambar sebagai gambar (image message)
            await conn.sendMessage(m.chat, {
                image: resultImage,
                caption: "Ini dia gambar hasil AI!"
            }, { quoted: m });

            // Cleanup dengan timeout
            setTimeout(() => {
                try {
                    if (fs.existsSync(tempImgPath)) fs.unlinkSync(tempImgPath);
                    if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
                } catch (err) {
                    console.error("Gagal menghapus file temporary:", err);
                }
            }, 30000);

        } catch (e) {
            console.log(e);
            m.reply(`Error saat mengolah gambar: ${e.message}`);
        }
    } else {
        m.reply(`🚫 Format yang diterima tidak valid. Kirim gambar atau stiker untuk proses ini.`);
    }
};

// Fungsi untuk membuat stiker
async function createSticker(img, url, packName, authorName, quality = 20) {
    let stickerMetadata = {
        type: 'full',
        pack: packName,
        author: authorName,
        quality
    };
    return new Sticker(img ? img : url, stickerMetadata).toBuffer();
}

handler.help = ["aiimage {prompt}"];
handler.tags = ["ai"];
handler.command = ["aiimage", "aimage"];

module.exports = handler;
