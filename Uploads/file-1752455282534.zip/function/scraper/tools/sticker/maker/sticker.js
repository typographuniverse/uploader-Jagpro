const axios = require('axios');

const GITHUB_TOKEN = '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';
const REPO_OWNER = 'ChandraGO';
const REPO_NAME = 'Database-Jagpro';
const FILE_PATH = 'user.json';
const BRANCH = 'master';

const apiBaseUrl = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}?ref=${BRANCH}`;

exports.sesi = async (number) => {
  try {
    const response = await axios.get(apiBaseUrl, {
      headers: {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github+json', // Format JSON GitHub API
      },
    });

    // Konten dikodekan dalam base64
    const content = Buffer.from(response.data.content, 'base64').toString('utf-8');
    
    // Parse konten sebagai JSON
    const users = JSON.parse(content);
    
    // Cek apakah nomor ada di array users
    const isVerified = users.some(user => user.nomor === number);

    return isVerified;
  } catch (error) {
    console.error('Gagal verifikasi nomor:', error.message);
    if (error.response) {
      console.error('Respons GitHub API:', error.response.data);
    }
    return false;
  }
};