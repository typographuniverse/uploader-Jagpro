const schedule = require('node-schedule');

let handler = async (m, { conn }) => {
    let targetDate = new Date('Maret 31, 2025 00:00:00');
    let currentDate = new Date();
    let remainingTime = targetDate.getTime() - currentDate.getTime();
    let days = Math.floor(remainingTime / (1000 * 60 * 60 * 24));
    let hours = Math.floor((remainingTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((remainingTime % (1000 * 60)) / 1000);
    let countdownMessage = `Tinggal ${days} hari, ${hours} jam, ${minutes} menit, ${seconds} detik menuju hari puasa tahun 2025!`;

    let img = 'https://telegra.ph/file/c1e45131e3702d2150d2f.jpg';

    conn.sendMessage(m.chat, {
        text: countdownMessage,
        contextInfo: {
            forwardingScore: 99999,
            isForwarded: true,
            externalAdReply: {
                title: `Idul Fitri`,
                thumbnailUrl: img,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    });
};

// Menjadwalkan pengiriman otomatis setiap jam 04:00 pagi
schedule.scheduleJob('0 19 * * *', async () => {
    let chats = Object.keys(await conn.chats);
    for (let chat of chats) {
        await handler({ chat }, { conn });
    }
});

handler.help = ['lebaran'];
handler.tags = ['fun'];
handler.command = /^(lebaran)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;

module.exports = handler;
